"""C03 original steerable corner development, mm. No vendor internals or release."""
from pathlib import Path
import sys,json,math
import cadquery as cq
import numpy as np
P=Path(__file__).parent
sys.path.insert(0,str(P.parent));sys.path.insert(0,str(P.parent/'running_gear_C02'))
from generate_cad import glb,properties,exact_bounds
from generate_interfaces import cyl_axis,tube_between,HOLES

def output(s,name,notes):
 assert s.isValid() and len(s.Solids())==1,(name,len(s.Solids()))
 cq.exporters.export(s,str(P/(name+'.step')));glb([(name,s)],P/(name+'.glb'))
 r={'part':name,'original':True,'fabrication_released':False,'valid':s.isValid(),'bounds_mm':exact_bounds(s),'density_assumption_kg_m3':7850,**properties(s),'notes':notes}
 (P/(name+'_report.json')).write_text(json.dumps(r,indent=2));print(name,r['mass_kg'],flush=True)

def arm(z,lower=False):
 print("start_arm",z,flush=True)
 eyes=[(-170,550,z),(170,550,z),(0,812,z-150)]
 p=cyl_axis(25,80,(-210,550,z),(1,0,0)).union(cyl_axis(25,80,(130,550,z),(1,0,0)))
 # Original machined housing, removable outer retainer is separate.
 p=p.union(cyl_axis(40,28.4,(-15.7,812,z-150),(1,0,0)))
 # Central neck keeps converging tubes away from the yawing fork bosses.
 neck=(0,760 if lower else 730,z-150)
 for a in eyes[:2]:
  if lower:
   foot=(a[0],575,z-110);mid=(a[0]/2,681,z-140);p=p.union(tube_between(a,foot)).union(tube_between(foot,mid)).union(tube_between(mid,neck))
  else:p=p.union(tube_between(a,neck))
 p=p.union(tube_between(neck,eyes[2]))
 print("arm_tubes_fused",z,flush=True)
 for x,y,zz in eyes[:2]:p=p.cut(cyl_axis(17.5,82,(x-41,y,zz),(1,0,0)))
 p=p.cut(cyl_axis(25,100,(-50,812,z-150),(1,0,0))).cut(cyl_axis(53.975/2,25.5,(-12.7,812,z-150),(1,0,0)))
 print("arm_bores_cut",z,flush=True)
 for a in [45,135,225,315]:
  y,zz=812+34*math.cos(math.radians(a)),z-150+34*math.sin(math.radians(a))
  p=p.cut(cyl_axis(2.1,35,(-18,y,zz),(1,0,0)))
 if lower:
  y,zz=550+.65*262,z-.65*150
  for a,b in [((-59.5,y,zz),(-24,y,zz)),((24,y,zz),(59.5,y,zz))]:p=p.union(tube_between(a,b,20,16))
  for x in [-42.71519,42.71519]:p=p.union(tube_between((x,y,z-144.9746835443038),(x,y,zz),12.5,9.5))
  for x in [-20,20]:p=p.union(cq.Workplane('XY').box(8,40,40).translate((x,y,zz)).cut(cyl_axis(7.25,20,(x-10,y,zz),(1,0,0))))
 print("arm_done",z,flush=True)
 return p.val()

def upright():
 outline=[(-145,-130),(-120,-150),(-120,-210),(120,-210),(120,-150),(145,-130),(145,130),(120,150),(120,210),(-120,210),(-120,150),(-145,130)]
 p=cq.Workplane('XY').polyline(outline).close().extrude(18).cut(cq.Workplane('XY').circle(86).extrude(20))
 p=p.cut(cq.Solid.makeCone(87,86,1,cq.Vector(0,0,0),cq.Vector(0,0,1)))
 for x,y in HOLES:p=p.cut(cq.Workplane('XY').center(x,y).circle(4.25).extrude(20))
 # Main plate is relieved broadly; joint clevis returns from outboard to avoid inboard arm tubes.
 for sign in [-1,1]:
  p=p.cut(cq.Workplane('YZ').center(sign*170,-15).circle(90).extrude(90,both=True))
  for x in [-100,100]:p=p.union(cq.Workplane('XY').box(12,30,82).translate((x,sign*170,-23)))
  p=p.union(cq.Workplane('XY').box(212,30,10).translate((0,sign*170,-64)))
  for x in [-39,39]:
   ear=cq.Workplane('YZ',origin=(x-4,sign*170,-15)).circle(16).extrude(8)
   ear=ear.union(cq.Workplane('XY').box(8,32,49).translate((x,sign*170,-39.5)))
   pin=cq.Workplane('YZ').center(sign*170,-15).circle(9.75).extrude(60,both=True)
   p=p.union(ear.cut(pin))
 return p.val()
if __name__=='__main__':
 for n,s in [('lower_wishbone_C03_R04',arm(-270,True))]:
  output(s,n,{'status':'Unqualified local development; collision sweep pending','outer_joint':'Single FK AIN16 spherical bearing per upper/lower joint; original bolted retainer housing','root_joints':'C02 paired GE20ES envelopes retained, retention unresolved','steering':'Actual yaw through outer spherical joint centerline; no visual-only yaw','pins':'3/4-inch nominal; actual hardware/retention and fork spacers pending','source_dimensions':'source_joint_selection.json'})
