from geometry_common import *
S=BASE/'service-fixtures';start=time.time();U=load(C/'upper_wishbone_C03_R06.step');L=load(C/'lower_wishbone_C03_R04.step');frame=load(C.parent/'frame_R07.step');body=load(BASE/'body-power/body_power_R01.step');cbase=load(S/'corner_cradle_S01.step');trestles=load(S/'chassis_trestles_S01.step');cradles=[]
for station in [-1350,1350]:
 for side in [-1,1]:cradles.append(proper(cbase,side).translate((station,0,0)))
fixtures=cq.Compound.makeCompound([trestles]+cradles)
static=[(f'frame_{i}',s,bd(s))for i,s in enumerate(frame.Solids())]+[(f'body_{i}',s,bd(s))for i,s in enumerate(body.Solids())]
fixture_parts=[(f'S01_solid_{i}',s,bd(s))for i,s in enumerate(fixtures.Solids())]
rackreport=json.loads((C/'rack_C03_R11_report.json').read_text());racks=[(i['part'],load(C/(i['part']+'.step')),i['group'])for i in rackreport['parts']]
rows=[];fails=[]
def best_screen(arm,items,label,meta):
 armbox=bd(arm)
 candidates=sorted([(bboxgap(armbox,b),n,s)for n,s,b in items],key=lambda t:t[0]);mindata=None
 for g,n,s in candidates:
  if mindata is not None and g>mindata['clearance_mm']+1e-7:continue
  # Positive AABB separation is already rigorous geometric clearance evidence.
  r=test(arm,s,label+'__'+n,exact_limit=1e-5);r.update(meta)
  if r['overlap_mm3']>1e-4:fails.append(r);print('FAIL',r,flush=True)
  if mindata is None or r['clearance_mm']<mindata['clearance_mm']:mindata=r
 rows.append(mindata)
for fore,side in [(1,1),(1,-1),(-1,1),(-1,-1)]:
 station=1350*fore;corner=('front'if fore>0 else 'rear')+'_'+('left'if side>0 else 'right');un=proper(U,side).translate((station,0,0));ln=proper(L,side).translate((station,0,0));sn='left'if side>0 else'right';cl=load(C/('stationary_clamp_'+('front'if fore>0 else'rear')+'_'+sn+'_C03_R03.step')).translate((station,0,0))
 for q in np.linspace(-12,12,25):
  arms=[('upper',un.rotate((station,side*550,70),(station+1,side*550,70),side*q)),('lower',ln.rotate((station,side*550,-270),(station+1,side*550,-270),side*q))]
  for tag,s in arms:
   meta={'corner':corner,'arm':tag,'q_deg':float(q),'rack_mm':None};best_screen(s,static,tag+'__frame_body',meta)
   if abs(q)<1e-9:best_screen(s,fixture_parts,tag+'__neutral_fixtures',meta)
  if q in [-12,0,12]:
   for tag,s in arms:
    rr=test(s,cl,tag+'__stationary_clamp_R03',exact_limit=1e-5);rr.update(corner=corner,arm=tag,q_deg=float(q),rack_mm=None);rows.append(rr)
    if rr['overlap_mm3']>1e-4:fails.append(rr);print('FAIL',rr,flush=True)
  if q in [-12,-9,-6,-3,0,3,6,9,12]:
   for rack in [-75,-37.5,0,37.5,75]:
    allrack=[]
    for n,s,g in racks:
     ss=s if fore>0 else s.mirror('YZ');ss=ss.translate((0,rack,0))if g=='rack_translation_Y'else ss;allrack.append((n,ss,bd(ss)))
    for tag,s in arms:best_screen(s,allrack,tag+'__rack_R11',{'corner':corner,'arm':tag,'q_deg':float(q),'rack_mm':rack})
  if q in [-12,0,12]:print(corner,q,'failures',len(fails),flush=True)
  report={'scope':'New armsU06/L04 vs actual frameR07/bodyR01 at25q samples; rackR11 at9q x5r samples; stationary clamps atq=-12,0,12; fixtures atneutral only. Proper side rotations preserved on common arms and same side orientation reused atrear. Private motor excluded. Positive AABB gaps are conservative bounds; candidates with overlapping boxes get exact B-rep tests.','source_sha256':{n:hashlib.sha256((C/(n+'.step')).read_bytes()).hexdigest()for n in ['upper_wishbone_C03_R06','lower_wishbone_C03_R04']},'rows':rows,'failures':fails,'elapsed_s':time.time()-start}
  (P/'new_arms_environment_check.json').write_text(json.dumps(report,indent=2))
print('COMPLETE',len(rows),'fail',len(fails),flush=True)
