# U06 / L04 original-geometry checks, baked C03 R03

Status: PASS within the finite check scopes below. Not fabrication, tolerance, dynamic, or service approval.

- Upper: upper_wishbone_C03_R06.step; lower: lower_wishbone_C03_R04.step. Exact hashes are in FINAL_U06_L04_ORIGINAL_CHECK_SUMMARY.json and input_hashes.json.
- All 36 coupled q/r endpoint and neutral poses across four corners pass. There are 360 actual-geometry pair checks (carrier R05, rim C01, 340 mm tire annulus, outer joint pins, actual Ø32 tie tube), plus 72 conservative whole-tie capsule-bound entries.
- Frame/body: 25 q samples per corner. Rack R11: 9 q × 5 rack samples per corner. The 592 environment result entries also cover clamp endpoints/neutral and neutral arm-to-S01 fixtures; no positive-volume overlap was found.
- Root hardware/backing and upper-to-lower checks pass. All 100 upper-to-handed-clamp tests across 25 q samples per corner pass. Read the root report for measured versus rigid-transform-inherited results and bearing-fit exclusions.
- Baked R03 neutral fixture test maps all 76 manifest nodes / 202 solids directly from the STEP, plus 12 conservative tie/head reservations. All 88 checks against 302 fixture solids pass without overlaps or contacts.
- Source tire containment is exact: tire_C01 outside the full 340 mm annulus has zero volume and zero faces. The rim is checked separately at every one of the 36 poses.

## Measured witnesses

- Upper versus stationary clamp: 3.000 mm at q = −12°, 0°, +12°.
- Upper versus 340 mm tire annulus: 3.011784 mm at q = −12°, rack = −75 mm.
- Upper versus rear partition: 47.201108 mm at q = −12°, 0°, +12°, both sides.
- Lower versus final steering lever: 7.983528 mm at the checked minimum candidate.
- Neutral S01 whole-tie capsule: 8.062146 mm.

The 29,197-pose upper-tube annulus screen samples 129 points on each of seven tube segments. Its conservative along-segment sampling allowance leaves 1.969629 mm at sampled poses. Local continuous refinement returns 3.011784 mm at the known endpoint; no worse interior candidate was found. This is not an interval proof over unsampled q/r space. Housing and eyes receive the finite exact geometry tests.

The approximately 3 mm nominal margins remain unqualified for tolerances, actual tire section on the selected rim, fabrication variation, and load deflection. Keep q=0 UI restrictions and all existing release holds. Root bearing fit/retention, strength, installed-wheel removal, lifting and the wheel-first support/isolation sequence remain unresolved.

In the motion/environment JSON, a zero clearance with type `Boolean_volume_check_only_gap_not_evaluated` means distance was not measured. Positive-volume intersection is the checked quantity; it does not indicate a zero-gap contact.

Rejected U03/U04/U05 results and frozen R01 remain separately preserved. Package only the explicit PUBLIC_SAFE_WHITELIST.json, not entire analysis directories. No private drive CAD was read or exported by this audit.
