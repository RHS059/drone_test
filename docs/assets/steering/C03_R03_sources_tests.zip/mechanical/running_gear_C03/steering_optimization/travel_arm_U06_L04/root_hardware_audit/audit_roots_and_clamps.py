"""Independent original-geometry audit. Read sources only; write this audit directory only."""
from pathlib import Path
import json,hashlib,time,math,copy,sys
import numpy as np
import cadquery as cq
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
from OCP.BRepAlgoAPI import BRepAlgoAPI_Common
P=Path(__file__).resolve().parent; C=P.parents[2]; C2=C.parent/'running_gear_C02'; T0=time.time()
EPS_VOL=1e-4; EPS_DIST=1e-5
sources={};inputs={}
def load(folder,stem):
 p=folder/(stem+'.step');s=cq.importers.importStep(str(p)).val()
 assert s.isValid(),stem
 sources[stem]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'solid_count':len(s.Solids()),'valid':True}
 inputs[stem]=s
 print('LOADED',stem,flush=True)
 return s
U=load(C,'upper_wishbone_C03_R06');L=load(C,'lower_wishbone_C03_R04')
assert sources['upper_wishbone_C03_R06']['sha256']=='cea5bba0af9ab4a41abd9957f143350cff1a7bc74f3a1f3fc3fe20f103347a6f'
H=load(C2,'stationary_hardware_C02_R01');B=load(C2,'inner_backing_C02_R01')
clamps={(fore,side):load(C,'stationary_clamp_'+('front' if fore>0 else 'rear')+'_'+('left' if side>0 else 'right')+'_C03_R03') for fore in [-1,1] for side in [-1,1]}
manifest_path=C/'original_steering_C03_R03_manifest.json';mf=json.loads(manifest_path.read_text());nodes={n['node']:n for n in mf['assembly_nodes']}
def bounds(s):
 b=s.BoundingBox();return np.array([b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax])
def boxgap(a,b):return float(np.linalg.norm(np.maximum(0,np.maximum(a[:3]-b[3:],b[:3]-a[3:]))))
def place(s,side,station):return (s if side==1 else s.rotate((0,0,0),(0,0,1),180)).translate((station,0,0))
def dist(s,t):
 d=BRepExtrema_DistShapeShape();d.SetMultiThread(False);d.LoadS1(s.wrapped);d.LoadS2(t.wrapped);d.Perform()
 assert d.IsDone(),'Distance calculation failed'
 return float(d.Value())
def common(s,t):
 op=BRepAlgoAPI_Common();v=s._bool_op((s,),(t,),op,parallel=False)
 assert op.IsDone(),'Boolean calculation failed'
 assert v.isValid(),'Invalid common shape'
 return v
names=[]
for z in [70,-270]:
 for x in [-170,170]:names.append(f'original_hinge_pin_{x}_{z}')
for x in [-35,35]:
 for z in [-114,114]:
  names += [f'M12_nominal_clamp_bolt_{x}_{z}',f'M12_nominal_washer_{x}_{z}',f'M12_nominal_nut_{x}_{z}']
assert len(H.Solids())==len(names)==16
hardware=[]
for i,(name,s) in enumerate(zip(names,H.Solids())):
 center=s.Center();expected=name.split('_')[-2:];x,z=map(float,expected)
 assert abs(center.z-z)<1e-3
 assert abs(center.x-(x-7.54439436717 if 'hinge' in name else x))<1e-3
 hardware.append((name,s))
rows=[];overlaps=[];contacts=[];mapping=[];clamp_rows=[]
canonical_path=P/'canonical_root_exact_results.json'
canonical=None if '--recompute-canonical' in sys.argv or not canonical_path.exists() else json.loads(canonical_path.read_text())
if canonical:
 for stem,item in canonical['sources'].items():assert sources[stem]['sha256']==item['sha256'],('Changed source',stem)
 assert canonical['manifest_sha256']==hashlib.sha256(manifest_path.read_bytes()).hexdigest()
 assert len(canonical['rows'])==15 and not canonical['positive_volume_failures'] and not canonical['zero_gap_contacts']
print('CANONICAL_CACHE',bool(canonical),flush=True)
def save(done=False):
 report={'status':'complete' if done else 'running','scope':'Actual U06/L04 vs 16 stationary hardware solids and inner backing plus upper/lower at q=-12,0,+12 degrees, all four original C03 R03 corners; U06 vs each handed R03 stationary clamp at q=-12..+12 in 1-degree steps.','excluded':'Private drive geometry, physical purchased bearings, tolerances, strength, dynamic deflection, unsampled continuous sweep. Other environment clearances belong to separate audits.','sources':sources,'manifest_path':str(manifest_path),'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'transform':'Common arms/hardware/backing: left identity, right proper Rz(pi), then station translation X=+1350 front or -1350 rear. Motion: world Rx(side*q) around (station,side*550,70 upper/-270 lower). Same common-part side orientation at both ends. Handed clamps are translated only.','method':'B-rep exact minimum distance for every aggregate root/backing/upper-lower group. Every root candidate with overlapping AABBs gets a single-threaded OpenCascade common-volume test. Upper-clamp receives exact common-volume test at each sample, plus distance at endpoints and neutral. Far pairs use rigorous AABB lower bounds.','positive_volume_threshold_mm3':EPS_VOL,'zero_gap_threshold_mm':EPS_DIST,'rigid_reuse_proof':'Rear-left, front-left and front-right root assemblies are common proper rigid transforms of rear-right at the same local q. Rz(pi) conjugates world Rx(-q) into Rx(q). All arms, backing and 16 hardware solids share the transform. Translation changes only X station. Each neutral placement/source is independently matched to the final manifest. Handed clamps are never reused.', 'canonical_reference':'The direct rear-right reference results are embedded in root_rows. The script optionally caches them locally; without that optional cache, or with --recompute-canonical, it recalculates all reference pairs.', 'contact_classification_scope':'Root group exact distances are evaluated at -12, 0, +12 degrees. Clamp exact distances are evaluated at the same three poses only; the other 88 clamp samples establish zero common volume, not a positive clearance or no-contact bound.', 'hardware_name_mapping':'16 imported solids mapped to generator export order and verified by center coordinates.','nominal_interface_note':'Ø20 hinge pins are surrounded by Ø35 arm pockets; unmodeled bearing fit envelopes are intentionally not solid metal. Nonzero clearance here does not validate installed bearing fits or retention.','neutral_manifest_mapping':mapping,'root_rows':rows,'clamp_rows':clamp_rows,'positive_volume_failures':overlaps,'zero_gap_contacts':contacts,'elapsed_s':time.time()-T0}
 (P/'root_hardware_upper_lower_clamp_audit.json').write_text(json.dumps(report,indent=2))
 return report

def groupcheck(a,candidates,label,meta):
 ab=bounds(a);best=math.inf;nearest=None;pr=[]
 for bg,name,b in sorted([(boxgap(ab,bounds(b)),name,b) for name,b in candidates],key=lambda r:r[0]):
  row={'part':name,'AABB_lower_bound_mm':bg,'common_volume_mm3':0.,'boolean_evaluated':False,'distance_mm':None,'distance_evaluated':False}
  if bg<=EPS_DIST:
   cm=common(a,b);row.update(common_volume_mm3=float(cm.Volume()),boolean_evaluated=True,common_solid_count=len(cm.Solids()))
  if bg<=best+EPS_DIST:
   dd=dist(a,b);row.update(distance_mm=dd,distance_evaluated=True)
   if dd<best:best=dd;nearest=name
  if row['common_volume_mm3']>EPS_VOL:
   failure={**meta,'pair':label,'other':name,'overlap_mm3':row['common_volume_mm3']};overlaps.append(failure);print('FAIL',failure,flush=True)
  elif row['distance_mm'] is not None and row['distance_mm']<EPS_DIST:
   contacts.append({**meta,'pair':label,'other':name,'overlap_mm3':row['common_volume_mm3']})
  pr.append(row)
 out={**meta,'pair':label,'minimum_clearance_mm':best,'nearest_part':nearest,'per_solid':pr};rows.append(out);save()
 return out

for fore in [-1,1]:
 for side in [-1,1]:
  station=fore*1350;corner=('front' if fore>0 else 'rear')+'_'+('left' if side>0 else 'right')
  neutral={'upper_wishbone_C03_R06':place(U,side,station),'lower_wishbone_C03_R04':place(L,side,station),'stationary_hardware_C02_R01':place(H,side,station),'inner_backing_C02_R01':place(B,side,station)}
  for stem,s in neutral.items():
   node=nodes[corner+'_'+stem];dv=abs(s.Volume()*1e-9-node['volume_m3']);dc=float(np.max(np.abs(np.array(s.Center().toTuple())*1e-3-np.array(node['com_m']))))
   assert dv<max(1e-10,node['volume_m3']*1e-6) and dc<1e-6,(corner,stem,dv,dc)
   assert node['source_step'].endswith(stem+'.step')
   mapping.append({'node':corner+'_'+stem,'volume_delta_m3':dv,'COM_max_delta_m':dc,'solid_count':len(s.Solids())})
  hw=[(n,place(s,side,station)) for n,s in hardware];back=[('inner_backing_C02_R01',neutral['inner_backing_C02_R01'])]
  for q in [-12,0,12]:
   if canonical:
    ref=[copy.deepcopy(r) for r in canonical['rows'] if r['q_deg']==q]
    assert len(ref)==5
    for row in ref:
     row['corner']=corner;row['reference_corner']='rear_right';row['evaluation']='direct_exact_reference' if corner=='rear_right' else 'proper_rigid_transform_invariance';rows.append(row)
    save();print('ROOT_CONGRUENCE',corner,q,'5 groups validated',flush=True)
    continue
   arms={name:neutral[stem].rotate((station,side*550,z),(station+1,side*550,z),side*q) for name,stem,z in [('upper','upper_wishbone_C03_R06',70),('lower','lower_wishbone_C03_R04',-270)]}
   results=[]
   for name,a in arms.items():
    meta={'corner':corner,'q_deg':q,'arm':name};r=groupcheck(a,hw,name+'__stationary_hardware',meta);results.append((name,'hardware',r['minimum_clearance_mm']))
    r=groupcheck(a,back,name+'__inner_backing',meta);results.append((name,'backing',r['minimum_clearance_mm']))
   r=groupcheck(arms['upper'],[('lower_wishbone_C03_R04',arms['lower'])],'upper__lower',{'corner':corner,'q_deg':q,'arm':'upper'});results.append(('upper','lower',r['minimum_clearance_mm']))
   print('ROOT_RESULT',corner,q,results,'fails',len(overlaps),flush=True)
  if canonical is None and corner=='rear_right':
   assert len(rows)==15 and not overlaps and not contacts
   canonical={'sources':sources,'manifest_sha256':hashlib.sha256(manifest_path.read_bytes()).hexdigest(),'reference_corner':'rear_right','rows':copy.deepcopy(rows),'positive_volume_failures':[],'zero_gap_contacts':[]}
   canonical_path.write_text(json.dumps(canonical,indent=2))
# Upper clamp sweep is intentionally separate from root checks for immediate partial report.
print('ROOTS_COMPLETE',len(rows),'fails',len(overlaps),'contacts',len(contacts),flush=True)
for fore in [-1,1]:
 for side in [-1,1]:
  station=fore*1350;corner=('front' if fore>0 else 'rear')+'_'+('left' if side>0 else 'right');u0=place(U,side,station);cl=clamps[(fore,side)].translate((station,0,0))
  for q in range(-12,13):
   u=u0.rotate((station,side*550,70),(station+1,side*550,70),side*q);c=common(u,cl);v=float(c.Volume());d=dist(u,cl) if q in [-12,0,12] or v>EPS_VOL else None
   row={'corner':corner,'q_deg':q,'pair':'upper__stationary_clamp_R03','common_volume_mm3':v,'common_solid_count':len(c.Solids()),'common_face_count':len(c.Faces()),'distance_mm':d};clamp_rows.append(row)
   if v>EPS_VOL:overlaps.append(row);print('FAIL',row,flush=True)
   elif d is not None and d<EPS_DIST:contacts.append(row)
   save()
   print('CLAMP_RESULT',corner,q,'volume',v,'distance',d,flush=True)
r=save(True);print('COMPLETE',len(rows),'root groups',len(clamp_rows),'clamp samples','failures',len(overlaps),'contacts',len(contacts),'seconds',r['elapsed_s'],flush=True)
