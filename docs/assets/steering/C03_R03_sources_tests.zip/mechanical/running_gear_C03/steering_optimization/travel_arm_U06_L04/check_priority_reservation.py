from geometry_common import *
q=-12.;r=-75.;qr=np.deg2rad(q);a=np.array([-289.,-90,-85]);dv=np.array([0.,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150]);d,_,_=solve(a,72,np.array([qr]),np.array([r]),np.array([dv]));dd=float(np.rad2deg(d[0]));king=np.array([0.,812,-250]);U=load(C/'upper_wishbone_C03_R06.step');upper=U.rotate((0,550,70),(1,550,70),q);rows=[]
reserve=cq.Workplane('XZ',origin=(0,1110,-250)).circle(438.15).circle(228.6).extrude(340).val();reserve=reserve.rotate(tuple(king),tuple(king+[0,0,1]),dd).translate(tuple(dv))
rsv=upper.intersect(reserve).Volume();rg=distance(upper,reserve)if rsv<1e-4 else 0
rows.append({'component':'conservative_340_tire_annulus','overlap_mm3':rsv,'clearance_mm':rg});print(rows[-1],flush=True);(P/'priority_check.json').write_text(json.dumps({'q_deg':q,'rack_mm':r,'steer_deg':dd,'rows':rows},indent=2))
