from geometry_common import *
U=load(C/'upper_wishbone_C03_R06.step');cl=load(C/'stationary_clamp_front_left_C03_R03.step');rows=[]
for q in [-12,0,12]:
 u=U.rotate((0,550,70),(1,550,70),q);vol=u.intersect(cl).Volume();row={'component':'stationary_clamp_front_left_R03','q_deg':q,'overlap_mm3':vol,'exact_clearance_mm':distance(u,cl)if vol<1e-4 else 0};rows.append(row);print(row,flush=True)
meta=json.loads((BASE/'body-power/verification.json').read_text());parts=load(BASE/'body-power/body_power_R01.step').Solids();panel=next(s for s,m in zip(parts,meta['parts'])if m['name']=='controller_battery_partition')
for side in [1,-1]:
 un=proper(U,side).translate((-1350,0,0))
 for q in [-12,0,12]:
  u=un.rotate((-1350,side*550,70),(-1349,side*550,70),side*q);vol=u.intersect(panel).Volume();row={'component':'rear_partition','side':side,'q_deg':q,'overlap_mm3':vol,'exact_clearance_mm':distance(u,panel)if vol<1e-4 else 0};rows.append(row);print(row,flush=True)
(P/'targeted_clearances.json').write_text(json.dumps({'upper_sha256':hashlib.sha256((C/'upper_wishbone_C03_R06.step').read_bytes()).hexdigest(),'rows':rows},indent=2))
