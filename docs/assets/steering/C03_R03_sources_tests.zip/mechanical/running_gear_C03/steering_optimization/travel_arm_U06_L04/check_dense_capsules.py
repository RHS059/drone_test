from geometry_common import *
import search_packageable_75 as m
q,r=np.meshgrid(np.deg2rad(np.linspace(-12,12,97)),np.linspace(-75,75,301),indexing='ij');Q=q.ravel();R=r.ravel();DV=np.array([np.zeros_like(Q),262*np.cos(Q)+150*np.sin(Q)-262,262*np.sin(Q)-150*np.cos(Q)+150]).T;a=np.array([-289.,-90,-85]);D,O,I=solve(a,72,Q,R,DV);K=np.array([0,812,-250]);n=np.array([0.,150,262]);n/=np.linalg.norm(n)
obs=[]
for label,z in [('upper',70),('lower',-270)]:
 for x in [-170,170]:
  obs.append((label+'_root_'+str(x),np.array([x-40,550,z]),np.array([x+40,550,z]),25,z))
  if label=='lower':points=[(x,550,z),(x,575,z-110),(x/2,681,z-140),(0,760,z-150)]
  else:points=[(x,550,z),(x,625,z+30),(x/2,600,z+50),(0,760,z-150)]
  for j,(p,b)in enumerate(zip(points[:-1],points[1:])):obs.append((label+'_branch_'+str(x)+'_'+str(j),np.array(p),np.array(b),16,z))
 obs.append((label+'_neck',np.array([0,760,z-150]),np.array([0,812,z-150]),16,z));obs.append((label+'_housing',np.array([-15.7,812,z-150]),np.array([12.7,812,z-150]),40,z))
# Conservative lower shock crossbars/support segments and tab boxes (enclosing spheres).
y=720.3;z=-367.5
for x in [-1,1]:
 obs.append(('lower_shock_crossbar_'+str(x),np.array([x*24,y,z]),np.array([x*59.5,y,z]),20,-270))
 obs.append(('lower_shock_support_'+str(x),np.array([x*42.71519,y,-414.9746835443038]),np.array([x*42.71519,y,z]),12.5,-270))
 # Tab box8x40x40 enclosure sphere.
 obs.append(('lower_shock_tab_'+str(x),np.array([x*20,y,z]),np.array([x*20,y,z+1e-6]),np.sqrt(4**2+20**2+20**2),-270))
levers=[]
for side in [-1,1]:
 aa=a+side*27.3*n;bb=aa+[-115-aa[0],772-(K+aa)[1],-(772-(K+aa)[1])*150/262];levers.append((K+DV+m.rotz(aa,D),K+DV+m.rotz(bb,D)))
rows=[]
for name,p,b,rad,z in obs:
 pp=p-[0,550,z];bb=b-[0,550,z];p=np.array([np.full_like(Q,pp[0]),pp[1]*np.cos(Q)-pp[2]*np.sin(Q)+550,pp[1]*np.sin(Q)+pp[2]*np.cos(Q)+z]).T;b=np.array([np.full_like(Q,bb[0]),bb[1]*np.cos(Q)-bb[2]*np.sin(Q)+550,bb[1]*np.sin(Q)+bb[2]*np.cos(Q)+z]).T
 for name2,g in [('whole_tie',m.distance_segments(I,O,p,b)-rad-16),('outer_fork',m.distance_segments(O,O+1e-6,p,b)-rad-37.2)]+[('lever_'+str(j),m.distance_segments(la,lb,p,b)-rad-17)for j,(la,lb)in enumerate(levers)]:
  i=np.argmin(g);rows.append({'arm_feature':name,'obstacle':name2,'gap_bound_mm':float(g[i]),'q_deg':float(np.rad2deg(Q[i])),'rack_mm':float(R[i]),'steer_deg':float(np.rad2deg(D[i]))})
rows.sort(key=lambda r:r['gap_bound_mm']);(P/'new_arms_dense_capsule_check.json').write_text(json.dumps({'scope':'Conservative enclosing capsules for original new-arm tube,eye,housing and lower shock structure versus finalY772 lever,wholeOD32tie andouterfork. Capsule overlap is inconclusive, not an actual solid collision. Front-left convention; mirrored upper/lower tube geometry covers other corners apart from tiny axial bore/housing handed details, which exact motion tests cover.','states':len(Q),'rows':rows},indent=2));print(json.dumps(rows[:12],indent=2))
