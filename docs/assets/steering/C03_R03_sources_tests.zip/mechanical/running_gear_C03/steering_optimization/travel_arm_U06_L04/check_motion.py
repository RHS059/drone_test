"""Separate new-arm travel check. Frozen C03R01 artifacts are read only.
No private motor is loaded. q/r are coupled with the existing tie closure.
"""
from pathlib import Path
import sys,json,math,hashlib,time
import numpy as np
import cadquery as cq
P=Path(__file__).parent;OPT=P.parent;C=OPT.parent;C2=C.parent/'running_gear_C02';BASE=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(OPT));from search import solve
from OCP.BRepExtrema import BRepExtrema_DistShapeShape

def load(p):return cq.importers.importStep(str(p)).val()
def bd(s):
 b=s.BoundingBox();return np.array([b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax])
def bboxgap(a,b):return float(np.linalg.norm(np.maximum(0,np.maximum(a[:3]-b[3:],b[:3]-a[3:]))))
def distance(s,t):
 d=BRepExtrema_DistShapeShape();d.SetMultiThread(False);d.LoadS1(s.wrapped);d.LoadS2(t.wrapped);d.Perform();return d.Value()
def proper(s,side):return s if side==1 else s.rotate((0,0,0),(0,0,1),180)
def rz(a,t):return np.array([a[0]*np.cos(t)-a[1]*np.sin(t),a[0]*np.sin(t)+a[1]*np.cos(t),a[2]])
def cylinder(a,b,rad):
 v=b-a;return cq.Solid.makeCylinder(rad,float(np.linalg.norm(v)),cq.Vector(*a),cq.Vector(*(v/np.linalg.norm(v))))
def test(s,t,label,exact_limit=25):
 b0,b1=bd(s),bd(t);g=bboxgap(b0,b1)
 if g>1e-6:return {'pair':label,'clearance_mm':g,'clearance_type':'conservative_AABB_lower_bound','overlap_mm3':0.0}
 common=s.intersect(t);v=common.Volume()
 return {'pair':label,'clearance_mm':0.0,'clearance_type':'Boolean_volume_check_only_gap_not_evaluated','overlap_mm3':v,'common_face_count':len(common.Faces()),'common_edge_count':len(common.Edges())}

U=load(C/'upper_wishbone_C03_R06.step');L=load(C/'lower_wishbone_C03_R04.step');W=load(BASE/'wheels/rim_C01.step');RES=cq.Workplane('XZ',origin=(0,170,0)).circle(438.15).circle(228.6).extrude(340).val();pin=load(C/'outer_pins_left_C03_R01.step');rows=[];fail=[];start=time.time()
a=np.array([-289.,-90,-85]);K=np.array([0.,812,-250]);v=np.array([0.,262,-150]);T=np.array([72.,262,-150]);Ltie=np.linalg.norm(T)
# Known former lever minimum first, then upper full-bump/lock region, followed by remaining endpoint/neutral grid.
states=[(-12,-75),(12,-75),(12,75),(-12,75),(0,-75),(0,75),(-12,0),(12,0),(0,0)]
for fore,side in [(1,1),(1,-1),(-1,1),(-1,-1)]:
 label=('front' if fore==1 else 'rear')+'_'+('left' if side==1 else 'right');station=fore*1350;sn='left' if side==1 else 'right'
 carrier=load(C/('steering_upright_'+('rear_'if fore<0 else '')+sn+'_C03_R05.step')).translate((station,0,0))
 un=proper(U,side).translate((station,0,0));ln=proper(L,side).translate((station,0,0));wn=proper(W,side).translate((station,side*940,-250));resn=proper(RES,side).translate((station,side*940,-250));pn=proper(pin,side).translate((station,0,0));king=np.array([station,side*812,-250.])
 for q,r in states:
  qr=np.deg2rad(q);dv=np.array([0.,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150]);d,_,_=solve(a,72,np.array([qr]),np.array([side*r]),np.array([dv]));d=float(fore*side*d[0]);delta=dv*np.array([1,side,1]);dd=np.rad2deg(d)
  u=un.rotate((station,side*550,70),(station+1,side*550,70),side*q);l=ln.rotate((station,side*550,-270),(station+1,side*550,-270),side*q)
  c=carrier.rotate(tuple(king),tuple(king+[0,0,1]),dd).translate(tuple(delta));w=wn.rotate(tuple(king),tuple(king+[0,0,1]),dd).translate(tuple(delta));pins=pn.rotate(tuple(king),tuple(king+[0,0,1]),dd).translate(tuple(delta));resq=resn.rotate(tuple(king),tuple(king+[0,0,1]),dd).translate(tuple(delta))
  inn=np.array([fore*989,side*460+r,-185.]);outer=king+delta+rz(a*np.array([fore,side,1]),d);assert abs(np.linalg.norm(outer-inn)-Ltie)<1e-6
  axis=(outer-inn)/Ltie
  tube=cylinder(inn+axis*47.625,outer-axis*47.625,16);tie_edge=cq.Edge.makeLine(cq.Vector(*inn),cq.Vector(*outer))
  for arm,s in [('upper',u),('lower',l)]:
   for target,t in [('carrier_R05',c),('rim_C01',w),('reserved_tire_340',resq),('actual_outer_joint_pins',pins),('actual_tie_OD32',tube)]:
    result=test(s,t,arm+'__'+target);result.update(corner=label,q_deg=q,rack_mm=r,steer_deg=dd);rows.append(result)
    if result['overlap_mm3']>1e-4:fail.append(result)
   dense=json.loads((P/'new_arms_dense_capsule_check.json').read_text());g=min(x['gap_bound_mm'] for x in dense['rows'] if x['obstacle']=='whole_tie' and x['arm_feature'].startswith(arm));rows.append({'corner':label,'q_deg':q,'rack_mm':r,'steer_deg':dd,'pair':arm+'__whole_tie_OD32_capsule','clearance_mm':g,'clearance_type':'conservative_feature_capsule_dense_domain_bound','overlap_mm3':None})
  print(label,q,r,dd,'failures',len(fail),'min state',min(x['clearance_mm']for x in rows[-12:]),flush=True)
  report={'scope':'New upperR06/lowerR04 actual B-reps vs current handed carrierR05, actual rimC01 and the conservative340mm tyre annulus, actual outer joint pins and actual/swept-reservation tie, coupled q/r endpoints and neutral. Correct properRz(pi) common right parts; common rear parts keep same side orientation. No private motor or load qualification.','new_sources':{n:hashlib.sha256((C/(n+'.step')).read_bytes()).hexdigest()for n in ['upper_wishbone_C03_R06','lower_wishbone_C03_R04']},'rows':rows,'failures':fail,'elapsed_s':time.time()-start,'planned_states':36,'completed_states':len(rows)//12}
  (P/'new_arms_motion_check.json').write_text(json.dumps(report,indent=2))
print('COMPLETE',len(rows),'fail',len(fail),flush=True)
