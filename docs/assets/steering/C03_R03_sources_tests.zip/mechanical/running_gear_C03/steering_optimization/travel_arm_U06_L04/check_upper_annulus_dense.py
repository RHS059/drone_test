from geometry_common import *
from scipy.optimize import minimize
import search_packageable_75 as m
Q,R=np.meshgrid(np.deg2rad(np.linspace(-12,12,97)),np.linspace(-75,75,301),indexing='ij');Q=Q.ravel();R=R.ravel();DV=np.array([np.zeros_like(Q),262*np.cos(Q)+150*np.sin(Q)-262,262*np.sin(Q)-150*np.cos(Q)+150]).T;a=np.array([-289.,-90,-85]);D,_,_=solve(a,72,Q,R,DV);KING=np.array([0.,812,-250]);segments=[]
for x in [-170,170]:
 pts=[(x,550,70),(x,625,100),(x/2,600,120),(0,760,-80)]
 for j,(p,b)in enumerate(zip(pts[:-1],pts[1:])):segments.append((f'branch_{x}_{j}',np.array(p,float),np.array(b,float)))
segments.append(('neck',np.array([0.,760,-80]),np.array([0.,812,-80])))
def world_to_wheel(A,Q,D,DV):
 p=A-[0,550,70];w=np.array([np.full_like(Q,p[0]),p[1]*np.cos(Q)-p[2]*np.sin(Q)+550,p[1]*np.sin(Q)+p[2]*np.cos(Q)+70]).T-(KING+DV)
 return np.array([w[:,0]*np.cos(D)+w[:,1]*np.sin(D),-w[:,0]*np.sin(D)+w[:,1]*np.cos(D)-128,w[:,2]]).T

def gap_points(P):
 rad=np.hypot(P[:,0],P[:,2]);dr=np.maximum(0,np.maximum(228.6-rad,rad-438.15));dy=np.maximum(0,abs(P[:,1])-170);return np.hypot(dr,dy)-16
rows=[]
for name,A,B in segments:
 aa=world_to_wheel(A,Q,D,DV);bb=world_to_wheel(B,Q,D,DV);mind=np.full_like(Q,np.inf);mint=np.zeros_like(Q);N=129
 for t in np.linspace(0,1,N):
  g=gap_points(aa+(bb-aa)*t);better=g<mind;mind=np.minimum(mind,g);mint[better]=t
 idx=int(np.argmin(mind));h=float(np.linalg.norm(B-A)/(2*(N-1)));row={'segment':name,'start_nominal_mm':A.tolist(),'end_nominal_mm':B.tolist(),'sampled_centerline_minus16_gap_mm':float(mind[idx]),'along_segment_sampling_error_bound_mm':h,'conservative_segment_gap_bound_at_sampled_poses_mm':float(mind[idx]-h),'q_deg':float(np.rad2deg(Q[idx])),'rack_mm':float(R[idx]),'segment_t':float(mint[idx])}
 # Refine q,r,t continuously from the worst dense-grid point; local bounded minimization is not an interval proof.
 def obj(x):
  qr=np.deg2rad(x[0]);dv=np.array([[0.,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150]]);d,_,_=solve(a,72,np.array([qr]),np.array([x[1]]),dv);pp=world_to_wheel(A+(B-A)*x[2],np.array([qr]),d,dv);return float(gap_points(pp)[0])
 opt=minimize(obj,[row['q_deg'],row['rack_mm'],row['segment_t']],method='Nelder-Mead',bounds=[(-12,12),(-75,75),(0,1)],options={'xatol':1e-9,'fatol':1e-9,'maxiter':1000});row['refined_candidate']={'q_deg':float(opt.x[0]),'rack_mm':float(opt.x[1]),'segment_t':float(opt.x[2]),'centerline_minus16_gap_mm':float(opt.fun),'success':bool(opt.success)};rows.append(row);print(row,flush=True)
rows.sort(key=lambda x:x['refined_candidate']['centerline_minus16_gap_mm']);report={'source_upper_sha256':hashlib.sha256((C/'upper_wishbone_C03_R06.step').read_bytes()).hexdigest(),'scope':'Seven OD32 upper-arm tube centerline capsules only. Unchanged root eyes/housing excluded. Dense97q x301rack x129 points/segment, analytic distance in yawed wheel frame to radial band[228.6,438.15] and axial[-170,170], minus16mm. Per-segment spatial sample error bound is subtracted separately. Continuous local refinement identifies candidates but does not certify unsampled q/r intervals.','sampled_pose_count':len(Q),'rows':rows};(P/'upper_annulus_dense_check.json').write_text(json.dumps(report,indent=2))
