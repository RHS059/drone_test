"""Independent q=0/rack=0 C03-to-S01 static fit only. No source edits or sequence/load approval."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).parent.parent))
from verify_exact import *
P=Path(__file__).parent
import hashlib,time
S=Path(str(Path(__file__).resolve().parents[4]/'service-fixtures'));t0=time.time()
def bounds(s):
 b=s.BoundingBox();return np.array([b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax])
def boxdist(a,b):
 return float(np.linalg.norm(np.maximum(0,np.maximum(a[:3]-b[3:],b[:3]-a[3:]))))
def named_solids(stem):
 sh=load(S/(stem+'.step'));meta=json.loads((S/(stem+'_verification.json')).read_text());sol=sh.Solids();assert len(sol)==len(meta['parts']);out=[]
 for i,(s,p) in enumerate(zip(sol,meta['parts'])):
  assert np.max(np.abs(bounds(s)-np.array(p['bounds_mm'])))<1e-4,(stem,i,'name mapping bounds mismatch')
  out.append((p['name'],s))
 return out
cradle=named_solids('corner_cradle_S01');trestle=named_solids('chassis_trestles_S01')
fixtures=[('trestles/'+n,s,bounds(s))for n,s in trestle]
for station in [-1350,1350]:
 for side in [-1,1]:
  for n,s in cradle:
   ss=s if side==1 else s.rotate((0,0,0),(0,0,1),180)
   ss=ss.translate((station,0,0));fixtures.append((f'cradle_{station}_{side}/'+n,ss,bounds(ss)))

# Load final baked geometry directly. No per-side or fore/aft transforms are applied here.
manifest=json.loads((C/'original_steering_C03_R03_manifest.json').read_text())
assembly_path=C/'original_steering_C03_R03.step'
assembly=load(assembly_path);solids=assembly.Solids();nodes=manifest['assembly_nodes']
assert len(nodes)==76 and len(solids)==sum(n['solid_count']for n in nodes)==202
allparts=[];audit=[];idx=0
for node in nodes:
 chunk=solids[idx:idx+node['solid_count']];idx+=node['solid_count'];s=chunk[0] if len(chunk)==1 else cq.Compound.makeCompound(chunk)
 vol=s.Volume()*1e-9;center=np.array(s.Center().toTuple())*1e-3
 ve=abs(vol-node['volume_m3']);ce=float(np.max(np.abs(center-np.array(node['com_m']))))
 assert ve<max(1e-10,node['volume_m3']*1e-6),(node['node'],'volume mapping mismatch',ve)
 assert ce<1e-6,(node['node'],'center mapping mismatch',ce)
 audit.append({'node':node['node'],'solid_count':len(chunk),'volume_delta_m3':ve,'COM_max_delta_m':ce})
 allparts.append((node['node'],s,0))
# Optional conservative purchased-head and full-tie reservations are additional to the baked original assembly.
for fore in [-1,1]:
 for side in [-1,1]:
  label=('front' if fore==1 else 'rear')+'_'+('left' if side==1 else 'right')
  I=np.array([fore*989,side*460,-185.]);O=np.array([fore*1061,side*722,-335.])
  for tag,point in [('inner',I),('outer',O)]:allparts.append((label+'_'+tag+'_head_reservation_OD44_45',cq.Solid.makeSphere(22.225,cq.Vector(*point),angleDegrees1=-90,angleDegrees2=90),0))
  allparts.append((label+'_whole_tie_OD32_capsule',edge(I,O),16))
rows=[];overlaps=[];contacts=[]
assembly_sha256=hashlib.sha256(assembly_path.read_bytes()).hexdigest()
for name,s,reserve in allparts:
 b=bounds(s);best=float('inf');nearest=None;tests=0;checks=0;partov=[];partcontacts=[]
 candidates=sorted([(boxdist(b,fb),fn,fs,fb) for fn,fs,fb in fixtures],key=lambda x:x[0])
 conservative_only=candidates[0][0]-reserve>=50
 if conservative_only:best=candidates[0][0];nearest=candidates[0][1]
 for lower,fn,fs,fb in ([] if conservative_only else candidates):
  # Exact distance to every potential nearer solid, using admissible AABB lower bound.
  if lower>best+1e-7:continue
  g=dist(s,fs);tests+=1
  if g<best:best=g;nearest=fn
  if lower<1e-7 and reserve==0:
   ov=s.intersect(fs).Volume();checks+=1
   if ov>1e-4:partov.append({'fixture':fn,'overlap_mm3':ov})
   elif g<1e-5:partcontacts.append(fn)
 row={'component':name,'minimum_clearance_mm':best-reserve,'nearest_fixture_solid':nearest,'exact_distance_pairs_evaluated':tests,'boolean_pairs_evaluated':checks,'intersections':partov,'contacts':partcontacts,'conservative_radius_reservation_mm':reserve,'clearance_value_type':'conservative_AABB_lower_bound' if conservative_only else 'exact_minimum_or_centerline_minus_radius'};rows.append(row)
 if partov:overlaps.append(row)
 if partcontacts:contacts.append(row)
 print(name,'gap',round(best-reserve,6),'overlap',partov,flush=True)
 result={'scope':'FINAL BAKED ASSEMBLY: q=0/rack=0; all76 manifest nodes/202 original solids plus12 conservative reservations, all four S01 front/rear cradle placements and already-global trestles. No operation or load approval.','placement':'S01 right cradle uses proper Rz(pi), then station translation. C03 geometry is loaded directly from the baked final STEP; no inferred corner transforms are applied.','method':'Conservative AABB separation certifies components with minimum bound>=50mm; closer components receive exact B-rep distances and overlap tests for all candidate intersections.','source_fixture_contract':str(S/'service_interface_contract_S01.json'),'fixture_solid_count':len(fixtures),'components_checked':len(rows),'required_components':len(allparts),'rows':rows,'positive_volume_failures':overlaps,'zero_gap_contacts':contacts,'assembly_step':str(assembly_path),'assembly_sha256':assembly_sha256,'assembly_manifest':str(C/'original_steering_C03_R03_manifest.json'),'manifest_node_count':76,'baked_solid_count':202,'manifest_mapping_audit':audit,'separate_revision':'New U06/L04 travel revision; frozen R01 files are unchanged','blocked_operations':'The installed wheel already obstructs the old axial extraction corridor. Wheel-first and a new positive support/isolation sequence remain unresolved. This check does not reapprove the old C02 two-pin removal boundary.','elapsed_s':time.time()-t0}
 (P/'S01_C03_R03_baked_assembly_compatibility.json').write_text(json.dumps(result,indent=2))
print('COMPLETE',len(rows),'failures',len(overlaps),'contacts',len(contacts),'minimum',min(r['minimum_clearance_mm']for r in rows),flush=True)
