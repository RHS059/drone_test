"""Separate new-arm travel check. Frozen C03R01 artifacts are read only.
No private motor is loaded. q/r are coupled with the existing tie closure.
"""
from pathlib import Path
import sys,json,math,hashlib,time
import numpy as np
import cadquery as cq
P=Path(__file__).parent;OPT=P.parent;C=OPT.parent;C2=C.parent/'running_gear_C02';BASE=Path(__file__).resolve().parents[4]
sys.path.insert(0,str(OPT));from search import solve
from OCP.BRepExtrema import BRepExtrema_DistShapeShape

def load(p):return cq.importers.importStep(str(p)).val()
def bd(s):
 b=s.BoundingBox();return np.array([b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax])
def bboxgap(a,b):return float(np.linalg.norm(np.maximum(0,np.maximum(a[:3]-b[3:],b[:3]-a[3:]))))
def distance(s,t):
 d=BRepExtrema_DistShapeShape();d.SetMultiThread(False);d.LoadS1(s.wrapped);d.LoadS2(t.wrapped);d.Perform();return d.Value()
def proper(s,side):return s if side==1 else s.rotate((0,0,0),(0,0,1),180)
def rz(a,t):return np.array([a[0]*np.cos(t)-a[1]*np.sin(t),a[0]*np.sin(t)+a[1]*np.cos(t),a[2]])
def cylinder(a,b,rad):
 v=b-a;return cq.Solid.makeCylinder(rad,float(np.linalg.norm(v)),cq.Vector(*a),cq.Vector(*(v/np.linalg.norm(v))))
def test(s,t,label,exact_limit=25):
 b0,b1=bd(s),bd(t);g=bboxgap(b0,b1)
 if g>1e-6:return {'pair':label,'clearance_mm':g,'clearance_type':'conservative_AABB_lower_bound','overlap_mm3':0.0}
 common=s.intersect(t);v=common.Volume()
 return {'pair':label,'clearance_mm':0.0,'clearance_type':'Boolean_volume_check_only_gap_not_evaluated','overlap_mm3':v,'common_face_count':len(common.Faces()),'common_edge_count':len(common.Edges())}
