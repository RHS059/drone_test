from pathlib import Path
import json,hashlib
import cadquery as cq
import struct
import numpy as np
P=Path(__file__).parent
m=json.loads((P/'original_steering_C03_R03_manifest.json').read_text())
s=cq.importers.importStep(str(P/'original_steering_C03_R03.step')).val()
b=(P/'original_steering_C03_R03.glb').read_bytes(); n=struct.unpack_from('<I',b,12)[0]; g=json.loads(b[20:20+n]); assert all(not any(k in x for k in ['matrix','translation','rotation','scale']) for x in g['nodes']); pos=[g['accessors'][p['attributes']['POSITION']] for m in g['meshes'] for p in m['primitives']]; bounds=[np.min([a['min'] for a in pos],axis=0).tolist(),np.max([a['max'] for a in pos],axis=0).tolist()]
expected={x['node'] for x in m['assembly_nodes']}
actual={x['name'] for x in g['nodes'] if 'mesh' in x}
r={'configuration':'C03_R03','units':'metres','up':'Z','node_count':len(actual),'manifest_names_match':actual==expected,'bounds_m':bounds,'all_node_BReps_valid':all(x.isValid() for x in s.Solids()),'BRep_solid_count':len(s.Solids()),'filled_purchased_envelopes_included':False,'hashes':{f:hashlib.sha256((P/f).read_bytes()).hexdigest() for f in ['original_steering_C03_R03.step','original_steering_C03_R03.glb','original_steering_C03_R03_manifest.json']}}
assert r['manifest_names_match'] and r['node_count']==76 and r['BRep_solid_count']==202 and r['all_node_BReps_valid'],r
(P/'original_steering_C03_R03_export_check.json').write_text(json.dumps(r,indent=2));print(r)
