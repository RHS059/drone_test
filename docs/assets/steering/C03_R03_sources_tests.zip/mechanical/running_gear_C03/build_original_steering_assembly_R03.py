"""Assemble original C03 parts in vehicle C at nominal pose. Purchased hardware is not fabricated.
STEPmm/GLBm. Does not include private drive geometry or fill reference bearings as physical material.
"""
from pathlib import Path
import sys,json,hashlib,math
import numpy as np
import cadquery as cq
P=Path(__file__).parent;C2=P.parent/'running_gear_C02';sys.path.insert(0,str(P.parent));from generate_cad import glb,properties
parts=[];manifest=[];cache={}
def load(folder,name):
 key=str(folder/name)
 if key not in cache:cache[key]=cq.importers.importStep(key+'.step').val()
 return cache[key]
def add(name,s,group,source,density=7850):
 parts.append((name,s));manifest.append({'node':name,'motion_group':group,'source_step':str(source.relative_to(P.parent))+'.step','valid':s.isValid(),'solid_count':len(s.Solids()),**properties(s,density=density)})
def proper_side(s,side):return s if side==1 else s.rotate((0,0,0),(0,0,1),180)
def align_z(s,n):
 n=np.array(n,float);n/=np.linalg.norm(n);axis=np.cross([0,0,1],n);ang=math.degrees(math.acos(np.clip(n[2],-1,1)))
 return s if abs(ang)<1e-10 else s.rotate((0,0,0),tuple(axis),ang)
for fore in [-1,1]:
 for side in [-1,1]:
  station=fore*1350;label=('front' if fore==1 else 'rear')+'_'+('left' if side==1 else 'right');sn='left' if side==1 else 'right'
  clamp='stationary_clamp_'+('front' if fore==1 else 'rear')+'_'+sn+'_C03_R03'
  add(label+'_clamp',load(P,clamp).translate((station,0,0)),label+'_fixed',P/clamp)
  for base,group in [('inner_backing_C02_R01','fixed'),('stationary_hardware_C02_R01','fixed')]:add(label+'_'+base,proper_side(load(C2,base),side).translate((station,0,0)),label+'_'+group,C2/base)
  for base,group in [('upper_wishbone_C03_R06','upper'),('lower_wishbone_C03_R04','lower'),('outer_pins_left_C03_R01','steer')]:add(label+'_'+base,proper_side(load(P,base),side).translate((station,0,0)),label+'_'+group,P/base)
  base='steering_upright_'+('rear_' if fore==-1 else '')+sn+'_C03_R05';add(label+'_upright',load(P,base).translate((station,0,0)),label+'_steer',P/base)
  for z,group in [(-80,'upper'),(-420,'lower')]:
   base='housing_retainer_C03_R01';s=load(P,base).translate((0,812,z));add(label+'_retainer_'+group,proper_side(s,side).translate((station,0,0)),label+'_'+group,P/base)
  base='wheel_adapter_C02_R02';s=load(C2,base).rotate((0,0,0),(1,0,0),-90).translate((0,928,-250));add(label+'_wheel_adapter',proper_side(s,side).translate((station,0,0)),label+'_spin',C2/base)
  I=np.array([fore*989,side*460,-185]);O=np.array([fore*1061,side*722,-335]);T=O-I;n=[0,side*150,262]
  for base in ['tie_tube_C03_R02','tie_insert_RH_C03_R02','tie_insert_LH_C03_R02']:
   add(label+'_'+base,align_z(load(P,base),T).translate(tuple(I)),label+'_tie',P/base)
  for where,pos,g in [('inner',I,('front' if fore==1 else 'rear')+'_rack'),('outer',O,label+'_steer')]:
   base='tie_clevis_pin_C03_R01';add(label+'_'+where+'_tie_pin',align_z(load(P,base),n).translate(tuple(pos)),g,P/base)
for fore in [-1,1]:
 label='front' if fore==1 else 'rear';r=json.loads((P/'rack_C03_R11_report.json').read_text())
 for p in r['parts']:
  base=p['part'];s=load(P,base);s=s if fore==1 else s.mirror('YZ')
  add(label+'_'+base,s,label+('_rack' if p['group']=='rack_translation_Y' else '_rack_fixed'),P/base,p['density_kg_m3'])
 base='rack_mount_hardware_C03_R03';s=load(P,base);s=s if fore==1 else s.mirror('YZ');add(label+'_rack_fasteners',s,label+'_rack_fixed',P/base)
ass=cq.Assembly(name='original_steering_C03_R03')
for n,s in parts:ass.add(s,name=n)
ass.export(str(P/'original_steering_C03_R03.step'));glb(parts,P/'original_steering_C03_R03.glb')
r={'configuration':'C03 original four-corner steering candidate R03','status':'Development CAD, no fabrication/operation release','units':{'STEP':'mm','GLB':'m'},'axes':'Xforward,Yleft,Zup','pose':'q0,rack0,unloaded','included':'Original fabricated CAD and nominal pin/bolt geometry only, four steering corners/two guided racks','excluded':['Middle fixed C02 corners','Frame/body/wheels','All private drive CAD','Physical purchased bearings/spacers/rod ends','Actuator and coilover bodies','Unselected retainers and locking hardware'],'mass_kg_original_geometry_subtotal':sum(x['mass_kg'] for x in manifest),'assembly_nodes':manifest}
(P/'original_steering_C03_R03_manifest.json').write_text(json.dumps(r,indent=2));print('nodes',len(parts),'original mass',r['mass_kg_original_geometry_subtotal'],flush=True)
