"""Bind completed selected-revision evidence without changing frozen CAD."""
from pathlib import Path
import json,hashlib
P=Path(__file__).parent; D=P/'steering_optimization/travel_arm_U06_L04'
r=json.loads((P/'interface_contract_C03_R03.json').read_text())
m=json.loads((D/'new_arms_motion_check.json').read_text());assert m['completed_states']==m['planned_states']==36 and not m['failures']
e=json.loads((D/'new_arms_environment_check.json').read_text());assert not e['failures']
f=json.loads((D/'S01_C03_R03_baked_assembly_compatibility.json').read_text());assert f['components_checked']==88 and not f['positive_volume_failures'] and not f['zero_gap_contacts']
a=json.loads((P/'original_steering_C03_R03_export_check.json').read_text());assert a['all_node_BReps_valid'] and a['manifest_names_match']
c=json.loads((P/'audit_evidence_C03_R03/C03_R03-private-composite-summary.json').read_text())
assert c['motor_fit_status'].startswith('PASS') and c['counts_kept_separate']['composed_sampled_motor_cases']==36
root=json.loads((D/'root_hardware_audit/root_hardware_upper_lower_clamp_audit.json').read_text());assert root['status']=='complete' and not root['positive_volume_failures']
r['new_revision_tests'].update({'status':'Selected original geometry sampled tests complete; detailed reports control scope','original_part_motion':'steering_optimization/travel_arm_U06_L04/new_arms_motion_check.json','original_part_environment':'steering_optimization/travel_arm_U06_L04/new_arms_environment_check.json','dense_tire_screen':'steering_optimization/travel_arm_U06_L04/upper_annulus_dense_check.json','nominal_tire_reservation_minimum_mm':3.011783908581865,'nominal_clamp_minimum_mm':3.0,'clearance_limitations':'Nominal unloaded CAD only. Approximately 3 mm local margins are unqualified for tolerance stack, weld distortion, tire variation, mud or elastic deflection. Discrete checks and locally refined analytic screens do not prove continuous swept clearance.'})
r['independent_private_motor_review']='Composite 36-pose sampled fit evidence bound to the selected R03 export: unchanged R01 component checks plus fresh upper R06/lower R04 arm checks. See audit_evidence_C03_R03/C03_R03-private-composite-summary.json. No vendor geometry included.'
r['service']['fixtures']='Exact baked R03 q0/rack0: 88 component checks (76 original nodes plus 12 reservations) against 302 fixture solids, no overlap/contact. Minimum 8.062146 mm. This does not qualify pin extraction or lifting.'
r['tests']=[dict(x,revision_scope='Inherited unchanged-component or kinematic result; changed-arm scope is in new_revision_tests') for x in r['tests']]
(P/'interface_contract_C03_R03.json').write_text(json.dumps(r,indent=2))
