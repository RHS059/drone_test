from pathlib import Path
import json,csv,math
P=Path(__file__).parent;rows=[]
def segment(part,name,a,b,od=32,wall=3):
 rows.append({'part':part,'segment':name,'start_mm':a,'end_mm':b,'outside_diameter_mm':od,'wall_mm':wall,'centerline_segment_length_mm':math.dist(a,b),'quantity_per_arm':1,'quantity_four_steering_corners':4})
for part,z in [('upper_R06',70),('lower_R04',-270)]:
 neck=[0,760,z-150]
 for x in [-170,170]:
  a=[x,550,z];f=[x,625,100] if z==70 else [x,575,-380];m=[x/2,600,120] if z==70 else [x/2,681,-410]
  for i,(a,b) in enumerate(zip([a,f,m],[f,m,neck])):segment(part,f'branch_{x}_segment_{i+1}',a,b)
 segment(part,'center_neck',neck,[0,812,z-150])
y=720.3
for i,(a,b) in enumerate([([-59.5,y,-367.5],[-24,y,-367.5]),([24,y,-367.5],[59.5,y,-367.5])]):segment('lower_R04',f'shock_crosspiece_{i}',a,b,40,4)
for x in [-42.71519,42.71519]:segment('lower_R04',f'shock_leg_{x}',[x,y,-414.9746835443038],[x,y,-367.5],25,3)
r={'configuration':'C03_R03 selected original arm routes','units':'mm','basis':'Exact parametric cylinder axis endpoints before Boolean unions and housing cuts. Includes four steering corners only; fixed middle arms remain C02.','fabrication_released':False,'manufacturing_warning':'These are centerline segment lengths, not finished saw-cut lengths or coping templates. Tube ends overlap at union joints. End copes, weld preparations, allowances, sequence, fixture datum, distortion and inspection require fabrication drawings and structural qualification. Do not sum raw tube volumes as assembled mass.','segments':rows}
(P/'arm_route_schedule_C03_R03.json').write_text(json.dumps(r,indent=2))
with (P/'arm_route_schedule_C03_R03.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
