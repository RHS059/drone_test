"""Explicit current-revision allowlist layered on frozen public baseline dependencies."""
from pathlib import Path
import json,hashlib,re,zipfile
P=Path(__file__).parent;M=P.parent;REL=M.parent/'releases';BASE=REL/'C03_R01_public';OUT=REL/'C03_R03_public'
files={}
old=json.loads((BASE/'PUBLIC_WHITELIST_SHA256.json').read_text())
skip={'PUBLIC_WHITELIST_SHA256.json','SOURCE_AND_RIGHTS.md','REPRODUCE.md'}
replace=['README_C03_R01.md','interface_contract_C03_R01.json','mass_cost_ledger_C03_R01.json','original_parts_C03_R01.csv','original_steering_C03_R01.step','original_steering_C03_R01.glb','original_steering_C03_R01_manifest.json','original_steering_C03_R01_export_check.json','SHA256_C03_R01.json']
for e in old['entries']:
 f=e['path']
 if f in skip or Path(f).name in replace:continue
 files[f]=BASE/f
# All original source dependencies and historical regression reports above retain their names.
# The authoritative current geometry and contract below supersede baseline arm selection.
new=['interface_contract_C03_R03.json','mass_cost_ledger_C03_R03.json','original_parts_C03_R03.csv','original_steering_C03_R03.step','original_steering_C03_R03.glb','original_steering_C03_R03_manifest.json','original_steering_C03_R03_export_check.json','build_original_steering_assembly_R03.py','write_mass_ledger_C03_R03.py','write_contract_C03_R03.py','finalize_contract_C03_R03.py','prepare_package_C03_R03.py','check_export_C03_R03.py','generate_upper_wishbone_R06.py','generate_lower_wishbone_R04.py','upper_wishbone_C03_R06.step','upper_wishbone_C03_R06.glb','upper_wishbone_C03_R06_report.json','lower_wishbone_C03_R04.step','lower_wishbone_C03_R04.glb','lower_wishbone_C03_R04_report.json','README_C03_R03.md','write_arm_routes_C03_R03.py','arm_route_schedule_C03_R03.json','arm_route_schedule_C03_R03.csv','actuator_followup/actuator_comparison_R01.json']
files['wheels/tire_C01.step']=Path(str(Path(__file__).resolve().parents[2]/'wheels/tire_C01.step'))
# Final evidence is explicitly listed in release_evidence_C03_R03.json; no recursive folder copy.
evidence=json.loads((P/'release_evidence_C03_R03.json').read_text())
new+=['release_evidence_C03_R03.json']+evidence['public_files']
for f in new:
 src=P/f;assert src.is_file(),src;files[str(Path('mechanical/running_gear_C03')/f)]=src
entries=[]
for rel,src in sorted(files.items()):
 data=src.read_bytes();native=hashlib.sha256(data).hexdigest()
 if src.suffix=='.py':
  s=data.decode()
  if '/workspace/shared/ugv-rover-integration' in s:
   depth=4 if '/travel_arm_U06_L04/' in rel else (3 if '/steering_optimization/' in rel else 2)
   s=s.replace("Path(__file__).resolve().parents[2]",f"Path(__file__).resolve().parents[{depth}]")
   s=re.sub(r"(['\"])/workspace/shared/ugv-rover-integration/([^'\"]+)\1",lambda x:f"str(Path(__file__).resolve().parents[{depth}]/"+repr(x[2])+")",s)
  data=s.encode();compile(data,rel,'exec')
 dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
 entries.append({'path':rel,'sha256':hashlib.sha256(data).hexdigest(),'native_sha256':native,'bytes':len(data)})
for name in ['SOURCE_AND_RIGHTS.md']:
 data=(BASE/name).read_bytes();(OUT/name).write_bytes(data);entries.append({'path':name,'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
data=(P/'README_C03_R03.md').read_bytes();(OUT/'REPRODUCE.md').write_bytes(data);entries.append({'path':'REPRODUCE.md','sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
r={'package':'C03_R03 original development checkpoint','proprietary_geometry_included':False,'selected_contract':'mechanical/running_gear_C03/interface_contract_C03_R03.json','historical_dependencies':'R01-named geometry, generators and reports remain solely for reproducibility and unchanged-component regression. Current R03 contract controls selected arm revisions.','entries':entries,'file_count':len(entries)}
(OUT/'PUBLIC_WHITELIST_SHA256.json').write_text(json.dumps(r,indent=2));(P/'PUBLIC_WHITELIST_SHA256_C03_R03.json').write_text(json.dumps(r,indent=2))
zpath=REL/'original_C03_R03_public.zip'
with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for e in entries:z.write(OUT/e['path'],e['path'])
 z.write(OUT/'PUBLIC_WHITELIST_SHA256.json','PUBLIC_WHITELIST_SHA256.json')
with zipfile.ZipFile(zpath) as z:assert z.testzip() is None
receipt={'zip':str(zpath),'sha256':hashlib.sha256(zpath.read_bytes()).hexdigest(),'bytes':zpath.stat().st_size,'file_count':len(entries)+1,'portable_root':str(OUT)}
(P/'public_package_receipt_C03_R03.json').write_text(json.dumps(receipt,indent=2));print(receipt)
