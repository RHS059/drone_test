from pathlib import Path
import json,hashlib
P=Path(__file__).parent
r=json.loads((P/'interface_contract_C03_R01.json').read_text())
r['configuration']='C03_R03 original front/rear steering candidate'
r['assembly_step']='original_steering_C03_R03.step'
r['assembly_glb']='original_steering_C03_R03.glb'
r['assembly_manifest']='original_steering_C03_R03_manifest.json'
for c in r['corners']:c['common_arm_meshes']=['upper_wishbone_C03_R06.glb','lower_wishbone_C03_R04.glb']
r['revision_changes']={'baseline':'Frozen C03_R01','changed_geometry':['Four upper arm instances use upper_wishbone_C03_R06','Four lower arm instances use lower_wishbone_C03_R04'],'unchanged':'All joint hardpoints, purchased interface dimensions, steering solver, rack, carrier and other original assembly components','history':'C03_R02 upper R03 passed motor checks but failed tire clearance. Intermediate upper R04 failed conservative tire reservation; upper R05 failed root-clevis clearance. Their evidence is preserved separately.'}
r['viewer_domain']={'default_suspension_q_rad':[0,0],'rack_translation_m':[-.075,.075],'optional_motion_study':{'suspension_q_rad':r['kinematics']['suspension_q_rad'],'enabled_only_after_final_export_binding':True,'label':'Unqualified kinematic study; sampled clearance only','limitations':['No continuous swept-clearance proof','Approximately 3 mm nominal margins; tolerances and deflection unqualified','No shock, spring, tire deflection or loaded ground-contact equilibrium','No physical operation or fabrication release']},'workshop_pose':'q0 and both racks0'}
r['new_revision_tests']={'status':'PENDING final independent geometry evidence; do not infer pass from inherited R01 reports','upper_step_sha256':hashlib.sha256((P/'upper_wishbone_C03_R06.step').read_bytes()).hexdigest(),'lower_step_sha256':hashlib.sha256((P/'lower_wishbone_C03_R04.step').read_bytes()).hexdigest()}
r['independent_private_motor_review']='New upper R06 checks pending; lower R04 passed 36 sampled poses. Protected OEM geometry is excluded.'
r['service']['fixtures']='New baked R03 neutral fixture check pending; R01 result remains historical only.'
r['mass']='See mass_cost_ledger_C03_R03.json. Original material-density estimates only; purchased unknown masses excluded.'
r['actuator_followup']='actuator_followup/actuator_comparison_R01.json; alternative ratings and dimensional comparison only, no changed actuator selection.'
(P/'interface_contract_C03_R03.json').write_text(json.dumps(r,indent=2))
