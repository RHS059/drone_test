from pathlib import Path
import json,itertools
import cadquery as cq
P=Path(__file__).parent
report=json.loads((P/'rack_C03_R11_report.json').read_text());parts=[]
for item in report['parts']:
 s=cq.importers.importStep(str(P/(item['part']+'.step'))).val();parts.append((item['part'],s,item['group']))
for side in ['left','right']:
 s=cq.importers.importStep(str(P/('stationary_clamp_front_'+side+'_C03_R03.step'))).val().translate((1350,0,0));parts.append(('corner_clamp_'+side,s,'stationary'))
h=cq.importers.importStep(str(P/'rack_mount_hardware_C03_R03.step')).val();parts.append(('rack_hardware',h,'stationary'))
body=cq.importers.importStep(str(Path(__file__).resolve().parents[2]/'body-power/body_power_R01.step')).val()
frame=cq.importers.importStep(str(P.parent/'frame_R07.step')).val()
def near(a,b):
 a,b=a.BoundingBox(),b.BoundingBox()
 return not(a.xmax<b.xmin-1e-6 or b.xmax<a.xmin-1e-6 or a.ymax<b.ymin-1e-6 or b.ymax<a.ymin-1e-6 or a.zmax<b.zmin-1e-6 or b.zmax<a.zmin-1e-6)
rows=[]
for u in [-75,0,75]:
 moved=[(n,s.translate((0,u,0)) if g=='rack_translation_Y' else s,g) for n,s,g in parts]
 for (a,s,ga),(b,t,gb) in itertools.combinations(moved,2):
  if u and ga==gb=='stationary':continue
  if near(s,t):
   v=s.intersect(t).Volume();r={'rack_mm':u,'a':a,'b':b,'overlap_mm3':v};rows.append(r);print(r,flush=True)
 for n,s,g in moved:
  if u and g=='stationary':continue
  for tag,comp in [('body',body),('frame',frame)]:
   for i,t in enumerate(comp.Solids()):
    if near(s,t):
     v=s.intersect(t).Volume();r={'rack_mm':u,'a':n,'b':tag+'_'+str(i),'overlap_mm3':v};rows.append(r);print(r,flush=True)
r={'scope':'Original front rack, source dimension bracket/pin and revised clamp B-reps against body R01/frame R07; actuator actual shape excluded','rows':rows,'failures':[r for r in rows if r['overlap_mm3']>1e-4],'valid':{n:s.isValid() for n,s,g in parts},'solids':{n:len(s.Solids()) for n,s,g in parts}}
(P/'rack_assembly_C03_R11_check.json').write_text(json.dumps(r,indent=2));print('failures',len(r['failures']),flush=True)
