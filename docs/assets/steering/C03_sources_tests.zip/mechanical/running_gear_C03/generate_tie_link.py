"""Original hollow adjustable tie link. Purchased rod ends remain sourced interfaces.
Local Z joins spherical centers at0 and310.3675241mm. Threads are drawing callouts, not helices.
"""
from pathlib import Path
import sys,json
import cadquery as cq
P=Path(__file__).parent;sys.path.insert(0,str(P.parent));from generate_cad import glb,properties,exact_bounds
L=(72**2+262**2+150**2)**.5;A=73.025;engagement=25.4;end=A-engagement;body_length=L-2*end
parts=[]
tube=cq.Workplane('XY',origin=(0,0,end)).circle(16).circle(12).extrude(body_length).val();parts.append(('tie_tube_C03_R02',tube))
for side,z in [('RH',end),('LH',L-end-40)]:
 insert=cq.Workplane('XY',origin=(0,0,z)).circle(12).circle(17.4625/2).extrude(40).val();parts.append(('tie_insert_'+side+'_C03_R02',insert))
report={'status':'Original CAD development, not load or manufacturing release','units':{'STEP':'mm','GLB':'m'},'joint_center_distance_mm':L,'purchased_end_parts':['FK JMX12','FK JMXL12'],'purchased_spacers':'12-10HB, pair per end; mounting pin15.875mm, clamped span46.355mm nominal','body_length_mm':body_length,'nominal_thread_engagement_mm':engagement,'thread_callouts':['3/4-16 UNF RH','3/4-16 UNF LH'],'tap_drill_model_mm':17.4625,'thread_status':'Pilot cylinders only; finished thread form, class and inspection not represented','insert_retention':'Welded to tube after controlled fit; weld throat, process, grade and fatigue not qualified','unknowns':['Actual selected rod-end supplier revision and tolerances','Jam-nut selection and adjustment/tool access','Tube/insert buckling and combined fatigue','Corrosion and spherical-joint lubrication','Full steering/body/drive clearance'], 'parts':[]}
for n,s in parts:
 assert s.isValid();cq.exporters.export(s,str(P/(n+'.step')));glb([(n,s)],P/(n+'.glb'));report['parts'].append({'part':n,'valid':s.isValid(),'bounds_mm':exact_bounds(s),'density_assumption_kg_m3':7850,**properties(s)})
report['pair_intersections_mm3']={a+'__'+b:s.intersect(t).Volume() for i,(a,s) in enumerate(parts) for b,t in parts[i+1:]}
(P/'tie_link_C03_R02_report.json').write_text(json.dumps(report,indent=2));print(report['pair_intersections_mm3'])
