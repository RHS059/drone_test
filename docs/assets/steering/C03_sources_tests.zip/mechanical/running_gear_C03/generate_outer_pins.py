from pathlib import Path
import sys,json
import cadquery as cq
P=Path(__file__).parent;sys.path.insert(0,str(P.parent));from generate_cad import glb,properties
parts=[]
for z in [-80,-420]:
 p=cq.Workplane('YZ',origin=(-43,812,z)).circle(19.05/2).extrude(100)
 p=p.union(cq.Workplane('YZ',origin=(-49,812,z)).circle(14).extrude(6))
 p=p.cut(cq.Workplane('XY',origin=(51,812,z-20)).circle(1.6).extrude(40))
 parts.append((str(z),p.val()))
a=cq.Assembly(name='outer_pins_left_C03_R01')
for n,s in parts:assert s.isValid();a.add(s,name=n)
a.export(str(P/'outer_pins_left_C03_R01.step'));glb(parts,P/'outer_pins_left_C03_R01.glb')
r={'status':'Original pins with real cross-drilled cotter holes; grade, fit, fatigue and actual cotter/washer retention unqualified','pin_diameter_mm':19.05,'shaft_length_mm':100,'head_diameter_mm':28,'head_thickness_mm':6,'cotter_hole_mm':3.2,'density_assumption_kg_m3':7850,**properties(cq.Compound.makeCompound([s for _,s in parts]))}
(P/'outer_pins_left_C03_R01_report.json').write_text(json.dumps(r,indent=2));print(r)
