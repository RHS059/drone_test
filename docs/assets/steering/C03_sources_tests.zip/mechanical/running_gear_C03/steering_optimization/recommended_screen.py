import numpy as np,math,json
import search_packageable_75 as m
from pathlib import Path
P=Path(__file__).parent
x=np.array([-289.,-90,-85,72]);a=x[:3];tx=x[3]
# Dense geometric screening; conservative capsule coverage of original wishbone tubes/eyes/housings and pins.
q,r=np.meshgrid(np.deg2rad(np.linspace(-12,12,97)),np.linspace(-75,75,301),indexing='ij');m.Q=q.ravel();m.R=r.ravel();m.DV=np.array([np.zeros_like(m.Q),262*np.cos(m.Q)+150*np.sin(m.Q)-262,262*np.sin(m.Q)-150*np.cos(m.Q)+150]).T
D,O,I=m.solve(a,tx,m.Q,m.R,m.DV)
vals={};details={}
n=np.array([0.,150,262]);n/=np.linalg.norm(n); lever_segments=[]
for side in [-1,1]:
 aa=a+side*27.3*n;bb=aa+np.array([-115-aa[0],772-(m.K+aa)[1],-(772-(m.K+aa)[1])*150/262]);lever_segments.append((m.K+m.DV+m.rotz(aa,D),m.K+m.DV+m.rotz(bb,D)))
for k,(p,b,rad,z) in enumerate(m.obs):
 if z is not None:
  p=p-np.array([0,550,z]);b=b-np.array([0,550,z]);
  p=np.array([np.full_like(m.Q,p[0]),p[1]*np.cos(m.Q)-p[2]*np.sin(m.Q)+550,p[1]*np.sin(m.Q)+p[2]*np.cos(m.Q)+z]).T
  b=np.array([np.full_like(m.Q,b[0]),b[1]*np.cos(m.Q)-b[2]*np.sin(m.Q)+550,b[1]*np.sin(m.Q)+b[2]*np.cos(m.Q)+z]).T
 else:p=np.broadcast_to(p,O.shape);b=np.broadcast_to(b,O.shape)
 for key,vv in [('tie',m.distance_segments(I,O,p,b)-rad-16),('outer_fork',m.distance_segments(O,O+1e-6,p,b)-rad-37.2),('outer_head',m.distance_segments(O,O+1e-6,p,b)-rad-22.225),('inner_head',m.distance_segments(I,I+1e-6,p,b)-rad-22.225)]+[('lever'+str(ii),m.distance_segments(la,lb,p,b)-rad-17) for ii,(la,lb) in enumerate(lever_segments)]:
  idx=np.argmin(vv);label=f'{key}_obstacle{k}'
  vals[label]=float(vv[idx]);details[label]={'clearance_mm':float(vv[idx]),'q_deg':float(np.rad2deg(m.Q[idx])),'rack_mm':float(m.R[idx]),'steer_deg':float(np.rad2deg(D[idx])),'obstacle_segment_a':m.obs[k][0].tolist(),'obstacle_segment_b':m.obs[k][1].tolist(),'obstacle_radius':rad}
T=np.array([tx,262,-150]);L=np.linalg.norm(T);u0=T/L;u=(O-I)/L;k=np.cross(np.broadcast_to(u0,u.shape),u);c=u@u0
N=n+np.cross(k,n)+np.cross(k,np.cross(k,n))/(1+c)[:,None]
ni=np.rad2deg(np.arccos(np.clip(N@n,-1,1)));no=np.rad2deg(np.arccos(np.clip(np.sum(N*m.rotz(n,D),axis=1),-1,1)));JA=m.rotz(np.array([-a[1],a[0],0]),D);moment=abs(np.sum(u*JA,axis=1))
res={'x':x.tolist(),'tie_length_mm':float(L),'states':len(D),'minimum_screen':sorted(details.items(),key=lambda x:x[1]['clearance_mm'])[:15],'all_minima':details,'max_inner_tilt_deg':float(ni.max()),'max_outer_tilt_deg':float(no.max()),'min_moment_arm_mm':float(moment.min()),'max_closure_error_mm':float(abs(np.linalg.norm(O-I,axis=1)-L).max()),'min_abs_full_rack_steer_deg':float(np.rad2deg(abs(D.reshape(97,301)[:,[0,-1]])).min()),'max_abs_steer_deg':float(np.rad2deg(abs(D)).max()),'zero_rack_max_abs_steer_deg':float(abs(np.rad2deg(D.reshape(97,301)[:,150])).max())}
(P/'recommended_dense_screen.json').write_text(json.dumps(res,indent=2));print(json.dumps({k:v for k,v in res.items() if k!='all_minima'},indent=2))
