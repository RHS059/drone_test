from verify_exact import *
from scipy.optimize import minimize_scalar
x=np.array([-289.,-90,-85,72]);a=x[:3];tx=x[3];H=load(C2/'stationary_hardware_C02_R01.step').Solids()[2]
def tie(q,r=-75):
 qr=np.deg2rad(q);dv=np.array([0,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150]);d,o,i=solve(a,tx,np.array([qr]),np.array([r]),np.array([dv]));return d[0],o[0],i[0],dv

def gap(q):
 d,o,i,dv=tie(q);return dist(edge(i,o),H)-16
opt=minimize_scalar(gap,bounds=(-12,12),method='bounded',options={'xatol':.001});print('root',opt.x,opt.fun,flush=True)
W=load(Path(str(Path(__file__).resolve().parents[3]/'wheels/wheel_C01.step'))).translate((0,940,-250));F=lever(a)
res={'actual_root_pin_minimum':{'q_deg':float(opt.x),'rack_mm':-75,'clearance_mm':float(opt.fun)},'outer_lever_to_wheel_gap_mm':dist(F,W),'wheel_note':'Source-backed original C01 wheel, provisional317.5mm width; tire section on8.5in rim not manufacturer-verified.'}
print('lever wheel',res['outer_lever_to_wheel_gap_mm'],flush=True)
# Wheel-relative geometry makes lever clearance invariant; tie moves across yaw/travel.
for q,r in [(-12,-75),(0,-75),(12,-75),(-12,75),(0,75),(12,75),(0,0)]:
 d,o,i,dv=tie(q,r)
 # Transform whole tie back into unsteered wheel frame to avoid repeatedly moving complex STEP.
 oi=rotz(o-(K+dv),np.array([-d]))[0]+K;ii=rotz(i-(K+dv),np.array([-d]))[0]+K
 g=dist(edge(ii,oi),W)-16;gh=dist(cq.Vertex.makeVertex(*oi),W)-22.225
 res.setdefault('tie_wheel_rows',[]).append({'q':q,'rack':r,'tube_gap_mm':g,'outer_head_gap_mm':gh});print(q,r,g,gh,flush=True)
(P/'recommended_root_and_wheel.json').write_text(json.dumps(res,indent=2))
