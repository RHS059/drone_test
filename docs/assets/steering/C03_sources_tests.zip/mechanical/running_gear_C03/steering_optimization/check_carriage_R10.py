from verify_exact import *
a=np.array([-289.,-90,-85]);T=np.array([72.,262,-150]);L=np.linalg.norm(T);u0=T/L;n0=np.array([0.,150,262]);n0/=np.linalg.norm(n0);car=load(C/'rack_carriage_C03_R11.step').translate((-1350,0,0));rows=[]
PIN=load(C/'tie_clevis_pin_C03_R01.step').rotate((0,0,0),(1,0,0),-math.degrees(math.atan2(150,262)))
def cyl_between(a,b,r):
 d=b-a;return cq.Solid.makeCylinder(r,float(np.linalg.norm(d)),cq.Vector(*a),cq.Vector(*(d/np.linalg.norm(d))))
for q in [-12,0,12]:
 qr=np.deg2rad(q);dv=np.array([0,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150])
 for r in [-75,0,75]:
  ds,outs,inns=solve(a,72,np.array([qr]),np.array([r]),np.array([dv]));dd=ds[0];o=outs[0];i=inns[0];u=(o-i)/L;N=rotation_align(u0,u)@n0;Cq=car.translate((0,r,0))
  shapes={'head_housing_cylinder':cyl_between(i-N*17.4498/2,i+N*17.4498/2,22.225),'shank_19_05mm':cyl_between(i,i+47.625*u,9.525),'tube_OD32mm':cyl_between(i+47.625*u,o-47.625*u,16)}
  row={'q_deg':q,'rack_mm':r,'steer_deg':float(np.rad2deg(dd))}
  pin=PIN.translate(tuple(i));row['pin_carriage_overlap_mm3']=pin.intersect(Cq).Volume();row['pin_carriage_gap_mm']=dist(pin,Cq)
  for label,s in shapes.items():
   row[label+'_overlap_mm3']=s.intersect(Cq).Volume();row[label+'_gap_mm']=dist(s,Cq)
  rows.append(row);print(row,flush=True)
  if q==0 and r==0:
   for n,s in shapes.items():cq.exporters.export(s,str(P/('R10_test_'+n+'.step')))
(P/'carriage_R10_interference.json').write_text(json.dumps({'scope':'Purchased head housing is sourced OD44.45 x17.4498 width cylinder envelope; shank nominal19.05; tube actualOD32 extends47.625mm from each ball. Spacers, ball internals and jam nuts unmodeled.','rows':rows},indent=2))
