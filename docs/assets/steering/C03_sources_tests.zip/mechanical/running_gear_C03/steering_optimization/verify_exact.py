"""Exact imported B-rep distances for whole tie capsule and source-size end spheres.
Local analysis only. Existing generators are untouched. Clearance is a sampled-motion result.
"""
from pathlib import Path
import sys, json, math, time
import numpy as np
import cadquery as cq
from search import solve,rotz,K,v
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
def dist(s,t):
 d=BRepExtrema_DistShapeShape();d.SetMultiThread(False);d.LoadS1(s.wrapped);d.LoadS2(t.wrapped);d.Perform();return d.Value()
P=Path(__file__).parent;C=P.parent;C2=C.parent/'running_gear_C02'

def load(file):return cq.importers.importStep(str(file)).val()

def edge(a,b):return cq.Edge.makeLine(cq.Vector(*a),cq.Vector(*b))

def rotation_align(u0,u):
 c=float(u0@u);k=np.cross(u0,u);S=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]])
 return np.eye(3)+S+S@S/(1+c)

def lever(a,target_y=787,target_x=-115):
 # Same parent double-clevis concept, arm length adapted. Two 8 mm plates; 46.6 mm clear span.
 ball=K+a;n=np.array([0.,150,262]);n/=np.linalg.norm(n); vv=np.cross(n,[1,0,0]);parts=[]
 for side in [-1,1]:
  center=ball+side*27.3*n
  e=np.array([target_x-center[0],(target_y-center[1])/vv[1]])
  d=e/np.linalg.norm(e);perp=np.array([-d[1],d[0]])*12
  poly=[perp,e+perp,e-perp,-perp]
  pl=cq.Plane(origin=tuple(center-4*n),xDir=(1,0,0),normal=tuple(n))
  ear=cq.Workplane(pl).polyline([tuple(x) for x in poly]).close().extrude(8)
  ear=ear.union(cq.Workplane(pl).circle(20).extrude(8))
  ear=ear.union(cq.Workplane(pl).center(*e).circle(16).extrude(8))
  ear=ear.cut(cq.Workplane(cq.Plane(origin=tuple(center-8*n),normal=tuple(n))).circle(8.15).extrude(16))
  parts.append(ear.val())
 return cq.Compound.makeCompound(parts)

def run(x,rmax=65, qsteps=9,rsteps=13, name='candidate'):
 a=np.array(x[:3],float);tx=x[3]; T=np.array([tx,262.,-150]);L=np.linalg.norm(T);u0=T/L;n0=np.array([0.,150,262]);n0/=np.linalg.norm(n0)
 U=load(C/'upper_wishbone_C03_R02.step');lower=load(C/'lower_wishbone_C03_R03.step');H=load(C2/'stationary_hardware_C02_R01.step');clamp=load(C2/'stationary_clamp_C02_R01.step')
 rail=cq.Workplane('XY').box(1700,100,200).translate((0,460,0)).val()
 body=cq.Workplane('XY').box(650,720,454).translate((-550,0,110)).val() # rear battery reflected into front-like local coordinates; most restrictive body box
 F=lever(a)
 cq.exporters.export(F,str(P/(name+'_outer_lever.step')))
 rows=[]; minima={};t=time.time()
 for q in np.linspace(-12,12,qsteps):
  qr=np.deg2rad(q);dv=np.array([0,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150]);
  obstacles={'upper':U.rotate((0,550,70),(1,550,70),q),'lower':lower.rotate((0,550,-270),(1,550,-270),q),'root_hardware':H,'clamp':clamp,'frame_rail':rail,'body':body}
  rarray=np.linspace(-rmax,rmax,rsteps);res=solve(a,tx,np.full(rsteps,qr),rarray,np.broadcast_to(dv,(rsteps,3)))
  if res is None:raise RuntimeError('no closure '+str(q))
  ds,outs,inns=res
  for r,d,o,i in zip(rarray,ds,outs,inns):
   dd=math.degrees(d);e=edge(i,o);Fq=F.rotate(tuple(K),tuple(K+[0,0,1]),dd).translate(tuple(dv))
   row={'q_deg':float(q),'rack_mm':float(r),'steer_deg':dd,'closure_error_mm':float(abs(np.linalg.norm(o-i)-L))}
   u=(o-i)/L;Ralign=rotation_align(u0,u);n=Ralign@n0
   row['inner_misalignment_deg']=math.degrees(math.acos(np.clip(n@n0,-1,1)))
   row['outer_misalignment_deg']=math.degrees(math.acos(np.clip(n@rotz(n0,np.array([d]))[0],-1,1)))
   # Lever force moment coefficient against tie force in mm. Zero indicates a toggle.
   ja=rotz(np.array([-a[1],a[0],0]),np.array([d]))[0]
   row['moment_arm_mm']=float(abs(u@ja))
   for label,s in obstacles.items():
    print('begin',q,r,label,flush=True)
    row['tube_'+label]=dist(e,s)-16
    row['outer_head_'+label]=dist(cq.Vertex.makeVertex(*o),s)-22.225
    row['inner_head_'+label]=dist(cq.Vertex.makeVertex(*i),s)-22.225
    row['inner_fork_ball_envelope_'+label]=dist(cq.Vertex.makeVertex(*i),s)-37.2
    row['lever_'+label]=dist(Fq,s)
   for key,val in row.items():
    if key.startswith(('tube_','outer_head_','inner_head_','inner_fork_','lever_')) and (key not in minima or val<minima[key]['mm']):minima[key]={'mm':val,'q_deg':float(q),'rack_mm':float(r),'steer_deg':dd}
   rows.append(row)
  print(name,'q',q,'min',min(vv['mm'] for vv in minima.values()),'elapsed',round(time.time()-t,1),flush=True)
  result={'parameters':{'a':a.tolist(),'T':T.tolist(),'inner_nominal':(K+a-T).tolist(),'outer_nominal':(K+a).tolist(),'rmax':rmax,'tie_centers_mm':L,'n0':n0.tolist()},'minima':minima,'rows':rows}
  (P/(name+'_exact.json')).write_text(json.dumps(result,indent=2))
 return result

if __name__=='__main__':
 import argparse
 ap=argparse.ArgumentParser();ap.add_argument('--x',type=float,nargs=4,required=True);ap.add_argument('--rack',type=float,default=65);ap.add_argument('--qs',type=int,default=9);ap.add_argument('--rs',type=int,default=13);ap.add_argument('--name',default='candidate');args=ap.parse_args()
 r=run(args.x,args.rack,args.qs,args.rs,args.name)
 print(json.dumps({'parameters':r['parameters'],'minima':r['minima'],'max_inner_tilt':max(x['inner_misalignment_deg'] for x in r['rows']),'max_outer_tilt':max(x['outer_misalignment_deg'] for x in r['rows']),'min_moment_arm_mm':min(x['moment_arm_mm'] for x in r['rows'])},indent=2))
