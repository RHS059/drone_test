from verify_exact import *
a=np.array([-289.,-90,-85]);F=lever(a,772);d=json.loads((P/'recommended_75_exact.json').read_text());d['parameters']['lever_target_y']=772;d['parameters']['lever_target_x']=-115;d['parameters']['lever_source']='recommended_75_lever_targetY772.step';d['parameters']['fork_gap_mm']=46.6;d['parameters']['plate_thickness_mm']=8
U=load(C/'upper_wishbone_C03_R02.step');L=load(C/'lower_wishbone_C03_R03.step');H=load(C2/'stationary_hardware_C02_R01.step');clamp=load(C2/'stationary_clamp_C02_R01.step');rail=cq.Workplane('XY').box(1700,100,200).translate((0,460,0)).val();body=cq.Workplane('XY').box(650,720,454).translate((-550,0,110)).val()
for row in d['rows']:
 q=row['q_deg'];dd=row['steer_deg'];qr=np.deg2rad(q);dv=np.array([0,262*np.cos(qr)+150*np.sin(qr)-262,262*np.sin(qr)-150*np.cos(qr)+150]);Fq=F.rotate(tuple(K),tuple(K+[0,0,1]),dd).translate(tuple(dv))
 for label,s in {'upper':U.rotate((0,550,70),(1,550,70),q),'lower':L.rotate((0,550,-270),(1,550,-270),q),'root_hardware':H,'clamp':clamp,'frame_rail':rail,'body':body}.items():row['lever_'+label]=dist(Fq,s)
 print(q,row['rack_mm'],row['lever_lower'],row['lever_clamp'],flush=True)
for key in list(d['minima']):
 if key.startswith('lever_'):
  row=min(d['rows'],key=lambda r:r[key]);d['minima'][key]={'mm':row[key],'q_deg':row['q_deg'],'rack_mm':row['rack_mm'],'steer_deg':row['steer_deg']}
W=load(Path(str(Path(__file__).resolve().parents[3]/'wheels/wheel_C01.step'))).translate((0,940,-250));Wr=cq.Workplane('XZ',origin=(0,1110,-250)).circle(438.15).circle(228.6).extrude(340).val();base=load(C/'steering_upright_C03_R03.step').rotate((0,0,0),(1,0,0),90).translate((0,797,-250));union=base.fuse(*F.Solids())
d['fixed_relative_clearances']={'lever_to_C01_wheel_mm':dist(F,W),'lever_to_340_reserved_tire_mm':dist(F,Wr),'lever_reserved_tire_overlap_mm3':F.intersect(Wr).Volume(),'lever_carrier_union_valid':union.isValid(),'lever_carrier_union_solids':len(union.Solids())}
cq.exporters.export(union,str(P/'recommended_75_connected_upright.step'));cq.exporters.export(F,str(P/'recommended_75_final_lever.step'));(P/'recommended_75_final_exact.json').write_text(json.dumps(d,indent=2));print(json.dumps({'minima':d['minima'],'fixed_relative_clearances':d['fixed_relative_clearances']},indent=2))
