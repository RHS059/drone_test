# C03 steering hardpoint optimization

## Recommended hardpoints (mm, station-local front-left)

- Kingpin midpoint K = (0, 812, -250)
- Steering arm a = (-289, -90, -85)
- Nominal tie vector T = (72, 262, -150)
- Outer spherical center = (-289, 722, -335)
- Inner spherical center = (-361, 460, -185)
- Tie spherical-center distance = 310.367524074 mm
- With47.625 mm exposed end length at each end, fabricated tube length=215.117524074 mm;25.4 mm nominal thread engagement is preserved.
- Both neutral fork pin axes n = (0, 0.496852199665, 0.867835175415)
- Rack travels along global Y, +/-75 mm; use the source-supported 200 mm actuator, not the 150 mm version.
- With the parent's 490 mm neutral actuator pin spacing, used length415..565 mm corresponds to extension25..175 mm.
- Mirror Y for the right side, mirror X for the rear axle. Front global inner anchor is (989, +/-460, -185); rear is (-989, +/-460, -185).
- FK JMX12/JMXL12 with 12-10HB spacers at BOTH ends, 46.6 mm nominal fork gap, 15.875 mm pin, 16.3 mm modeled hole. The previous global-X inner pin axis must not be reused for this skew tie.

## Motion and numerical checks

Dense grid: 97 suspension positions over +/-12 degrees and301 rack positions over +/-75 mm,29,197 states.

- Minimum full-rack outer-wheel steering:15.03283966 degrees
- Maximum inner-wheel steering:21.46701832 degrees
- Neutral suspension/full rack:19.96536636 degrees inner /15.08858928 degrees outer
- Nominal Ackermann error:0.90118 degrees outer-angle error, using1624 mm kingpin track and1350 mm half-wheelbase
- Zero-rack bump steer:<5.1e-14 degrees
- Maximum closure residual:3.41e-13 mm
- Minimum tie-force steering moment arm:76.19851349 mm, no sampled toggle
- Inner spherical misalignment:14.03991628 degrees
- Outer spherical misalignment:21.19244437 degrees
- Both remain within the source's conservatively interpreted +/-24-degree high-misalignment limit. The unspaced inner +/-14-degree bearing allowance is insufficient.

Proof of zero-rack closure: out-in = (T.x, Rx(q)*(0,262,-150).yz) at zero steer. Rotation about X preserves its norm for every q, not merely at the sampled states.

## Final outer lever

Use `recommended_75_final_lever.step` or the equivalent `recommended_75_lever_targetY772.step`.
`recommended_75_connected_upright.step` is the original R03 upright fused with the tested two plates. It is one valid connected solid.

Each8 mm plate has a center at outer_ball +/-27.3*n, lies normal to n, has a20 mm pin-boss radius and8.15 mm pin-hole radius, and connects via a24 mm-wide strip to a16 mm-radius pad. The endpoint is X=-115,Y=772. The two endpoint Z values are -395.083540585 and -332.168367812. Its inclined plane determines Z; do not replace it with a horizontal beam at the ball's Z.

The original Y=787 attachment is rejected: although it clears the provisional source wheel, it overlaps a deliberately conservative340 mm-wide solid tire annulus by3.544 mm3. The revised Y=772 route clears it.

## Actual imported CAD checks

`recommended_75_final_exact.json` contains the nine combinations q={-12,0,12} degrees, rack={-75,0,75} mm, using the imported original upper/lower wishbones, stationary hardware, clamp, frame rail and rear battery box. Whole tie-tube clearance uses the entire ball-to-ball centerline minus16 mm, a conservative capsule that is longer than the fabricated tube. Head clearances use radius22.225 mm spheres. Inner fork space is conservatively reserved as a37.2 mm sphere.

Minimum observed gaps:

- Final outer lever to lower wishbone:8.746986 mm
- Whole tie to original stationary clamp:21.918855 mm
- Inner fork reservation to rear battery:35.249983 mm
- Inner fork reservation to frame rail:47.800000 mm
- Whole tie to lower wishbone:42.762767 mm on the9-state grid;42.409848 mm at the critical root-pin state
- Actual lower root-pin to whole tie:17.256539 mm, optimized over q at rack=-75, at q=+3.209754 degrees
- Final outer lever to original C01 wheel:35.302448 mm
- Whole tie to C01 wheel:50.249746 mm
- Outer head spherical envelope to C01 wheel:44.024746 mm
- Final outer lever to conservative340 mm-wide tire reservation:6.438871 mm, zero overlap
- Whole tie to infinite340 mm tire inner-sidewall plane:32.000000 mm
- Outer head to that plane:25.775000 mm

The340 mm tire reservation is a fully occupied annulus, OD876.3 mm, ID457.2 mm, width340 mm, centered at(0,940,-250). It is deliberately more restrictive than the source-backed provisional317.5 mm wheel section. Relative lever/wheel geometry is invariant with steering and jounce, so the lever-to-wheel and reserved-annulus results apply throughout the specified motion.

The dense capsule screen covers wishbone tube/eye/housing and root-pin envelopes; its final conservative lower bound is3.297924 mm at the lever/lower-tube screen and7.437672 mm at the whole-tie/root-head screen. These are conservative enclosing-capsule distances, not the actual imported-solid gaps above. They must not be reported as exact solid clearances.

## R08 carriage issue found during independent check

The hardpoint route is feasible, but the parent's first R08 carriage support is not. `carriage_R08_interference.json` records shank/tube intersections at all nine sampled states. Neutral overlap is1634.514 mm3 for the19.05 mm nominal shank and2228.299 mm3 for the actual OD32 tube starting47.625 mm from the spherical center. Worst tube overlap is6545.639 mm3 at q=-12 degrees,rack=+75 mm. The head housing itself clears.

Cause: the support roots are placed30 mm outward along the tie direction, and the vertical posts obstruct the rod's exit. Reroute the support behind/inboard of the spherical center, with a suggested root offset near-60*vv (vv=(0,262,-150)/norm). A mere-30*vv move risks bringing the vertical upper post through the head envelope. The replacement R10 carriage was subsequently tested and passed; the R08 geometry itself remains rejected.


## R10 carriage verification

The parent rebuilt the support roots at center-60*vv. `carriage_R10_interference.json` records the nine requested suspension/rack combinations, tested against the actual imported R10 carriage.

- Zero head-housing, shank or tube interference at all nine states
- Source-size head housing envelope: OD44.45 x width17.4498 mm; minimum gap6.637091 mm
- Nominal shank OD19.05 mm: minimum gap8.255502 mm
- Actual OD32 tube spanning47.625 mm from each ball: minimum gap19.163110 mm
- Original `tie_clevis_pin_C03_R01.step` transformed local+Z to n0 at the inner ball: zero carriage overlap; near-zero distance is intended pin-head seating against the fork plate

Right-side geometry is mirrored; reversing global rack travel corresponds to the already tested opposite left-side rack travel. This check does not model purchased spherical-ball/spacer internals. The source head housing is a conservative external cylinder, not a claim that its filled center is solid material.

## Files and reproducibility

- `recommended_dense_screen.json`, `recommended_screen.py`: dense closure, angular and conservative envelope check
- `recommended_75_final_exact.json`, `verify_final_lever.py`: final exact imported-solid sampled checks
- `recommended_root_and_wheel.json`, `check_root_and_wheel.py`: root-pin clearance optimization and source wheel checks (source wheel lever result in this older file is forY787; use final_exact for finalY772 lever)
- `lever_refinement.json`, `refine_lever.py`: attachment-path alternatives and340 mm tire checks
- `carriage_R08_interference.json`, `check_carriage_R08.py`: failed R08 support evaluation
- `carriage_R10_interference.json`, `check_carriage_R10.py`: passed replacement R10 carriage/head/shank/tube/pin check
- `verify_exact.py`: shared exact geometry and distance routines; default lever targetY remains787 for reproducibility of earlier files; final routine explicitly passes772

Only this analysis directory was edited by this worker. No parent generator or production model was modified.

## Limits

This establishes geometric feasibility under the stated model and sampled/dense analytical sweeps. It is not a fabrication, load, fatigue, tolerance, safety, or steering-system release. Purchased spacer and ball internal contours, retention hardware, jam nuts/tool access, actual tread/sidewall tolerances on the selected rim, weld qualification, tube buckling, pin bending, and actuator force/duty/fault behavior remain unqualified. Full axle/rack/vehicle assembly validation remains with the parent build. Conservative head envelopes are useful external-space reservations, not substitutes for purchased-component internal interference validation.

## S01 static compatibility supplement

The subsequent bounded q=0/rack=0 S01 check passed for all four front/rear sides and both R11 racks:72 component/envelope checks against302 fixture solids. Minimum conservative whole-tie capsule gap8.062146 mm; actual tube13.128666 mm; upright11 mm; outer tie pin18.5 mm. See `S01_C03_STATIC_CHECK.md` and `S01_C03_static_compatibility.json`. This does not approve the old pin-removal sequence, any service motion, or fixture loading.
