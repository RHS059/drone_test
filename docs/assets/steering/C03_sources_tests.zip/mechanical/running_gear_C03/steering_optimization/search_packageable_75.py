import numpy as np, math, json
from scipy.optimize import differential_evolution
from pathlib import Path
P=Path(__file__).parent
K=np.array([0.,812,-250]); v=np.array([0.,262,-150]);
qs=np.deg2rad(np.array([-12,-6,0,6,12])); rs=np.array([-75.,-50,-25,0,25,50,75])
Q,R=np.meshgrid(qs,rs,indexing='ij'); Q=Q.ravel();R=R.ravel();
DV=np.array([np.zeros(len(Q)),262*np.cos(Q)+150*np.sin(Q)-262,262*np.sin(Q)-150*np.cos(Q)+150]).T
# obstacle capsule skeletons, including max root-pin head envelope.
obs=[]
for z,lower in [(70,False),(-270,True)]:
 for x in [-170,170]:
  obs.append((np.array([x-40,550,z]),np.array([x+40,550,z]),25,z))
  if lower:
   obs += [(np.array([x,550,z]),np.array([x/2,681,z-95]),16,z),(np.array([x/2,681,z-95]),np.array([0,760,z-150]),16,z)]
  else: obs.append((np.array([x,550,z]),np.array([0,730,z-150]),16,z))
 obs.append((np.array([0,760 if lower else 730,z-150]),np.array([0,812,z-150]),16,z))
 obs.append((np.array([-15.7,812,z-150]),np.array([12.7,812,z-150]),40,z))
 for x in [-170,170]:
  obs.append((np.array([x-71,550,z]),np.array([x-65,550,z]),16,None))
  obs.append((np.array([x-65,550,z]),np.array([x+65,550,z]),10,None))

def rotz(a,d):
 return np.array([a[0]*np.cos(d)-a[1]*np.sin(d), a[0]*np.sin(d)+a[1]*np.cos(d), np.full(np.shape(d),a[2])]).T

def solve(a,tx,q=Q,r=R,dv=DV):
 T=np.array([tx,262.,-150]); I=K+a-T
 S=T-a+dv-np.array([np.zeros(len(np.atleast_1d(r))),np.atleast_1d(r),np.zeros(len(np.atleast_1d(r)))]).T
 C=S[:,0]*a[0]+S[:,1]*a[1]; D=-S[:,0]*a[1]+S[:,1]*a[0]; E=(T@T-np.sum(S*S,axis=1)-a@a)/2-S[:,2]*a[2]
 rat=E/np.hypot(C,D)
 if np.any(np.abs(rat)>1): return None
 phi=np.arctan2(D,C); alpha=np.arccos(rat)
 roots=np.array([phi+alpha,phi-alpha]); roots=(roots+np.pi)%(2*np.pi)-np.pi
 d=np.take_along_axis(roots,np.argmin(np.abs(roots),axis=0)[None,:],axis=0)[0]
 out=K+dv+rotz(a,d); inn=I+np.array([np.zeros_like(r),r,np.zeros_like(r)]).T
 return d,out,inn

def distance_segments(p1,q1,p2,q2):
 u=q1-p1;v=q2-p2;w=p1-p2
 aa=np.sum(u*u,axis=-1);bb=np.sum(u*v,axis=-1);cc=np.sum(v*v,axis=-1);dd=np.sum(u*w,axis=-1);ee=np.sum(v*w,axis=-1)
 den=aa*cc-bb*bb
 s=np.divide(bb*ee-cc*dd,den,out=np.zeros_like(den),where=abs(den)>1e-12)
 t=np.divide(aa*ee-bb*dd,den,out=np.zeros_like(den),where=abs(den)>1e-12)
 interior=np.linalg.norm(w+s[:,None]*u-t[:,None]*v,axis=-1)
 interior[(abs(den)<1e-12)|(s<0)|(s>1)|(t<0)|(t>1)]=np.inf
 def ptseg(p,a,b):
  ab=b-a;rr=np.sum(ab*ab,axis=-1);h=np.clip(np.sum((p-a)*ab,axis=-1)/rr,0,1)
  return np.linalg.norm(p-a-h[:,None]*ab,axis=-1)
 return np.minimum.reduce([interior,ptseg(p1,p2,q2),ptseg(q1,p2,q2),ptseg(p2,p1,q1),ptseg(q2,p1,q1)])

def clearance(a,tx,d,out,inn):
 vals=[]
 n=np.array([0.,150,262]);n/=np.linalg.norm(n)
 lever_segments=[]
 for side in [-1,1]:
  aa=a+side*27.3*n
  bb=aa+np.array([-115-aa[0],787-(K+aa)[1],-(787-(K+aa)[1])*150/262])
  lever_segments.append((K+DV+rotz(aa,d),K+DV+rotz(bb,d)))
 # full tie tube; outer sphere includes fork gap + plate + nose radius conservatively
 for p,b,rad,z in obs:
  if z is not None:
   p=p-np.array([0,550,z]);b=b-np.array([0,550,z]);
   p=np.array([np.full_like(Q,p[0]),p[1]*np.cos(Q)-p[2]*np.sin(Q)+550,p[1]*np.sin(Q)+p[2]*np.cos(Q)+z]).T
   b=np.array([np.full_like(Q,b[0]),b[1]*np.cos(Q)-b[2]*np.sin(Q)+550,b[1]*np.sin(Q)+b[2]*np.cos(Q)+z]).T
  else:p=np.broadcast_to(p,out.shape);b=np.broadcast_to(b,out.shape)
  vals.append(distance_segments(inn,out,p,b)-rad-16)
  # outer fork sphere; exact shapes later
  vals.append(distance_segments(out,out+1e-6,p,b)-rad-37)
  for la,lb in lever_segments:vals.append(distance_segments(la,lb,p,b)-rad-13)
 # rail collision screen: inner root portion must be below rail; full tie further y than rail except inside
 vals.append(np.full(len(Q),-100-(K+a-np.array([tx,262,-150]))[2]-24))
 return np.min(vals)

def evaluate(x,verbose=False):
 a=np.array(x[:3]);tx=x[3];res=solve(a,tx)
 if res is None:return 1e6
 d,out,inn=res
 if np.max(abs(d))>np.deg2rad(40):return 1e5+np.max(abs(d))*100
 cle=clearance(a,tx,d,out,inn)
 # wheel inner side plane (-42 reserved) distance; tie must be inboard. q independent frame
 wheel_n=np.array([-np.sin(d),np.cos(d),np.zeros_like(d)]).T
 inner_side=np.sum((inn-(K+DV))*wheel_n,axis=1)
 # all endpoint y must be below -42 minus tube radius
 tire=min(np.min(-42-16-np.maximum(inner_side,a[1])),-42-33-a[1]);cle=min(cle,tire)
 dr=d.reshape(len(qs),len(rs));mn=np.min(np.abs(dr[:,[0,-1]]))*180/np.pi;mx=np.max(abs(d))*180/np.pi
 # nominal near ackermann target equivalent right side delta(r)=-delta_left(-r)
 l=abs(dr[2,0]);rr=abs(dr[2,-1]);inner=max(l,rr);outer=min(l,rr)
 ideal_outer=np.arctan(1350/(1350/np.tan(inner)+1624))
 ack=abs(outer-ideal_outer)*180/np.pi
 # positive steer on left must be inner
 if l<rr:ack+=5
 # approximate bearing misalign: rod inclination min/max and planar delta leave exact verification later
 penalty=max(0,8-cle)**2*30+max(0,15-mn)**2*30+ack**2*2 + max(0,mx-25)**2*5
 # favor short rearward arm with modest skew and positive clearances
 penalty+=0.001*(a[0]+250)**2+0.001*tx**2+0.015*max(0,cle-20)**2
 if verbose:return {'x':x.tolist(),'clearance_screen_mm':cle,'steer_min_deg':mn,'steer_max_deg':mx,'ackermann_error_deg':ack,'left_plus_turn':l*180/np.pi,'right_plus_turn':rr*180/np.pi,'cost':penalty}
 return penalty

if __name__=='__main__':
 results=[]
 for seed in range(1):
  sol=differential_evolution(evaluate,[(-330,-270),(-120,-83),(-80,-50),(0,140)],seed=seed,popsize=12,maxiter=70,tol=.001,polish=True)
  r=evaluate(sol.x,True);print(r,flush=True);results.append(r);(P/'search_packageable_75_results.json').write_text(json.dumps(results,indent=2))
