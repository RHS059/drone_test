"""Original clamp revisions and nominal fastening for connected C03 rack support."""
from pathlib import Path
import sys,math,json
import cadquery as cq
P=Path(__file__).parent;sys.path.insert(0,str(P));from generate_steering_corner import output
base=cq.importers.importStep(str(P.parent/'running_gear_C02/stationary_clamp_C02_R01.step')).val()
p=cq.Workplane(obj=base)
for x in [-202,-170]:
 for z in [-125,-235]:p=p.cut(cq.Workplane(cq.Plane(origin=(x,490,z),normal=(0,1,0))).circle(5.5).extrude(40))
left=p.val();right=left.mirror('XZ')
notes={'original':'Four Ø11 M10 clearance holes added for connected rack hanger; frame unchanged','mounting_holes_left_mm':[[x,510,z] for x in [-202,-170] for z in [-125,-235]],'coordinates':'Vehicle C at front stationX0; rear uses mirrorX on manufactured counterpart','status':'Clamp loss of section, bolt preload, fatigue and simultaneous suspension/steering loads not qualified'}
output(left,'stationary_clamp_front_left_C03_R03',notes);output(right,'stationary_clamp_front_right_C03_R03',notes)
# Nominal M10 bolts, washers and nuts; no helical thread or supplier approval.
parts=[]
for side in [-1,1]:
 for xx in [1148,1180]:
  for z in [-125,-235]:
   normal=(0,side,0)
   def cyl(r,y,L,inner=0):
    w=cq.Workplane(cq.Plane(origin=(xx,side*y,z),normal=normal)).circle(r)
    if inner:w=w.circle(inner)
    return w.extrude(L)
   bolt=cyl(5,500,35)
   head=cq.Workplane(cq.Plane(origin=(xx,side*493.6,z),normal=normal)).polygon(6,16/math.cos(math.pi/6)).extrude(6.4)
   parts.append((f'bolt_{side}_{xx}_{z}',bolt.union(head).val()))
   parts.append((f'washer_outer_{side}_{xx}_{z}',cyl(10,522,2,5.5).val()))
   parts.append((f'washer_inner_{side}_{xx}_{z}',cyl(10,500,2,5.5).val()))
   nut=cq.Workplane(cq.Plane(origin=(xx,side*524,z),normal=normal)).polygon(6,16/math.cos(math.pi/6)).circle(5).extrude(8)
   parts.append((f'nut_{side}_{xx}_{z}',nut.val()))
from generate_cad import glb,properties
ass=cq.Assembly(name='rack_mount_hardware_C03_R03')
for n,s in parts:assert s.isValid();ass.add(s,name=n)
ass.export(str(P/'rack_mount_hardware_C03_R03.step'));glb(parts,P/'rack_mount_hardware_C03_R03.glb')
r={'status':'Nominal original fastener geometry only; grade, torque, locking and threads unqualified','part_count':len(parts),'density_assumption_kg_m3':7850,**properties(cq.Compound.makeCompound([s for _,s in parts]))}
(P/'rack_mount_hardware_C03_R03_report.json').write_text(json.dumps(r,indent=2));print(r)
