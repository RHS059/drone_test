"""Numerical tests of published dimensional reservations only. No proprietary actuator CAD."""
from pathlib import Path
import json
import cadquery as cq
P=Path(__file__).parent
report=json.loads((P/'rack_C03_R11_report.json').read_text())
parts=[(x['part'],cq.importers.importStep(str(P/(x['part']+'.step'))).val(),x['group']) for x in report['parts']]
# Manufacturer max rectangular main-body envelope, motor down. It excludes eye transitions.
# Actual contour may occupy less; positive volume is a reservation conflict, not proof of hardware collision.
body=cq.Workplane('XY').box(77,235,148).translate((1084,-340+21.6+235/2,-250-36)).val()
# Source mounting eyes reserved as dimensional solids with pin holes, exact external profile unverified.
def eye(y,width):
 return cq.Workplane('YZ',origin=(1084-width/2,y,-250)).circle(13.4).circle(6.1).extrude(width).val()
rear=eye(-340,25.4)
rows=[]
for r in [-75,0,75]:
 envs=[('main_body',body),('rear_eye',rear),('front_eye',eye(150+r,30.2))]
 for n,s,g in parts:
  ss=s.translate((0,r,0)) if g=='rack_translation_Y' else s
  for label,t in envs:
   # Nominal pin cylinders are excluded:12 mm pin inside12.2 mounting bore is checked by diameters.
   v=ss.intersect(t).Volume();rows.append({'rack_mm':r,'part':n,'reservation':label,'overlap_mm3':v})
comp=cq.importers.importStep(str(Path(__file__).resolve().parents[2]/'body-power/body_power_R01.step')).val()
for fore in [-1,1]:
 b=body if fore==1 else body.mirror('YZ')
 for i,s in enumerate(comp.Solids()):
  a,c=b.BoundingBox(),s.BoundingBox()
  if a.xmax<c.xmin or c.xmax<a.xmin or a.ymax<c.ymin or c.ymax<a.ymin or a.zmax<c.zmin or c.zmax<a.zmin:continue
  rows.append({'fore':fore,'part':'vehicle_body_'+str(i),'reservation':'main_body','overlap_mm3':b.intersect(s).Volume()})
r={'scope':'Published dimensional max-body and nominal eye reservations for HD48B045200mm M/M; motor-down. Exact transitions, connectors, cable bends and tolerances unverified','pin_fit':'12mm nominal pins versus12.2 E9 source eyes; full tolerance stack not approved','rows':rows,'failures':[x for x in rows if x['overlap_mm3']>1e-4]}
(P/'actuator_reservation_C03_R01.json').write_text(json.dumps(r,indent=2));print('conflicts',r['failures'],flush=True)
