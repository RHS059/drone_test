"""Original C03 R11 rack for skew-tie geometry; mm. Development, not fabrication release."""
from pathlib import Path
import sys,json,math
import numpy as np
import cadquery as cq
P=Path(__file__).parent;sys.path.insert(0,str(P.parent));from generate_cad import glb,properties,exact_bounds
X=989;Z=-250;parts=[]
def add(n,s,g='stationary',d=7850):
 assert s.isValid();parts.append((n,s,g,d))
def box(dx,dy,dz,x,y,z):return cq.Workplane('XY').box(dx,dy,dz).translate((x,y,z))
def tube(dx,dy,dz,wx,wz,x,y,z):return box(dx,dy,dz,x,y,z).cut(box(dx-2*wx,dy+2,dz-2*wz,x,y,z))
guide=tube(80,600,60,6,6,X,0,Z).cut(box(10,190,20,X-37,0,Z))
guide=guide.cut(box(10,190,20,X+37,150,Z))
for side in [-1,1]:guide=guide.union(box(20,10,30,X-50,side*90,Z))
add('rack_guide',guide.val())
beam=tube(80,1020,40,4,4,X,0,-300)
# Original welded longitudinal bridges connect the new crossbeam to existing corner clamps.
for side in [-1,1]:
 bridge=box(248,60,40,1113,side*480,-300).cut(box(250,52,32,1113,side*480,-300))
 beam=beam.union(bridge)
 hanger=box(80,8,210,1157,side*506,-215)
 for xx in [1148,1180]:
  for zz in [-125,-235]:hanger=hanger.cut(cq.Workplane(cq.Plane(origin=(xx,side*490,zz),normal=(0,side,0))).circle(5.5).extrude(40))
 beam=beam.union(hanger)
 liner=box(68,50,48,X,side*270,Z).cut(box(60.5,52,40.5,X,side*270,Z))
 add('guide_liner_'+str(side),liner.val(),d=940)
carriage=tube(60,920,40,4,4,X,0,Z)
# Handed inclined clevises: spacers12-10HB on both ends, gap46.6, pin15.875.
for side in [-1,1]:
 n=np.array([0,side*150,262],float);n/=np.linalg.norm(n)
 vv=np.array([0,side*262,-150],float);vv/=np.linalg.norm(vv)
 ball=np.array([X,side*460,-185.])
 for sign in [-1,1]:
  center=ball+sign*27.3*n;root=center-60*vv
  pl=cq.Plane(origin=tuple(center-4*n),xDir=(1,0,0),normal=tuple(n))
  # Local y direction is n cross X, opposite vv for left side.
  ry=float((root-center)@np.cross(n,[1,0,0]))
  ear=cq.Workplane(pl).circle(20).extrude(8).union(cq.Workplane(pl).center(0,ry/2).rect(24,abs(ry)).extrude(8))
  ear=ear.union(cq.Workplane(pl).center(0,ry).circle(12).extrude(8))
  ear=ear.cut(cq.Workplane(cq.Plane(origin=tuple(center-8*n),normal=tuple(n))).circle(8.15).extrude(16))
  # Vertical posts support each fork outside the purchased ball/spacer envelope.
  bottom=Z+20;top=root[2]+3
  post=box(20,16,top-bottom,X,root[1],(top+bottom)/2)
  # Extend the hollow carriage with a welded lateral box finger under each outboard post.
  ymin,ymax=sorted([side*440,root[1]+side*8]); finger=box(32,ymax-ymin,20,X,(ymin+ymax)/2,Z+10)
  carriage=carriage.union(ear).union(post).union(finger)
#200mm stroke candidate: pin length490 neutral, range415..565, equivalent25..175 extension.
AX=X+95
for label,y,gap in [('rear',-340,27),('front',150,32)]:
 if label=='rear':bracket=box(83,36,12,X+81.5,y,Z-36)
 else:bracket=box(81,24,12,X+82.5,y,Z-29).union(box(20,24,16,X+40,y,Z)).union(box(8,24,43,X+46,y,Z-13.5))
 for side in [-1,1]:
  xx=AX+side*(gap/2+4)
  ear=box(8,32,38 if label=='rear' else 30,xx,y,Z-19 if label=='rear' else Z-15)
  ear=ear.union(cq.Workplane('YZ',origin=(xx-4,y,Z)).circle(16).extrude(8))
  ear=ear.cut(cq.Workplane('YZ',origin=(xx-5,y,Z)).circle(6.25).extrude(10));bracket=bracket.union(ear)
 if label=='rear':beam=beam.union(bracket)
 else:carriage=carriage.union(bracket)
 x0=AX-gap/2-8
 pin=cq.Workplane('YZ',origin=(x0,y,Z)).circle(6).extrude(60).union(cq.Workplane('YZ',origin=(x0-5,y,Z)).circle(11).extrude(5))
 pin=pin.cut(cq.Workplane('XY',origin=(x0+54,y,Z-10)).circle(1.6).extrude(20))
 add('actuator_'+label+'_pin',pin.val(),'stationary' if label=='rear' else 'rack_translation_Y')
carriage=carriage.union(box(20,20,16,X-40,0,Z))
add('rack_crossbeam',beam.val());add('rack_carriage',carriage.val(),'rack_translation_Y')
r={'revision':'C03 rack R11','status':'Original geometry development; collision and load checks pending','units':{'STEP':'mm','GLB':'m'},'front_rack_x_mm':X,'rear_rack_transform':'Original mirror through X=0','slider_translation_axis':[0,1,0],'travel_candidate_mm':[-75,75],'physical_stop_faces_mm':[-85,85],'moving_stop_lug_half_length_mm':10,'stop_qualification':'No impact/force/fault qualification','inner_tie_ball_centers_mm':[[X,-460,-185],[X,460,-185]],'inner_pin_axes':[[0,-150/math.sqrt(150**2+262**2),262/math.sqrt(150**2+262**2)],[0,150/math.sqrt(150**2+262**2),262/math.sqrt(150**2+262**2)]],'inner_tie_end':'FK JMX12/JMXL12 with12-10HB spacers; nominal15.875 pin and46.355 span in46.6 fork','guide_clearance_per_side_mm':.25,'liner':'Original polymer, density940 assumption, grade/wear/debris control unknown','frame_connection':'Original box bridges and hangers to eightM10 nominal clamp bolts; strength/bolt loads unqualified','actuator_candidate':'Thomson ElectrakHD48V B045200mm M/M, not approved for steering','actuator_nominal_pin_centers_mm':[[AX,-340,Z],[AX,150,Z]],'actuator_stroke_used_mm':[25,175],'actuator_body_orientation':'Motor downward; unknown exact contour reserved separately','parts':[]}
for n,s,g,d in parts:
 stem=n+'_C03_R11';cq.exporters.export(s,str(P/(stem+'.step')));glb([(n,s)],P/(stem+'.glb'))
 r['parts'].append({'part':stem,'group':g,'density_kg_m3':d,'density_assumed':True,'valid':s.isValid(),'solid_count':len(s.Solids()),'bounds_mm':exact_bounds(s),**properties(s,density=d)})
(P/'rack_C03_R11_report.json').write_text(json.dumps(r,indent=2));print([(x['part'],x['solid_count']) for x in r['parts']],flush=True)
