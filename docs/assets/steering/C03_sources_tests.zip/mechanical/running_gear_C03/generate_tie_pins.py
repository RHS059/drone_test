"""Original removable clevis pins, no strength/retention approval. Local pin axis+Z, ball center0."""
from pathlib import Path
import sys,json
import cadquery as cq
P=Path(__file__).parent;sys.path.insert(0,str(P));from generate_steering_corner import output
s=cq.Workplane('XY',origin=(0,0,-31.3)).circle(15.875/2).extrude(80)
s=s.union(cq.Workplane('XY',origin=(0,0,-36.3)).circle(12.5).extrude(5))
s=s.cut(cq.Workplane('YZ',origin=(-15,0,42.7)).circle(1.6).extrude(30))
output(s.val(),'tie_clevis_pin_C03_R01',{'status':'Original nominal geometry; material/fit/fatigue and actual cotter selection pending','axis':'Local+Z','ball_center_mm':[0,0,0],'shaft_diameter_mm':15.875,'shaft_length_mm':80,'head_diameter_mm':25,'head_thickness_mm':5,'cotter_bore_mm':3.2,'fork_gap_mm':46.6,'fork_plate_thickness_mm':8,'purchased_spacer_span_mm':46.355,'qualification':'0.245 mm nominal stack slack before shimming; no clamp/preload or retention release'})
