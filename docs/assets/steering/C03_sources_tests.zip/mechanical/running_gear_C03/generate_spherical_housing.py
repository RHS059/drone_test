"""Original removable AIN16 bearing housing, not vendor CAD. Development dimensions in mm.
Bearing outside dimensions are sourced; housing, retention plate and holes are original design.
No fitted tolerances, material grade, axial capacity, weld or fatigue approval is implied.
"""
from pathlib import Path
import sys,json,math
import cadquery as cq
P=Path(__file__).parent
sys.path.insert(0,str(P.parent))
from generate_cad import glb,properties,exact_bounds
D=53.975;W=25.4;R=40;lip=3;aperture=50;boltpcd=68
# Local X is the bearing pin axis; bearing center is origin.
def cyl(r,x0,length):return cq.Workplane('YZ',origin=(x0,0,0)).circle(r).extrude(length)
housing=cyl(R,-W/2-lip,W+lip).cut(cyl(aperture/2,-W/2-lip-1,W+lip+2)).cut(cyl(D/2,-W/2,W+1))
retainer=cyl(R,W/2,lip).cut(cyl(aperture/2,W/2-1,lip+2))
for a in [45,135,225,315]:
 y,z=boltpcd/2*math.cos(math.radians(a)),boltpcd/2*math.sin(math.radians(a))
 housing=housing.cut(cq.Workplane('YZ',origin=(-W/2-lip-1,y,z)).circle(2.1).extrude(W+lip+2))
 retainer=retainer.cut(cq.Workplane('YZ',origin=(W/2-1,y,z)).circle(2.75).extrude(lip+2))
parts=[('housing_body_C03_R01',housing.val()),('housing_retainer_C03_R01',retainer.val())]
assert all(s.isValid() and len(s.Solids())==1 for _,s in parts)
assert housing.val().intersect(retainer.val()).Volume()<1e-7
report={'original_geometry':True,'not_fabrication_released':True,'bearing':'FK AIN16 nominal outside diameter 53.975 mm, race width 25.4 mm','units':{'STEP':'mm','GLB':'m'},'bearing_center_local_mm':[0,0,0],'pin_axis_local':[1,0,0],'race_socket_nominal_mm':D,'race_width_nominal_mm':W,'housing_OD_mm':80,'retaining_lip_radial_mm':(D-aperture)/2,'shoulder_and_retainer_thickness_mm':lip,'retainer_bolts':'4 M5x0.8, body Ø4.2 pilots and retainer Ø5.5 clearance on Ø68 PCD; bolts and threads not yet installed','housing_retainer_overlap_mm3':housing.val().intersect(retainer.val()).Volume(),'gates':['Machined fit, runout and thermal tolerances unselected','Bearing catalogue ultimate radial load is not working-load approval','Retainer plate bending, bolt preload, axial bearing retention and fatigue unvalidated','Housing weld procedure and inspection unselected; bearing must be removable before welding','Pin spacers, high-misalignment articulation and assembly tooling require complete joint check'],'parts':[]}
for n,s in parts:
 cq.exporters.export(s,str(P/(n+'.step')));glb([(n,s)],P/(n+'.glb'));report['parts'].append({'name':n,'valid':s.isValid(),'bounds_mm':exact_bounds(s),'assumed_density_kg_m3':7850,**properties(s)})
(P/'spherical_housing_C03_R01_report.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
