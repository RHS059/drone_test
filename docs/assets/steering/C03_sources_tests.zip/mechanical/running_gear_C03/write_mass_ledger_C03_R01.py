from pathlib import Path
import json,csv,hashlib
P=Path(__file__).parent
m=json.loads((P/'original_steering_C03_R01_manifest.json').read_text());c2=json.loads((P.parent/'running_gear_C02/mass_cost_ledger_C02_R06.json').read_text())
items=[]
for p in m['assembly_nodes']:
 source=P.parent/p['source_step'];items.append({'node':p['node'],'quantity':1,'unit_mass_kg':p['mass_kg'],'basis':'Original CAD volume with assumed material density; no purchased envelopes counted','unit_cost':None,'source':p['source_step'],'sha256':hashlib.sha256(source.read_bytes()).hexdigest()})
for p in c2['items']:
 if p['mass_kg_per_corner'] is not None:items.append({'node':'two_middle_'+p['part'],'quantity':2,'unit_mass_kg':p['mass_kg_per_corner'],'basis':p['basis'],'unit_cost':None,'source':'running_gear_C02/'+p['part']+'.step','sha256':p['sha256_STEP']})
purchased=[('WD220 drive candidate',6),('KM3MSPN72204 tire',6),('EVOSE5240060141 rim',6),('EVOCM0750180040 flat-seat nut; raw212 unit unverified',30),('Wheeladapter outputstuds/inputnuts, finishedstack TBD',60),('GE20ES root/middle reference-bearing fit; grade/retention unselected',56),('FKAIN16 spherical bearing',8),('FK16-12HB misalignment spacer',16),('FKJMX12 RH tie rod end',4),('FKJMXL12 LH tie rod end',4),('FK12-10HB misalignment spacer',16),('AINhousing retainer M5 screws, grade/length unselected',32),('ThomsonHD48B045200mm actuator packaging candidate',2),('KingRS2008 PureRacecoilover candidate with unselectedsprings',6),('Cotters, axialretainers, jamnuts, seals, lubrication',None)]
orig=sum(p['quantity']*p['unit_mass_kg'] for p in items)
r={'configuration':'C03_R01 candidate','original_four_steering_corners_and_two_racks_kg':m['mass_kg_original_geometry_subtotal'],'two_middle_C02_R06_original_corner_mass_kg':2*c2['original_corner_mass_kg'],'six_corner_running_gear_original_subtotal_kg':orig,'difference_vs_C02_six_original_corners_kg':orig-c2['six_original_corner_mass_kg'],'same_scope_frame_body_runninggear_original_subtotal_kg':386.9529671773959+115.71496048218766+orig,'not_complete_vehicle_mass':True,'fabrication_released':False,'original_items':items,'purchased_items':[{'component':n,'quantity':q,'unit_mass_kg':None,'unit_cost':None,'status':'Supplier/item/configuration/finishedstack qualification required; no invented mass or price'} for n,q in purchased],'further_excluded':['Arms/grippers/tools/payload','Battery/electronics/cables unless separately sourced in integration ledger','Fixture/support masses are separate'],'cost_currency':None,'cost_status':'Fabrication and exact purchased configurations require quotes; no complete vehicle cost asserted','important_unknown':'EVOweight212 has no verified unit; never multiply by0.001 as a mass assumption.'}
(P/'mass_cost_ledger_C03_R01.json').write_text(json.dumps(r,indent=2))
with (P/'original_parts_C03_R01.csv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=['node','quantity','unit_mass_kg','basis','unit_cost','source','sha256']);w.writeheader();w.writerows(items)
print({k:v for k,v in r.items() if k.endswith('_kg')})
