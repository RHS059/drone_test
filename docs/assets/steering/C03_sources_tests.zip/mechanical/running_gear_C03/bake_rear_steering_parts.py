"""Bake genuinely handed original rear carrier/clamp parts, preserving source wheel rotations."""
from pathlib import Path
import sys,json
import cadquery as cq
P=Path(__file__).parent;sys.path.insert(0,str(P));from generate_steering_corner import output
for side in ['left','right']:
 for src,dst in [('steering_upright_'+side+'_C03_R05','steering_upright_rear_'+side+'_C03_R05'),('stationary_clamp_front_'+side+'_C03_R03','stationary_clamp_rear_'+side+'_C03_R03')]:
  s=cq.importers.importStep(str(P/(src+'.step'))).val().mirror('YZ')
  output(s,dst,{'status':'Original handed counterpart; load and complete motion qualification pending','source_original':src,'operation':'Mirror original B-rep through vehicle X=0, station-relative','placement':'Translate−1350mmX for rear station; no further reflection','source_COTS':'Do not apply this reflection to wheel/motor assets; proper source rotations retained'})
