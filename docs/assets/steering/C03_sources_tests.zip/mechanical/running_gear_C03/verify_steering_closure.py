"""Original C03 mathematical linkage and commercial angular-envelope checks only."""
from pathlib import Path
import json,math
import numpy as np
import steering_topology_study as m
P=Path(__file__).parent;v=m.v;L=m.L;v0=m.T/L;n0=np.array([0.,150,262]);n0/=np.linalg.norm(n0)
rows=[];fail=[]
for qd in np.linspace(-12,12,121):
 q=math.radians(qd)
 for r in np.linspace(-.075,.075,241):
  d=m.solve(q,r,1)
  if d is None:fail.append([qd,r,'no closure']);continue
  K=m.king+m.rx(q)@v-v;out=K+m.rz(d)@m.a;inn=m.inner+[0,r,0];u=(out-inn)/L
  c=float(v0@u);k=np.cross(v0,u);S=np.array([[0,-k[2],k[1]],[k[2],0,-k[0]],[-k[1],k[0],0]]);R=np.eye(3)+S+S@S/(1+c);n=R@n0
  tilt_inner=math.degrees(math.acos(np.clip((R@n0)@n0,-1,1)));tilt_outer=math.degrees(math.acos(np.clip(n@(m.rz(d)@n0),-1,1)))
  error=abs(np.linalg.norm(out-inn)-L)
  rows.append({'q_deg':float(qd),'rack_m':float(r),'steer_deg':math.degrees(d),'closure_error_m':float(error),'inner_tie_ball_tilt_deg':tilt_inner,'outer_tie_ball_tilt_deg':tilt_outer})
  if error>1e-8 or tilt_inner>24 or tilt_outer>24 or abs(math.degrees(d))>30:fail.append(rows[-1])
nom=[]
for r in [.025,.05,.075]:
 dl=m.solve(0,-r,1);dr=m.solve(0,-r,-1);Rl=.812+1.35/math.tan(dl);Rr=-.812+1.35/math.tan(dr)
 nom.append({'rack_m':-r,'left_steer_deg':math.degrees(dl),'right_steer_deg':math.degrees(dr),'ICR_from_left_m':Rl,'ICR_from_right_m':Rr,'ICR_difference_m':Rl-Rr})
r={'configuration':'C03 topology development R05','scope':'Analytical closure and catalogue angular envelope only; not B-rep collision, stiffness, force, dynamic or safety qualification','count':len(rows),'left_corner_only':'Right mirrors this geometry; front/rear configurations still require full assembly CAD checks','outer_pin_axis_at_neutral':n0.tolist(),'inner_pin_axis_at_neutral':n0.tolist(),'tie_hardware':'FK JMX12/JMXL12: both ends12-10HB pair15.875mm pin,total48° conservatively ±24°','outer_joint':'AIN16 with16-12HB, total60° conservatively ±30°','max_abs_steer_deg':max(abs(x['steer_deg']) for x in rows),'max_inner_tie_tilt_deg':max(x['inner_tie_ball_tilt_deg'] for x in rows),'max_outer_tie_tilt_deg':max(x['outer_tie_ball_tilt_deg'] for x in rows),'maximum_closure_error_m':max(x['closure_error_m'] for x in rows),'failures':fail,'nominal_Ackermann_screen':nom,'rows':rows}
(P/'steering_closure_C03_R05.json').write_text(json.dumps(r,indent=2));print({k:v for k,v in r.items() if k!='rows'})
