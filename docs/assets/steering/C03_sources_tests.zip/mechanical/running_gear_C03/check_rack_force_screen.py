"""Illustrative quasi-static steering screen. Assumed mass/friction, not actuator selection."""
from pathlib import Path
import json,math,numpy as np
import steering_topology_study as m
P=Path(__file__).parent;rows=[]
for qd in np.linspace(-12,12,49):
 q=math.radians(qd)
 for r in np.linspace(-.075,.075,151):
  factor=0;details=[]
  for side in [-1,1]:
   M=np.diag([1,side,1]);K=M@(m.king+m.rx(q)@m.v-m.v);a=M@m.a;d=m.solve(q,r,side);I=M@m.inner+[0,r,0]
   out=K+m.rz(d)@a;u=(out-I)/m.L;j=m.rz(d)@np.cross([0,0,1],a)
   deriv=abs(u[1]/float(u@j));factor+=deriv;details.append(deriv)
  rows.append({'q_deg':float(qd),'rack_m':float(r),'sum_abs_wheel_angle_derivative_rad_per_m':factor,'per_corner_derivatives':details})
peak=max(rows,key=lambda x:x['sum_abs_wheel_angle_derivative_rad_per_m']);Fz=1500*9.81/6;scrub=.128;mu=.6;torque=Fz*mu*scrub
r={'status':'Illustrative zero-speed friction screen; not an approved load case or exact tire contact model','assumptions':{'vehicle_mass_kg':1500,'equal_static_wheel_load_N':Fz,'friction_coefficient':mu,'geometric_lateral_scrub_arm_m':scrub,'vertical_kingpin':'Original baseline, no caster/trail','tire_contact_patch_torsion':'Excluded, unknown; can increase resistance','pin_friction_compliance_losses':'Excluded'},'peak_geometry':peak,'assumed_tire_resisting_torque_per_corner_Nm':torque,'rack_force_static_screen_N':torque*peak['sum_abs_wheel_angle_derivative_rad_per_m'],'rack_force_3g_same_friction_screen_N':3*torque*peak['sum_abs_wheel_angle_derivative_rad_per_m'],'actuator_candidate':{'B045_dynamic_capacity_N':4500,'full_load_speed_mm_s':19,'duty_fraction_at25C':.25,'150mm_lock_to_lock_time_at_full_load_s':150/19,'approval':'No steering suitability, response or safety approval'},'gates':['Manufacturer simultaneous radial/axial bearing loads','Finished linkage stiffness and buckling','Tire force envelope and steering on terrain','Dynamic steering duty and actuator temperature','Sensing, endplay1.2mm, fault response, emergency handling','Fastener fatigue and physical stop overload']}
(P/'rack_force_screen_C03_R01.json').write_text(json.dumps(r,indent=2));print(json.dumps(r,indent=2))
