"""Original C03 steering closure study. No hardware or load qualification."""
import json,math
from pathlib import Path
import numpy as np
from scipy.optimize import brentq
P=Path(__file__).parent
v=np.array([0.,.262,-.15]); king=np.array([0.,.812,-.25])
a=np.array([-.289,-.090,-.085])
# Match tie Y/Z vector to suspension Y/Z, with constant72 mm X skew to cancel neutral-rack bump steer.
T=np.array([.072,.262,-.15])
inner=king+a-T
L=np.linalg.norm(T)
def rx(q):
 c,s=np.cos(q),np.sin(q);return np.array([[1,0,0],[0,c,-s],[0,s,c]])
def rz(q):
 c,s=np.cos(q),np.sin(q);return np.array([[c,-s,0],[s,c,0],[0,0,1]])
def solve(q,r,side):
 # Reflect original steering arm across Y for right side, while retaining rearward X.
 M=np.diag([1.,side,1.]);K=M@(king+rx(q)@v-v);A=M@a;I=M@inner+np.array([0,r,0])
 S=K-I
 C=S[0]*A[0]+S[1]*A[1];D=-S[0]*A[1]+S[1]*A[0]
 E=(L*L-S@S-A@A)/2-S[2]*A[2]
 ratio=E/math.hypot(C,D)
 if abs(ratio)>1+1e-12:return None
 phi=math.atan2(D,C);alpha=math.acos(np.clip(ratio,-1,1))
 roots=[(phi+x+math.pi)%(2*math.pi)-math.pi for x in [alpha,-alpha]]
 return min(roots,key=abs)

rows=[]
for q in [-12,-6,0,6,12]:
 for r in [-.075,-.04,0,.04,.075]:
  for side in [-1,1]:
   d=solve(math.radians(q),r,side)
   rows.append(dict(q_deg=q,rack_m=r,side=side,steer_deg=None if d is None else math.degrees(d)))
report={'status':'mathematical topology only; physical joints, actuator, rack guides and clashes pending','units':'m, degrees','left_kingpin_midpoint':king.tolist(),'left_steering_arm_vector':a.tolist(),'left_inner_tie_joint':inner.tolist(),'tie_joint_distance_m':float(L),'rack_translation_axis':[0,1,0],'front_station_x_m':1.35,'rear_configuration':'reflect front mechanism about X=0 to obtain opposite steer; middle fixed','rows':rows,'gates':['No approved steering range','No selected actuator or force/duty validation','Spherical bearing misalignment and fork interference need full motion check','Full-scale tire/rim/drive envelope sweep pending','No steering linkage compliance, Ackermann optimization or stability validation']}
(P/'steering_topology_study.json').write_text(json.dumps(report,indent=2))
if __name__=='__main__': print(json.dumps(report,indent=2))
