from pathlib import Path
import json,math
import steering_topology_study as m
import cadquery as cq
P=Path(__file__).parent
U=cq.importers.importStep(str(P/'upper_wishbone_C03_R02.step')).val();L=cq.importers.importStep(str(P/'lower_wishbone_C03_R03.step')).val();K=cq.importers.importStep(str(P/'steering_upright_left_C03_R05.step')).val();pins=cq.importers.importStep(str(P/'outer_pins_left_C03_R01.step')).val()
W=cq.importers.importStep(str(Path(__file__).resolve().parents[2]/'wheels/wheel_C01.step')).val().translate((0,940,-250));ret=cq.importers.importStep(str(P/'housing_retainer_C03_R01.step')).val()
rows=[]
def test(a,s,b,t,q,d):
 vol=s.intersect(t).Volume();r={'q_deg':q,'steer_deg':d,'a':a,'b':b,'overlap_mm3':vol};rows.append(r);print(r,flush=True)
test('wheel',W,'upright',K,0,0);test('pins',pins,'upright',K,0,0)
for q in [-12,0,12]:
 a=math.radians(q);dy=262*math.cos(a)+150*math.sin(a)-262;dz=262*math.sin(a)-150*math.cos(a)+150
 u=U.rotate((0,550,70),(1,550,70),q);l=L.rotate((0,550,-270),(1,550,-270),q)
 ur=ret.translate((0,812,-80)).rotate((0,550,70),(1,550,70),q);lr=ret.translate((0,812,-420)).rotate((0,550,-270),(1,550,-270),q)
 for rack in [-.075,0,.075]:
  d=math.degrees(m.solve(a,rack,1))
  k=K.rotate((0,812,-250),(0,812,-249),d).translate((0,dy,dz));pin=pins.rotate((0,812,-250),(0,812,-249),d).translate((0,dy,dz))
  for n,s in [('upper',u),('lower',l),('upper_retainer',ur),('lower_retainer',lr)]:
   test(n,s,'upright',k,q,d);test(n,s,'pins',pin,q,d)
r={'status':'Sampled original geometry only, no physical bearing/spacer internal geometry or load approval','rows':rows,'failures':[r for r in rows if r['overlap_mm3']>1e-4]};(P/'corner_steering_C03_R05_check.json').write_text(json.dumps(r,indent=2));print('failures',len(r['failures']))
