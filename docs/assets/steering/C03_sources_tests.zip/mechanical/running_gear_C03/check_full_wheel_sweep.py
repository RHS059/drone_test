from pathlib import Path
import sys,json,math
import numpy as np
import cadquery as cq
import steering_topology_study as m
P=Path(__file__).parent
wheel=cq.importers.importStep(str(Path(__file__).resolve().parents[2]/'wheels/wheel_C01.step')).val()
body=cq.importers.importStep(str(Path(__file__).resolve().parents[2]/'body-power/body_power_R01.step')).val();frame=cq.importers.importStep(str(P.parent/'frame_R07.step')).val()
def near(a,b):
 a,b=a.BoundingBox(),b.BoundingBox();return not(a.xmax<b.xmin or b.xmax<a.xmin or a.ymax<b.ymin or b.ymax<a.ymin or a.zmax<b.zmin or b.zmax<a.zmin)
rows=[];count=0
for fore in [-1,1]:
 for side in [-1,1]:
  for qd in [-12,0,12]:
   q=math.radians(qd);dv=(m.rx(q)@m.v-m.v)*1000;dv[1]*=side
   for r in [-.075,0,.075]:
    d=fore*math.degrees(m.solve(q,r,side));king=(fore*1350,side*812,-250)
    w=wheel if side==1 else wheel.rotate((0,0,0),(0,0,1),180)
    w=w.translate((fore*1350,side*940,-250)).rotate(king,(king[0],king[1],king[2]+1),d).translate(tuple(dv))
    for name,comp in [('body',body),('frame',frame)]:
     for i,t in enumerate(comp.Solids()):
      if near(w,t):
       v=w.intersect(t).Volume();row={'station':fore*1350,'side':side,'q_deg':qd,'rack_m':r,'steer_deg':d,'part':name+'_'+str(i),'overlap_mm3':v};rows.append(row);print(row,flush=True)
    count+=1
r={'scope':'36 configurations, source-dimension original317.5mm tire/rim versus actual bodyR01/frameR07; selected8.5in rim actual tire width unknown; does not qualify340mm reservation','configuration_count':count,'checks':rows,'failures':[a for a in rows if a['overlap_mm3']>1e-4]}
(P/'full_wheel_sweep_C03_R01.json').write_text(json.dumps(r,indent=2));print('FAILURES',len(r['failures']),flush=True)
