"""Original connected steering lever and actual inclined pin clevis for sourced rod end."""
from pathlib import Path
import sys,math,json
import cadquery as cq
import numpy as np
P=Path(__file__).parent
sys.path.insert(0,str(P));from generate_steering_corner import output
base=cq.importers.importStep(str(P/'steering_upright_C03_R03.step')).val().rotate((0,0,0),(1,0,0),90).translate((0,797,-250))
v=np.array([0,262.,-150]);v/=np.linalg.norm(v);n=np.array([0,-v[2],v[1]])
ball=np.array([-289.,722.,-335.]);gap=46.6;thick=8
p=cq.Workplane(obj=base)
for side in [-1,1]:
 center=ball+side*(gap/2+thick/2)*n
 # Connect each plate to the actual carrier inner half, away from the motor pilot.
 target=np.array([-115.,772.,center[2]])
 s=(772-center[1])/v[1];endpoint=np.array([174.,s]);d=endpoint/np.linalg.norm(endpoint);perp=np.array([-d[1],d[0]])*12
 corners=[perp,endpoint+perp,endpoint-perp,-perp]
 plane=cq.Plane(origin=tuple(center-thick/2*n),xDir=(1,0,0),normal=tuple(n))
 ear=cq.Workplane(plane).polyline([tuple(x) for x in corners]).close().extrude(thick)
 ear=ear.union(cq.Workplane(plane).circle(20).extrude(thick))
 ear=ear.union(cq.Workplane(plane).center(*endpoint).circle(16).extrude(thick))
 ear=ear.cut(cq.Workplane(cq.Plane(origin=tuple(center-8*n),normal=tuple(n))).circle(8.15).extrude(16))
 p=p.union(ear)
left=p.val();right=left.mirror('XZ')
notes={'status':'Original connected fork and lever; all motion, load and fit checks pending','native_axes':'Already vehicle C millimetres at station X0','left_outer_tie_ball_mm':ball.tolist(),'outer_tie_pin_axis':n.tolist(),'rod_end':'FK JMX12/JMXL12 +12-10HB spacer pair','pin_nominal_mm':15.875,'clevis_hole_mm':16.3,'clevis_gap_mm':gap,'published_ball_plus_spacer_span_mm':46.355,'fasteners':'Actual pin, retention, bolt grade and washer stack unselected','right_geometry':'Original mirrored manufactured counterpart, baked into B-rep; source wheel/motor still use proper rotations'}
output(left,'steering_upright_left_C03_R05',notes);output(right,'steering_upright_right_C03_R05',notes)
