"""Domain-specific requirement graph. Unknown endpoints deliberately fail closure."""
from pathlib import Path
import json
P=Path(__file__).resolve().parent;O=P/'freeze_E04';parts={};ports={};edges=[];internal=[]
physical=json.loads((O/'electrical_connection_contract_E04.json').read_text());pd={r['id']:r for r in physical['ports']}
def dev(id,kind,part=None,installed=False):parts[id]={'kind':kind,'part':part,'installed_interface_model':installed,'operational':False}
def port(id,domain='DC_power',pin=None,source=False):
 d=pd.get(id);ports[id]={'device':id.split(':')[0],'domain':domain,'source_pin_or_function':pin or id.split(':')[1],'source_pinout_verified':source,'source_position_verified':bool(d and d.get('source_XYZ_verified')),'point_C_mm':d.get('source_blade_face_C_mm',d.get('source_hole_axis_C_mm'))if d else None,'physical_continuity_verified':False};return id
def cable(a,b,domain='DC_power',gates=None):
 edges.append({'id':f'WIRE_{len(edges):03}','from':a,'to':b,'domain':domain,'endpoints_physically_verified':False,'retained_cable_model':False,'status':'required_unclosed','gates':gates or ['Actual selected cable, route/clamps, mating retention and finished endpoint datum incomplete.']})
def conversion(id,inp,out,kind):internal.append({'id':id,'inputs':inp,'outputs':out,'kind':kind,'source_function_known':True,'configured_qualified':False})
def pair(id,funcs,domain='DC_power',source=True):return[port(id+':'+f,domain,f,source)for f in funcs]
for b in [1,2]:
 dev(f'BAT{b}','battery','BAT548110620');pair(f'BAT{b}',['+','-'])
 dev(f'FB{b}','required_positive_pack_fuse','rating≤100A, exact coordinated fuse/covered holder unresolved');pair(f'FB{b}',['IN','OUT'])
 dev(f'QB{b}','two_pole_isolator','OTDC160GV11-ESS',True);pair(f'QB{b}',['P_IN','P_OUT','N_IN','N_OUT'])
 cable(f'BAT{b}:+',f'FB{b}:IN');cable(f'FB{b}:OUT',f'QB{b}:P_IN');cable(f'BAT{b}:-',f'QB{b}:N_IN')
 conversion(f'FB{b}:fusing',[f'FB{b}:IN'],[f'FB{b}:OUT'],'positive branch overcurrent interruption')
 conversion(f'QB{b}:switching',[f'QB{b}:P_IN',f'QB{b}:N_IN'],[f'QB{b}:P_OUT',f'QB{b}:N_OUT'],'manual2pole isolation, ABB proposed DC circuit assignment requires confirmation')
dev('MERGE','required_battery_merge_bus','Covered retained equal-path two-pack positive/negative bus; not selected');pair('MERGE',['P1','P2','P','N1','N2','N'],source=False)
for b in [1,2]:cable(f'QB{b}:P_OUT',f'MERGE:P{b}');cable(f'QB{b}:N_OUT',f'MERGE:N{b}')
conversion('MERGE:parallel',['MERGE:P1','MERGE:P2','MERGE:N1','MERGE:N2'],['MERGE:P','MERGE:N'],'parallel positive and negative buses; positive/negative remain isolated')
dev('FMAIN','required_bank_positive_fuse','200A proposal, coordination unverified');pair('FMAIN',['IN','OUT']);cable('MERGE:P','FMAIN:IN');conversion('FMAIN:fusing',['FMAIN:IN'],['FMAIN:OUT'],'main positive overcurrent interruption')
dev('Q0','two_pole_main_isolator','OTDC250GV11-ESS',True);pair('Q0',['P_IN','P_OUT','N_IN','N_OUT']);cable('FMAIN:OUT','Q0:P_IN');cable('MERGE:N','Q0:N_IN');conversion('Q0:switching',['Q0:P_IN','Q0:N_IN'],['Q0:P_OUT','Q0:N_OUT'],'manual2pole isolation')
dev('LYNX','battery_management','LYN034170310',True);pair('LYNX',['BAT+','BAT-','SYS+','SYS-']);cable('Q0:P_OUT','LYNX:BAT+');cable('Q0:N_OUT','LYNX:BAT-');conversion('LYNX:contactor_precharge',['LYNX:BAT+'],['LYNX:SYS+'],'battery positive contactor/precharge');conversion('LYNX:shunt',['LYNX:BAT-'],['LYNX:SYS-'],'negative shunt')
for f,pin in [('ATC_COM','3'),('ATC_NO','4'),('ATD_COM','5'),('ATD_NO','6')]:port('LYNX:'+f,'safety_permission',pin,True)
for f,pin in [('AUX+','1'),('AUX-','2')]:port('LYNX:'+f,'battery_voltage_aux',pin,True)
dev('DIST','required_load_distribution','Protected covered DC distribution, exact hardware unresolved');pair('DIST',['P','N']+[f'P{i}'for i in range(1,12)]+[f'N{i}'for i in range(1,12)],source=False);cable('LYNX:SYS+','DIST:P');cable('LYNX:SYS-','DIST:N')
for i in range(1,7):
 inv=f'INV{i}';mot=f'M{i}';dev(f'FD{i}','traction_branch_protection','JLLN080.V candidate; exact covered holder and coordination unresolved');pair(f'FD{i}',['IN','OUT']);dev(f'KD{i}','traction_branch_contactor','AlbrightSW200-20/Sevcon82857026 configuration candidate');pair(f'KD{i}',['IN','OUT','COIL+','COIL-']);dev(inv,'DC_to_three_phase_inverter','Gen4Size2 exact48V/sincos factory variant unresolved',True)
 pair(inv,['B+','B-']);pair(inv,['U','V','W'],'three_phase_motor');pair(inv,['SIN','COS','SENSOR_SUPPLY','SENSOR_RETURN','TEMP'],'motor_feedback',False)
 for name,pin in [('KEY','1'),('CONTACTOR_LOW','3'),('CONTACTOR_SUPPLY','4'),('BRAKE_LOW','7'),('BRAKE_SUPPLY','8')]:port(inv+':'+name,'switching_control',pin,True)
 for name,pin in [('CAN_H','13'),('CAN_L','24')]:port(inv+':'+name,'CANopen_500k',pin,True)
 cable(f'DIST:P{i}',f'FD{i}:IN');cable(f'FD{i}:OUT',f'KD{i}:IN');cable(f'KD{i}:OUT',inv+':B+');cable(f'DIST:N{i}',inv+':B-');cable(inv+':CONTACTOR_SUPPLY',f'KD{i}:COIL+','switching_control');cable(inv+':CONTACTOR_LOW',f'KD{i}:COIL-','switching_control')
 conversion(f'FD{i}:fusing',[f'FD{i}:IN'],[f'FD{i}:OUT'],'branch fuse');conversion(f'KD{i}:contact',[f'KD{i}:IN'],[f'KD{i}:OUT'],'branch contactor; reverse regen opening unqualified');conversion(inv+':power_stage',[inv+':B+',inv+':B-'],[inv+':U',inv+':V',inv+':W'],'three_phase inverter with separate KEY-controlled branch precharge')
 dev(mot,'IPM_motor_and_reduction','WD220-SMAC132-050-48V-EMB-5STUDS');pair(mot,['U','V','W'],'three_phase_motor',True);pair(mot,['SIN','COS','SUPPLY','RETURN','KTY1','KTY2'],'motor_feedback',True);pair(mot,['BRK+','BRK-'],'parking_brake_coil',True)
 for phase in ['U','V','W']:cable(inv+':'+phase,mot+':'+phase,'three_phase_motor',['No labelled OEM exit XYZ/mating connector; phase routing remains unresolved at motor; phase current47Arms is not DC branch current.'])
 for a,b in [('SIN','SIN'),('COS','COS'),('SENSOR_SUPPLY','SUPPLY'),('SENSOR_RETURN','RETURN'),('TEMP','KTY1')]:cable(inv+':'+a,mot+':'+b,'motor_feedback',['Exact RM44 encoder supply/commonmode/phasing and Gen4 sin/cos pin21-versus31 documentation conflict unresolved.'])
 cable(inv+':B-',mot+':KTY2','motor_feedback',['Gen4 temperature return source referencesB−; exact sensor wiring/isolated thermal variant approval remains open. This is a temperature lead, not a motor power DC return.'])
 cable(inv+':BRAKE_SUPPLY',mot+':BRK+','parking_brake_coil');cable(inv+':BRAKE_LOW',mot+':BRK-','parking_brake_coil')
for i in [1,2]:
 dev(f'UR{i}','robot_controller','UR20OEMDC19..72V');pair(f'UR{i}',['P','N']);dev(f'URSOFT{i}','required_UR_inrush_branch','Source-required softstart, exact rated circuit not complete');pair(f'URSOFT{i}',['P_IN','N_IN','P_OUT','N_OUT']);cable(f'DIST:P{6+i}',f'URSOFT{i}:P_IN');cable(f'DIST:N{6+i}',f'URSOFT{i}:N_IN');cable(f'URSOFT{i}:P_OUT',f'UR{i}:P');cable(f'URSOFT{i}:N_OUT',f'UR{i}:N')
 dev(f'STR{i}','steering_actuator','ThomsonHD48B068200COO candidate');pair(f'STR{i}',['POWER_RED','POWER_BLACK']);pair(f'STR{i}',['SIGNAL_BLUE','SIGNAL_BROWN'],'CANopen_500k');dev(f'KSTR{i}','required_external_steering_switch','Exact safety switching component not selected');pair(f'KSTR{i}',['IN','OUT','COIL+','COIL-']);cable(f'DIST:P{8+i}',f'KSTR{i}:IN');cable(f'KSTR{i}:OUT',f'STR{i}:POWER_RED');cable(f'DIST:N{8+i}',f'STR{i}:POWER_BLACK')
 # Explicitly no fictitious actuator INHIBIT input.
dev('CTRL','vehicle_controller_candidate','ifmCR711S');pair('CTRL',['24V','0V'],'24V_aux');dev('GX','battery_telemetry_gateway','CerboGX candidate');pair('GX',['VE_CAN_H','VE_CAN_L'],'VE_Can_250k');pair('GX',['ETHERNET'],'Ethernet');pair('CTRL',['ETHERNET'],'Ethernet');cable('GX:ETHERNET','CTRL:ETHERNET','Ethernet',['Battery service registers307/308/318/319 read-only; actual UnitID discovery and stale-data fail-safe remain unimplemented.'])
for bus in [1,2]:pair('CTRL',[f'CAN{bus}_H',f'CAN{bus}_L'],'CANopen_500k'if bus==1 else'raw_CAN_500k',False)
for i in range(1,7):
 for f in ['H','L']:cable('CTRL:CAN1_'+f,f'INV{i}:CAN_'+f,'CANopen_500k',['Exact bus routing,120Ωend termination, ground/isolation and commissioned node configuration open.'])
for i in [1,2]:
 cable('CTRL:CAN1_H',f'STR{i}:SIGNAL_BLUE','CANopen_500k');cable('CTRL:CAN1_L',f'STR{i}:SIGNAL_BROWN','CANopen_500k')
for i in range(1,12):
 dev(f'IS{i}','current_sensor_candidate','LEM CAB500-C/SP7');
 for name,pin,dom in [('CAN_L','A','raw_CAN_500k'),('CAN_H','B','raw_CAN_500k'),('GND','C','12V_aux'),('UC','D','12V_aux')]:port(f'IS{i}:'+name,dom,pin,True)
 for f in ['H','L']:cable('CTRL:CAN2_'+f,f'IS{i}:CAN_'+f,'raw_CAN_500k',['LEM8..16V requires12Vsupply; unique rawCAN IDs and SP7 configuration applicability unqualified.'])
source={'battery':'https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/installation.html','lynx':'https://www.victronenergy.com/media/pg/Lynx_Smart_BMS_NG/en/installation.html','ifm':'https://www.ifm.com/ae/en/product/CR711S','lem':'https://www.lem.com/sites/default/files/products_datasheets/cab_500-c_spx_public_datasheet_v4.pdf','gx_registers':'https://www.victronenergy.com/upload/documents/CCGX-Modbus-TCP-register-list-3.81.xlsx','thomson':'https://www.thomsonlinear.com/downloads/actuators/Electrak_HD_Actuator_bren.pdf'}
for e in edges:assert e['from']in ports and e['to']in ports
assert not any(k.startswith('M')and k.split(':')[-1]in ['DC_RETURN','B-','B+']for k in ports)
assert not any('STR' in k and 'INHIBIT'in k for k in ports)
out={'revision':'E04','type':'required electrical topology with explicit unclosed cable endpoints','parts':parts,'ports':ports,'cables':edges,'internal_functional_conversions':internal,'sources':source,'all_required_cable_endpoints_closed':False,'installed_full_system':False,'enforced_current_limit':False,'warm_bank_development_limit_A':180,'temperature_limits':'victron_candidate/temperature_limit_tests.json','ATC_regen_permission_path':{'pins':['LYNX:ATC_COM','LYNX:ATC_NO'],'24V_potential_free_wetting_required':True,'not_connected_to_48V_AUX':True,'controller_input_mapping':None,'Gen4_regen_inhibit_command_mapping':None,'independent_brake_or_sink_selected':False,'complete':False},'ATD_load_permission_path':{'pins':['LYNX:ATD_COM','LYNX:ATD_NO'],'fast_vehicle_stop_implemented':False,'BMS_delayed_violation_not_used_for_stop_timing':True},'required_remaining_control_functions':['Per-pack branch current and imbalance monitoring','Temperature-aware minimum of actualBMSDCL/CCL, source conservative bank envelope and180A warm ceiling','Deduct arm/aux current before traction allocation','No-regeneration demand whenATCopen or no safe charge headroom','Stale/lost telemetry inhibits drive permission; exact hardwired stop chain unqualified','DualchannelEstop/manualreset/contactorfeedback architecture and service brake validation'],'source_gen4_pin_conflict':'SIN21 table/figure versus31 prose; exact configured encoder hardware unresolved','configuration_not_commissioned':True}
(O/'electrical_topology_E04.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'devices':len(parts),'ports':len(ports),'required_cables':len(edges),'conversions':len(internal),'complete':False}))
