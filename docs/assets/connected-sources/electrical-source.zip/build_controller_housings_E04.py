"""Six visible original source-dimensional Gen4 Size2 housing interfaces.
No proprietary geometry imported. Exact factory option and terminalZ remain open.
"""
from pathlib import Path
import cadquery as cq,json,hashlib
import cad_export as ce
P=Path(__file__).resolve().parent;O=P/'victron_candidate/controllers_E04';O.mkdir(exist_ok=True);ce.P=O
F=json.loads((P/'source_facts.json').read_text());C=json.loads((P/'carrier_freeze_E02/connection_contract.json').read_text());parts=[];facts=[]
box,bore,cyl=ce.box,ce.bore,ce.cyl
for i in range(1,7):
 ref=f'INV{i}';n=next(n for n in C['nodes']if n['id']==ref);cx,cy,cz=[v*1000 for v in n['center_C_m']]
 base=box(165,187,12,(cx,cy,cz+6));shell=box(165,187,59,(cx,cy,cz+41.5)).cut(box(159,181,57,(cx,cy,cz+40.5)))
 for x,y in F['controller_interface']['mount_centers_mm']:
  base=bore(base,cx+x,cy+y,3.5,cz-1,14);shell=bore(shell,cx+x,cy+y,10,cz+11.9,60)
 for label in ['M1','M2','M3','Bminus','DCplus']:
  x,y=F['controller_interface']['power_terminal_XY_mm'][label];x+=cx;y+=cy
  # Original insulated support reaches source-proposed terminal plane, does not certify OEMZ.
  shell=bore(shell,x,y,11,cz+11.9,60)
  sign=-1 if label in ['DCplus','Bminus'] else 1
  shell=shell.cut(box(22,55,14,(x,y+sign*17,cz+65)))
  support=cyl(11,53,(x,y,cz+12)).cut(cyl(9,15,(x,y,cz+50)))
  terminal=cyl(9,15,(x,y,cz+50)).cut(cyl(3,15,(x,y,cz+50)))
  parts.append((ref+'_'+label+'_original_insulated_terminal_support',support,'housing','Original geometric support to proposedZ65; exact OEM insulation and internal attachment unverified.'))
  parts.append((ref+'_'+label+'_M6_source_XY_terminal_interface',terminal,'copper','SourceXY andM6 internal thread; proposedZ65 and originalØ18×15 body, nominal cylindrical thread-contact. Terminal location/depth/current path not supplier-qualified.'))
 # Original header support face at proposed matingZ71. Actual OEM header identity/orientation unverified.
 socket=box(63.4,34.6,6,(cx,cy+70.5,cz+68));shell=shell.cut(box(63.4,34.6,7,(cx,cy+70.5,cz+68)))
 parts.extend([(ref+'_source_dimensional_base',base,'steel','Source165×187base,12mm source legacy thickness,151×173M6mount pattern; current ordered revision pending.'),(ref+'_original_max_housing_shell',shell,'housing','Original max shell165×187×71overall with access wells. Exterior contours and internals not OEM reconstruction.'),(ref+'_proposed_AMPSEAL_header_interface',socket,'housing','Proposed support under existing776164-1 interface atZ71. Exact supplierheader/latch andcontact engagement unresolved.')])
 facts.append({'device':ref,'origin_C_mm':[cx,cy,cz],'overall_source_envelope_mm':[165,187,71],'mount_axes_C_mm':[[cx+x,cy+y,cz]for x,y in F['controller_interface']['mount_centers_mm']],'source_XY_verified':True,'legacy_base_thickness_mm':12,'source_current_configured_variant_verified':False,'terminal_contact_plane_relative_Z_mm':65,'terminal_Z_source_verified':False,'actual_signal_header_frame_verified':False,'internal_inverter_geometry_modeled':False})
meta=ce.export('controller_housing_interfaces_E04',parts,{'source':'Gen4 Size2 public legacy drawing numeric envelope/base/mount/terminalXY plus original interface design','vehicle_placed':True})
# Internal housings/terminals contact nominally; assembled existing carrier/bolt/lug check follows independently.
conf=[]
for i,(n,s,_,_)in enumerate(parts):
 for m,t,_,_ in parts[i+1:]:
  a=s.BoundingBox();b=t.BoundingBox()
  if any(getattr(a,k)>getattr(b,k.replace('min','max'))+1e-6 or getattr(b,k)>getattr(a,k.replace('min','max'))+1e-6 for k in ['xmin','ymin','zmin']):continue
  v=s.intersect(t).Volume()
  if v>1e-4:conf.append({'a':n,'b':m,'volume_mm3':v})
out={'revision':'E04','geometry':meta,'devices':facts,'parts':[{'name':n,'solids':len(s.Solids()),'volume_mm3':s.Volume(),'material':mat}for n,s,mat,_ in parts],'self_overlaps':conf,'self_geometry_pass':not conf,'source_terminal_physical_attachment_verified':False,'source_controller_motor_compatibility_verified':False,'electrical_commissioned':False,'model_is_original_dimensioned_interface':True}
(O/'controller_housing_contract_E04.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'parts':len(parts),'self_overlaps':conf}))
