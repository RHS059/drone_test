"""Original rear-trough revision and source-dimensional LAPP partition glands.
Writes a delta package only. No whole-body file is changed.
"""
from pathlib import Path
import cadquery as cq,json,math
import cad_export as ce
P=Path(__file__).resolve().parent;O=P/'victron_candidate/switchgear_E04';ce.P=O
box,cyl=ce.box,ce.cyl
parts=[];welds=[];changes=[]
def add(n,s,mat='steel',note='Original welded body component; strength unqualified.'):
 assert s.isValid();parts.append((n,s,mat,note));return s
# Common alignment closes the old rear-to-battery/tool trough discontinuity.
specs=[(1,-1863,-1173,-1897,-1143,'rear_bulkhead_3mm','controller_battery_partition'),(2,-1125,-475,-1140,-460,'controller_battery_partition','battery_tool_partition'),(3,-440,520,-457,547,'battery_tool_partition','arm_facing_bulkhead_3mm')]
for i,x0,x1,wa,wb,an,bn in specs:
 floor=add(f'cable_duct_floor_{i}',box(x1-x0,62,2,((x0+x1)/2,515,251)))
 changes.append({'action':'replace','name':f'cable_duct_floor_{i}'})
 for old_y,y in [(400,484),(470,546)]:
  name=f'cable_duct_side_{i}_{y}';add(name,box(x1-x0,2,40,((x0+x1)/2,y,272)))
  changes.extend([{'action':'remove','name':f'cable_duct_side_{i}_{old_y}'},{'action':'add','name':name}]);welds.append({'a':f'cable_duct_floor_{i}','b':name,'seam':f'{x1-x0} mm longitudinal contact edge; proposed same-alloy seam weld.','strength_qualified':False})
 for label,wall,tip,host in [('rear',wa,x0+25,an),('front',wb,x1-25,bn)]:
  xa,xb=sorted([wall,tip]);sh=box(xb-xa,62,3,((xa+xb)/2,515,248.5))
  for y in [487.5,520]:
   g=cq.Workplane('XZ').polyline([(wall,223),(wall,247),(tip,247)]).close().extrude(3).translate((0,y,0)).val();sh=sh.fuse(g)
  n=f'cable_duct_{i}_{label}_welded_support';add(n,sh);changes.append({'action':'replace','name':n});welds.extend([{'a':n,'b':host,'seam':'62×3 mm shelf edge plus two24×3 mm gusset roots; source-material contact must pass after SO01.','strength_qualified':False},{'a':n,'b':f'cable_duct_floor_{i}','seam':'25×62 mm bearing overlap plus edge welds.','strength_qualified':False}])
# Original maximum gland housings; actual source clamp range6–13mm includes10.3mm cable.
# Source thread9mm with3mm panel and6mm source locknut is flush, not overengaged.
for y in [366.5,443.5]:
 z=182.25;n=f'QB2_partition_gland_{y}'
 def tx(s):return s.rotate((0,0,0),(0,1,0),-90).translate((-1143,y,z))
 tube=cq.Workplane('XY').circle(10).circle(6.5).extrude(9).translate((0,0,-9)).val()
 hexbody=cq.Workplane('XY').polygon(6,25/math.cos(math.pi/6)).circle(6.5).extrude(6).val().intersect(cyl(13.8,6,(0,0,0)))
 cap=cq.Workplane('XY').circle(13.8).circle(5.15).extrude(22).translate((0,0,6)).val()
 add(n+'_53111020_body',tx(tube.fuse(hexbody).fuse(cap)),'cover','Source maximum37mm overall including9mm thread,25mmAF,27.6mm cap diameter. Internal shoulder/clamp contour original; seal pullout/IP not qualified.')
 nut=cq.Workplane('XY').polygon(6,27/math.cos(math.pi/6)).circle(10).extrude(6).translate((0,0,-9)).val().intersect(cyl(14.85,6,(0,0,-9)))
 add(n+'_53119020_locknut',tx(nut),'cover','Source6mm thickness,27mmAF. Nominal M20×1.5 cylindrical thread-equivalent against gland thread; no helix/tolerance/preload model.')
 changes.extend([{'action':'add','name':n+'_53111020_body'},{'action':'add','name':n+'_53119020_locknut'}])
meta=ce.export('aligned_trough_and_glands_E04',parts,{'source':'Original project body geometry; LAPP53111020/53119020 public dimensions','vehicle_placed':True})
holes=[{'id':f'QB2_partition_gland_{y}','target_part':'controller_battery_partition','axis_C_mm':[-1141.5,y,182.25],'direction_C':[1,0,0],'diameter_mm':20.2,'cut_x_mm':[-1144,-1139],'gland':'LAPP53111020','nut':'LAPP53119020','gland_axis_toward_cable_C':[-1,0,0],'gland_panel_seat_X_mm':-1143,'physical_patch_applied':False}for y in [366.5,443.5]]
report={'revision':'E04','changes':changes,'welded_connections':welds,'partition_hole_cutters':holes,'partition_trunk_slots':[{'target_part':n,'center_C_mm':[x,515,273],'size_xyz_mm':[10,64,42],'purpose':'Aligned open-trough passage, lower edgeZ252 above support weld-rootZ250. Edge stiffness, weather isolation and grommet finish not released.'}for n,x in [('controller_battery_partition',-1141.5),('battery_tool_partition',-458.5)]],'parts':[{'name':n,'bounds_mm':[s.BoundingBox().xmin,s.BoundingBox().ymin,s.BoundingBox().zmin,s.BoundingBox().xmax,s.BoundingBox().ymax,s.BoundingBox().zmax],'solids':len(s.Solids())}for n,s,_,_ in parts],'geometry':meta,'gland_source_urls':['https://products.lappgroup.com/fileadmin/documents/technische_doku/datenblaetter/skintop/DB53111000EN.pdf','https://imager.lapp.com/e/lapp/IxNMTvvLiYtWEfUsJRUaNg~~/DB53119000EN.pdf'],'installed_clamp_or_IP_tested':False,'full_cable_continuity':False,'freeze':False}
(O/'rear_trough_patch_contract.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'parts':len(parts),'holes':holes}))
