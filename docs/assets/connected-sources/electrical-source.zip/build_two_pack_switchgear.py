"""Original source-dimension ABB installed layout, terminal lugs and retained trays.
Does not import supplier CAD. Numeric foot facts were independently inspected from ABB STEP.
"""
from pathlib import Path
import cadquery as cq,json,math,hashlib
import cad_export as ce
P=Path(__file__).resolve().parent;O=P/'victron_candidate'/'switchgear_E04';O.mkdir(parents=True,exist_ok=True);ce.P=O
box,bore,cyl=ce.box,ce.bore,ce.cyl
facts=json.loads((P/'cover_research/abb_installed_interface_facts.json').read_text());(O/'abb_interface_facts.json').write_text(json.dumps(facts,indent=2)+'\n')
parts=[];devices=[];mounts=[];terms=[];holes=[];shaft_patches=[]
def washer(ro,ri,t,z,x=0,y=0):return cq.Workplane('XY').circle(ro).circle(ri).extrude(t).translate((x,y,z)).val()
def bolt(r,L,under,af,hh,x=0,y=0):return cyl(r,L,(x,y,under-L)).fuse(cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(hh).translate((x,y,under)).val())
def nut(r,t,z,af,x=0,y=0):return cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).circle(r).extrude(t).translate((x,y,z)).val()
def save(name,shape,mat='housing',note='Original dimensional interface; not an exact supplier contour.'):
 assert shape.isValid(),name;parts.append((name,shape,mat,note))
def tf(s,p):return s.rotate((0,0,0),(0,0,1),-90).translate(p)
def tp(q,p):return [p[0]+q[1],p[1]-q[0],p[2]+q[2]]
poses=[('QB1',(-1660,365,117)),('QB2',(-1320,405,117)),('Q0',(-1560,-370,117))]
for ref,p in poses:
 def add(tag,shape,mat='housing',note='Original source-dimensional interface; source contour simplified.'):
  save(ref+'_'+tag,tf(shape,p),mat,note)
 base=box(146,115,2,(0,0,1))
 for x in [-67,67]:
  for y in [-50.5,50.5]:base=bore(base,x,y,2.75,-1,4)
 add('mount_foot_interface',base,'steel','Original base interpolation. Source ABB foot supportZ0/clampZ2, slotsXY±67/±50.5 and5.5 CAD diameter verified; actual bent contour simplified.')
 housing=box(134,115,108,(0,0,56))
 for xx in [-67,67]:
  for yy in [-50.5,50.5]:housing=bore(housing,xx,yy,5.5,1.9,8)
 add('max_housing',housing,note='Maximum original housing interpolation with four mounting-screw clearances; not exact vendor contour.')
 add('shaft_mechanism_interface',box(40,35,10,(0,0,115)),note='Source maximum depth120; exact center mechanism contour simplified. Extension shaft not completed.')
 # Original source-external cover shell reaches the documented body mating plane.
 for x in [-38.5,38.5]:
  for sy in [-1,1]:
   shell=box(38.5,99.3,110,(x,sy*107.15,55)).cut(box(34.5,99.4,106,(x,sy*106.1,55)))
   # Open terminal exit for actual conductor, leaving cover edge profile original.
   shell=shell.cut(box(28,5,32,(x,sy*156,67)))
   add(f'OTDCS200GG1_{x}_{sy}',shell,'cover','Source installed external sectionY57.5…156.8,Z0…110.2mm shell/exit contour original.24.8mm attachment tabs and snap-lock geometry unmodeled, retention gate open.')
 # Real M5 mounting interfaces. 2mm foot+3mm tray+2x1washer+4nut;16mm bolt,5mm protrusion.
 for k,(x,y) in enumerate([(x,y)for x in [-67,67]for y in [-50.5,50.5]]):
  stem=f'mount{k}';add(stem+'_M5x16',bolt(2.5,16,3,8,3.5,x,y),'steel','M5x0.8 nominal cylindrical thread-equivalent, grade/tolerance/preload unqualified.')
  add(stem+'_upper_washer',washer(5,2.7,1,2,x,y),'steel');add(stem+'_lower_washer',washer(5,2.7,1,-4,x,y),'steel');add(stem+'_M5nut',nut(2.5,4,-8,8,x,y),'steel','Nominal cylindrical thread contact; no modeled helix.')
  mounts.append({'id':ref+'_'+stem,'supported':ref,'support':ref+'_tray','source_mount_axis_C_mm':tp([x,y,0],p),'source_XYZ_verified':True,'foot_mm':2,'tray_mm':3,'bolt':'M5x16, project coarse pitch0.8mm','nut_height_mm':4,'protrusion_mm':5,'thread_representation':'equivalent cylindrical contact','supplier_torque_Nm':None,'locking_grade_strength_verified':False})
 # Source blade palms; project assignment is not an invented OEM molded terminal number.
 for x in [-38.5,38.5]:
  for sy in [-1,1]:
   y=71*sy;fun=('P_'if x<0 else'N_')+('IN'if sy>0 else'OUT');stem='terminal_'+fun
   tab=box(19.5,25,3,(x,70*sy,57.5));tab=bore(tab,x,y,4.5,55,5);add(stem+'_blade',tab,'copper','Source blade rearZ56/frontZ59,19.5width,Ø9 hole. Terminal assignment is project circuit2a proposal, floating DC install still unqualified.')
   main=ref=='Q0';od=16.5 if main else 12.5;inner=12 if main else 8.2;length=43;barrel=21 if main else 20.5;palm_t=4 if main else 3;pre=10 if main else 10.5
   # Lug source width17,length43; explicit original palm thickness/shoulder interpolation.
   paddle=box(17,2*pre,palm_t,(0,0,palm_t/2));paddle=bore(paddle,0,0,4.25 if main else 4.2,-1,palm_t+2)
   tube=cq.Workplane('XZ').circle(od/2).circle(inner/2).extrude(-barrel).translate((0,length-pre-barrel,od/2)).val()
   bridge=box(12,5,palm_t,(0,11,palm_t/2));lug=paddle.fuse(bridge).fuse(tube)
   if sy<0:lug=lug.rotate((0,0,0),(0,0,1),180)
   lug=lug.translate((x,y,59));add(stem+('_7SG8_lug'if main else'_105R8_lug'),lug,'copper','Source Klauke narrow17mm palm; original thickness/shoulder. Main7SG8 uses EKM60ID/EK30ID for fine-stranded conductor; exact crimp approval remains open.')
   upper=59+palm_t;under=upper+1.6;L=20;lowerz=54.4;nutbottom=47.9
   add(stem+'_M8x20',bolt(4,L,under,13,5.3,x,y),'steel','Project M8x1.25 smooth thread equivalent; ABB torque and exact lug stack require qualification.')
   add(stem+'_upper_washer',washer(8,4.2,1.6,upper,x,y),'steel');add(stem+'_lower_washer',washer(8,4.2,1.6,lowerz,x,y),'steel');add(stem+'_M8nut',nut(4,6.5,nutbottom,13,x,y),'steel')
   mouth=tp([x,y+sy*(length-pre),59+od/2],p)
   terms.append({'id':ref+':'+fun,'source_blade_face_C_mm':tp([x,y,59],p),'source_blade_hole_diameter_mm':9,'source_XYZ_verified':True,'project_polarity_and_circuit_assignment_verified':False,'lug':'7SG8'if main else'105R8','lug_palm_width_mm':17,'lug_palm_thickness_original_assumption_mm':palm_t,'wire_mouth_C_mm':mouth,'outward_axis_C':[sy,0,0],'nominal_conductor_mm2':70 if main else 35,'actual_cable_candidate':'LAPP0060001'if main else'LAPP0058001/0058104','cable_nominal_OD_mm':14.2 if main else 10.3,'minimum_static_bend_radius_mm':85.2 if main else 61.8,'ampacity_crimp_route_release':False,'bolt':'M8x20','thread_engagement_nut_mm':6.5,'protrusion_mm':nutbottom-(under-L),'source_terminal_contact_complete':True,'physical_electrical_connection_verified':False})
 # Original carrier, cantilevered outside the frame rail. All deck fasteners remain inboard of Y410.
 cx,cy,z=p;trayw=168
 tray=box(170,trayw,3,(cx,cy,z-1.5))
 for x in [-67,67]:
  for y in [-50.5,50.5]:q=tp([x,y,0],p);tray=bore(tray,q[0],q[1],2.75,z-4,6)
 ys={'QB1':[315,375],'QB2':[335,375],'Q0':[-315,-375]}[ref]
 for xx in [cx-70,cx+70]:
  for yy in ys:
   tray=bore(tray,xx,yy,3.3,z-4,6);stem=f'{ref}_deck_{xx}_{yy}'
   leg=box(14,14,11,(xx,yy,108.5));leg=bore(leg,xx,yy,3.3,102,13);save(stem+'_leg',leg,'steel','Original11mm support; material and cantilever strength unqualified.')
   save(stem+'_M6x30',bolt(3,30,z+1.6,10,4,xx,yy),'steel','M6x1 nominal thread-equivalent; original 3+11+3 grip and retained nut.')
   save(stem+'_upper_washer',washer(6,3.2,1.6,z,xx,yy),'steel');save(stem+'_lower_washer',washer(9,3.2,1.6,98.4,xx,yy),'steel');save(stem+'_M6nut',nut(3,5,93.4,10,xx,yy),'steel')
   holes.append({'id':stem,'target_part':'main_base_deck_3mm','center_C_mm':[xx,yy,100],'diameter_mm':6.6,'cut_z_mm':[99,104],'leg_top_z_mm':114,'tray_top_z_mm':117,'nut_bottom_z_mm':93.4,'bolt_tip_z_mm':88.6,'thread_proxy':'M6x1 nominal cylindrical contact','body_patch_applied':False})
 save(ref+'_tray',tray,'steel','Original3mm tray.12 new deck holes separate from carrier R02 patch; cantilever strength unqualified.')
 devices.append({'id':ref,'model':'OTDC250GV11-ESS'if ref=='Q0'else'OTDC160GV11-ESS','origin_C_mm':list(p),'rotation_C_from_local':[0,0,-90],'source_installed_cover_envelope_local_mm':[146,313.6,120],'source_verified_blade_and_mount_XYZ':True,'geometry_original':True,'housing_contour_exact':False,'source_CAD_read_for_numeric_foot_interface':True,'shroud':'4xOTDCS200GG1','shroud_attachment_tabs_and_locks_modeled':False,'handle':'OHB65J6 front operation','shaft':'OXP6X210','shaft_cut_length_verified':False,'handle_and_shaft_assembly_installed':False,'physical_assembly_acceptance':False})
 # Door dimensions are requested patches only until shaft seat/length and actual hardware are verified.
 target='rear_controller_hatch_removable_lid'
 shaft_patches.append({'id':ref,'target_part':target,'outside_door_z_mm':345,'door_thickness_mm':3,'shaft_hole_center_C_mm':[cx,cy,345],'shaft_hole_diameter_mm':31,'screw_holes_C_mm':[[cx+d,cy+d,345] for d in [-18.7383297,18.7383297]],'screw_hole_diameter_mm':5,'shaft_tip_z_range_mm':[363.5,367],'closed_handle_max_z_mm':390.8,'padlock_open_max_z_mm':426.8,'apply_patch_now':False,'reason':'Shaft seat/cut length and handle hardware unresolved; do not cut until installation frame is frozen.'})
meta=ce.export('installed_isolators_E04',parts,{'source':'ABB installation2026 + original supports + Klauke lugs','source_CAD_read':True,'vehicle_placed':True,'frame':'Vehicle C mm','not_commissioned':True})
result={'revision':'E04','scope':'Three source-dimensional isolator candidates with mounted terminal interfaces,12 shroud shells and retained original trays. Shaft/handle assembly, exact clips, cable bends and electrical qualification remain open.','devices':devices,'mounts':mounts,'power_terminals':terms,'body_deck_patch':holes,'deferred_hatch_patch':shaft_patches,'geometry':meta,'validation_pending':True,'source_supplier_geometry_included':False,'source_motor_geometry_read':False,'protection_or_safety_released':False}
(O/'isolator_placement_contract.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'parts':len(parts),'devices':len(devices),'source_terminals':len(terms),'new_deck_holes':len(holes),'geometry_valid':True,'physical_acceptance':False}))
