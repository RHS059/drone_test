"""Offline requirement model only. Not deployed, timed, or safety-qualified control code.
Uses the more restrictive source-plot value at every discontinuity.
"""
from math import isfinite
SOURCE='https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/operation.html'
def individual_limits(t):
 if not isinstance(t,(int,float)) or not isfinite(t):return (0,0)
 discharge=0 if t<=-20 or t>=50 else 50 if t<=0 or t>=35 and t<45 else 30 if t>=45 else 100
 charge=0 if t<=5 or t>=50 else 20 if t<=10 else 30 if t<=15 or t>=35 else 50
 return discharge,charge

def bank_limits(temperatures,online,ATC,ATD,DCL,CCL,auxiliary_A,valid_telemetry):
 if not valid_telemetry or len(temperatures)!=2 or online!=[True,True] or any(not isfinite(x) for x in [DCL,CCL,auxiliary_A]):
  return {'traction_A':0,'regen_A':0,'motion_enable':False,'reason':'Missing/stale data or a pack is offline; validated stop required.'}
 limits=[individual_limits(t) for t in temperatures]
 # Twice the lower individual value avoids relying on equal temperature sharing.
 discharge=max(0,min(180,DCL,2*min(x[0]for x in limits))) if ATD else 0
 charge=max(0,min(CCL,2*min(x[1]for x in limits))) if ATC else 0
 # Even nonzero electrical budgets do not establish a safe drive system.
 return {'traction_A':max(0,discharge-max(0,auxiliary_A)),'regen_A':charge,'motion_enable':False,'reason':'Requirement calculation only; brake/sink, motor pairing and enforcement are not commissioned.'}

if __name__=='__main__':
 import json
 from pathlib import Path
 expected={-21:(0,0),-20:(0,0),-10:(50,0),0:(50,0),5:(100,0),7:(100,20),10:(100,20),12:(100,30),15:(100,30),25:(100,50),35:(50,30),40:(50,30),45:(30,30),49:(30,30),50:(0,0),51:(0,0)}
 for t,v in expected.items():assert individual_limits(t)==v,(t,individual_limits(t))
 warm=bank_limits([25,25],[True,True],True,True,200,200,20,True);assert warm['traction_A']==160 and warm['regen_A']==100 and not warm['motion_enable']
 cold=bank_limits([0,25],[True,True],True,True,200,200,20,True);assert cold['traction_A']==80 and cold['regen_A']==0
 noATC=bank_limits([25,25],[True,True],False,True,200,200,20,True);assert noATC['regen_A']==0
 lost=bank_limits([25,25],[True,False],True,True,200,200,20,True);assert lost['traction_A']==0
 bad=bank_limits([25,25],[True,True],True,True,float('nan'),200,20,True);assert bad['traction_A']==0
 out={'source':SOURCE,'source_plot_text_discrepancy':'General datasheet charge100A/pack; operation plot50A/pack maximum at15–35C. Lower plot governs this candidate.','boundary_policy':'At all discontinuities use lower limit; no operation at exact outer boundaries until measurement error/hysteresis is specified.','test_count':21,'all_assertions_pass':True,'rows':[{'cell_temperature_C':t,'discharge_A_each':v[0],'charge_A_each':v[1]}for t,v in expected.items()],'warm_with20A_aux':warm,'mixed_cold':cold,'ATC_open':noATC,'lost_pack':lost,'implemented_vehicle_enforcement':False,'motion_enable':False,'safety_release':False}
 Path(__file__).with_name('temperature_limit_tests.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'test_count':21,'pass':True,'vehicle_control_implemented':False}))
