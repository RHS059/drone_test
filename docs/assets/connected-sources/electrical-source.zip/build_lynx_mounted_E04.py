"""Original source-dimensional Lynx1000 NG interface study. No supplier CAD imported.
Private STEP supplied only independently recorded numeric source interface facts.
"""
from pathlib import Path
import cadquery as cq, math,json,struct,hashlib
import cad_export as ce
P=Path(__file__).resolve().parent; O=P/'victron_candidate/lynx_E04';O.mkdir(exist_ok=True);ce.P=O
box,cyl,bore=ce.box,ce.cyl,ce.bore
parts=[];mounts=[];terms=[];edges=[]
def add(n,s,mat='housing',note='Original simplified interface geometry, not exact supplier contour.'):
 assert s.isValid(),n;parts.append((n,s,mat,note));return s
def tf(s):return s.rotate((0,0,0),(0,0,1),90).mirror('YZ').translate((445-80.9244668,-81.013659,149.8))
# Proper rigid transform: rawX -> global+Y, rawY -> global-X, keeps handedness.
# Use proper Rz90; put narrow footprint along vehicle X. globalX=445-(rawY-80.9244668).
def tf(s):return s.rotate((0,0,0),(0,0,1),90).translate((525.9244668,-81.013659,149.8))
def tp(p):return [525.9244668-p[1],p[0]-81.013659,p[2]+149.8]
def wa(ro,ri,h,z,x,y):return cq.Workplane('XY').circle(ro).circle(ri).extrude(h).translate((x,y,z)).val()
def nut(r,h,z,af,x,y):return cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).circle(r).extrude(h).translate((x,y,z)).val()
def bolt(r,L,under,af,hh,x,y,up=False):
 return cyl(r,L,(x,y,under if up else under-L)).fuse(cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(hh).translate((x,y,under-hh if up else under)).val())
# Source footprint238? Overall229.027x172.117x100.8. Simplified max housing excluding feet belowZ0.
outer=box(229.027318,172.117049,96,(81.013659,80.9244665,48));inner=box(223.027318,166.117049,93,(81.013659,80.9244665,49.5));case=outer.cut(inner)
for x in [-33.5,195.527318]:
 for y in [39,126]:case=case.cut(box(18,36,51,(x,y,35.5)))
axes=[(22,100,3.25),(172,100,3.25),(37,16,2.6),(157,16,2.6)]
for k,(x,y,r) in enumerate(axes):
 # Original conical foot interpolation between source support and upper clamp planes.
 foot=cq.Solid.makeCone(8.05,11.5,12.8,cq.Vector(x,y,-4.8));foot=bore(foot,x,y,r,-5,14)
 if k>=2:foot=foot.cut(box(5.2,2,14,(x,y+1,1.5))).cut(cyl(2.6,14,(x,y+2,-5)))
 case=case.fuse(foot)
 # Upper counterbore source approximately16.18 diameter; custom22OD washer spans verified source seat.
 case=bore(case,x,y,8.0902,0,8)
 case=bore(case,x,y,12,8,90)
add('LYNX1000_original_max_housing_and_mount_interface',tf(case),note='Original max housing shell, terminal access windows and foot interpolation. Numeric source mount supportZ−4.8/clampZ8; source contour and OEM cover retention not reconstructed. One factory enclosure boundary, physical exterior contour fit remains bounded.')
for k,(x,y,r) in enumerate(axes):
 stem=f'LYNX_mount_{k}'
 for tag,s in [('M5x30',bolt(2.5,30,9.5,8,3.5,x,y)),('original_OD22_upper_washer',wa(11,2.75,1.5,8,x,y)),('lower_washer',wa(5,2.7,1,-10.8,x,y)),('M5nut',nut(2.5,4,-14.8,8,x,y))]:add(stem+'_'+tag,tf(s),'steel')
 mounts.append({'id':stem,'axis_C_mm':tp([x,y,-4.8]),'axis_C':[0,0,1],'source_mount_XYZ_verified':True,'source_foot_contact_z_mm':145,'source_upper_seat_z_mm':157.8,'upper_washer_OD_ID_t_mm':[22,5.5,1.5],'washer_is_original_not_supplier_approved':True,'bolt':'M5x30 coarse0.8','underhead_C_z_mm':159.3,'nut_C_z_mm':[135,139],'tip_C_z_mm':129.3,'thread_engagement_mm':4,'protrusion_mm':5.7,'thread_representation':'nominal cylindrical equivalent; no helix','grade_preload_locking_strength_qualified':False})
for fun,x,y,bottom,top,out in [('BAT+',-23,126,24,32,-1),('BAT-',-23,39,24,32,-1),('SYS+',173.5,126,16,24,1),('SYS-',173.5,39,16,24,1)]:
 stem='LYNX_'+fun.replace('+','positive').replace('-','negative')
 blade=box(38.5 if out<0 else 23.5,30,8,(-14.25 if out<0 else 173.75,y,(bottom+top)/2));blade=bore(blade,x,y,5.5,bottom-1,10);add(stem+'_source_blade',tf(blade),'copper','Source 8mm tinned Cu, M10 holeØ11; exact inside bus/contactor/shunt not geometrically reconstructed.')
 # 7SG10 dimensions differ from 7SG8. Original thickness4 and shoulder are explicit.
 lug=box(23,19,4,(0,0,2));lug=bore(lug,0,0,5.25,-1,6)
 tube=cq.Workplane('YZ').circle(8.25).circle(6).extrude(21).translate((11.5,0,8.25)).val();lug=lug.fuse(box(5,12,4,(12,0,2))).fuse(tube)
 if out<0:lug=lug.rotate((0,0,0),(0,0,1),180)
 lug=lug.translate((x,y,top));add(stem+'_Klauke7SG10_lug',tf(lug),'copper','Klauke7SG10 70mm²,M10:44long,19palm,21barrel,OD16.5/ID12;4mm palm and bridge original assumption. Crimp/fine-strand tool qualification open.')
 for tag,s in [('M10x30',bolt(5,30,bottom,17,6.4,x,y,True)),('flat_washer',wa(10,5.25,2,top+4,x,y)),('spring_washer_envelope',wa(9.1,5.1,2.2,top+6,x,y)),('M10nut',nut(5,8,top+8.2,17,x,y))]:add(stem+'_'+tag,tf(s),'steel','Project retained M10x1.5 equivalent stack; OEM33Nm torque requires exact stack/material confirmation, no spring performance implied.')
 terms.append({'id':'LYNX:'+fun,'domain':'DC_power','source_hole_axis_C_mm':tp([x,y,top]),'source_contact_plane_C_z_mm':top+149.8,'source_XYZ_verified':True,'source_basis':'Official M10 drawing plus privately inspected numeric hole/annulus datums; no supplier geometry exported.','lug':'Klauke7SG10','lug_mouth_C_mm':tp([x+out*32.5,y,top+8.25]),'outward_axis_C':[0,out,0],'actual_source_terminal_attachment_geometrically_checked':False,'nominal_conductor_mm2':70,'cable_OD_mm':14.2,'minimum_fixed_bend_radius_mm':85.2,'electrical_crimp_ampacity_protection_qualified':False,'bolt':'M10x30','nut_engagement_mm':8,'thread_protrusion_mm':5.8})
# Existing retained original PDU plate, now four new BMS bores. Old internal bores remain historical vacant holes.
G=P/'carrier_freeze_E02/original_electrical_carriers_E02.glb';b=G.read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);names=[n['name']for n in j['nodes']]
base=box(180,450,5,(445,0,142.5))
for xs,ys,r in [([370,520],[-205,205],3.3),([410,480],[-165,165],2.7),([376.5,513.5],[-190,190],2.2)]:
 for x in xs:
  for y in ys:base=bore(base,x,y,r,138,10)
manifest=json.loads((P/'carrier_freeze_E02/geometry_manifest.json').read_text());v=next(r['volume_mm3']for r in manifest['parts']if r['name']=='PDU_original_baseplate');assert abs(base.Volume()-v)<1e-5
for x,y,r in axes:q=tp([x,y,0]);base=bore(base,q[0],q[1],2.75,139,7)
add('PDU_original_baseplate',base,'steel','Existing E02 base retains all original bores, with four addedØ5.5 M5 BMS bores. External4M6 deck supports unchanged.')
remove=[n for n in names if n.startswith('PDU_')and n!='PDU_original_baseplate'and not n.startswith('PDU_original_support_')]
meta=ce.export('lynx1000_mounted_E04',parts,{'source':'Victron LYN034170310 official dimensional drawing/manual + original support/lug interface geometry','source_CAD_read':True,'vehicle_placed':True})
contract={'revision':'E04','device':'LYN034170310','candidate_not_commissioned':True,'source_urls':['https://www.victronenergy.com/upload/documents/Lynx-Smart-BMS-1000-NG-(M10).pdf','https://www.victronenergy.com/media/pg/Lynx_Smart_BMS_NG/en/installation.html','https://www.klauke.com/kr/en/tubular-cable-lugs-for-switchgear-connection-standard-type-4941'],'transform_C_from_source':{'rotation_Z_deg':90,'translation_mm':[525.9244668,-81.013659,149.8],'proper_rotation':True},'mounts':mounts,'power_terminals':terms,'internal_functional_nodes':[{'id':'LYNX:positive_path','from':'LYNX:BAT+','to':'LYNX:SYS+','function':'source internal contactor and precharge','geometry_inside_not_reconstructed':True},{'id':'LYNX:negative_path','from':'LYNX:BAT-','to':'LYNX:SYS-','function':'source internal shunt','geometry_inside_not_reconstructed':True}],'factory_cover_retention_detail_verified':False,'patch':{'replace':['PDU_original_baseplate'],'remove':remove,'add':[n for n,_,_,_ in parts if n!='PDU_original_baseplate'],'original_deck_holes_and_M6_supports_unchanged':True},'parts':[{'name':n,'solids':len(s.Solids()),'bounds_mm':[s.BoundingBox().xmin,s.BoundingBox().ymin,s.BoundingBox().zmin,s.BoundingBox().xmax,s.BoundingBox().ymax,s.BoundingBox().zmax]}for n,s,_,_ in parts],'geometry':meta,'open_gates':['Source private STEP consists of shells, so numeric datum verification does not certify factory internal solids or manufacturing geometry.','Original OD22 washers bear on source planes but manufacturer approval/material/strength unqualified.','Factory cover screw/clip detail not reconstructed.','Branch fuses, contactors, merge/distribution bars and end-to-end cable routing remain separate requirements.','Total180A warm-bank development limit is not enforced; temperature-aware power sharing and ATC regen inhibition unresolved.','No precharge energy/timeout/current proof for all loads.'],'freeze':False}
(O/'lynx_mounted_contract.json').write_text(json.dumps(contract,indent=2)+'\n');print(json.dumps({'parts':len(parts),'terminals':len(terms),'mounts':len(mounts)}))
