"""Visible original UR OEMDC source-dimension cases with explicit missing mounting interface."""
from pathlib import Path
import json
import cad_export as ce
P=Path(__file__).resolve().parent;O=P/'victron_candidate/controllers_E04';ce.P=O
parts=[];facts=[]
for i,x in enumerate([-1710,-1370],1):
 n=f'UR{i}_OEMDC_source_dimension_case_UNRETAINED';s=ce.box(168,451,150,(x,0,218));parts.append((n,s,'housing','Manufacturer451×150×168max dimensions oriented widthY; no source mounting holes,connector coordinates or physical retention known. This case is visibly UNRETAINED on its tray.'))
 facts.append({'id':f'UR{i}','source_node':n,'center_C_mm':[x,0,218],'source_WHD_mm':[451,150,168],'mass_kg_source':4.3,'mount_geometry_known':False,'terminal_XYZ_known':False,'tray_retains_controller':False,'required_support_interface_complete':False})
meta=ce.export('UR_OEMDC_cases_UNRETAINED_E04',parts,{'source':'Universal Robots OEMDC official specifications; original maximum dimensional reservations','vehicle_placed':True})
(O/'UR_case_reservation_contract_E04.json').write_text(json.dumps({'revision':'E04','geometry':meta,'devices':facts,'source':'https://www.universal-robots.com/manuals/EN/HTML/SW5_25/Content/prod_oem_cb_all/oem_cb_all_specs_root.htm','source_supplier_CAD_used':False,'electrical_and_mounting_acceptance':False},indent=2)+'\n')
