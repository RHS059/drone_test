"""Original breakout lid retained at four M2 equivalent threaded bosses.
Keeps E02 outside envelope, M4 axes and provisional front feedthrough bores.
"""
from pathlib import Path
import cadquery as cq,json,math,hashlib
import cad_export as ce
P=Path(__file__).resolve().parent;O=P/'victron_candidate/breakout_E04';O.mkdir(exist_ok=True);ce.P=O
box,cyl=ce.box,ce.cyl
parts=[];stacks=[]
def add(n,s,mat,note):assert s.isValid(),n;parts.append((n,s,mat,note))
def ax(s):return s.rotate((0,0,0),(1,0,0),-90)
case=box(30,30,56,(175,750,-250)).cut(box(26,30,52,(175,748,-250)))
for z in [-270,-230]:case=case.cut(cq.Workplane('XZ').center(175,z).circle(2.2).extrude(-10).translate((0,760,0)).val())
lid=box(30,2,56,(175,734,-250))
for z in [-265,-250,-235]:lid=lid.cut(cq.Workplane('XZ').center(175,z).circle(4.2).extrude(-8).translate((0,730,0)).val())
for i,(x,z)in enumerate([(x,z)for x in [163,187]for z in [-275,-225]]):
 boss=box(4,9,4,(x,739.5,z));case=case.fuse(boss);case=case.cut(ax(cyl(1,9,(0,0,735))).translate((x,0,z)))
 lid=lid.cut(ax(cyl(1.1,4,(0,0,732))).translate((x,0,z)))
 bolt=ax(cyl(1,10,(0,0,732.5)).fuse(cyl(1.9,2,(0,0,730.5)))).translate((x,0,z));wa=ax(cq.Workplane('XY').circle(2.5).circle(1.1).extrude(.5).translate((0,0,732.5)).val()).translate((x,0,z))
 add(f'breakout_lid_M2x10_{i}',bolt,'steel','Original smooth M2×0.4 equivalent screw. Drive/head contour not an exact purchased SKU. Material, thread class, engagement strength and vibration retention unqualified.');add(f'breakout_lid_M2_washer_{i}',wa,'steel','Original nominal OD5 ID2.2 t0.5 washer.')
 stacks.append({'id':f'breakout_lid_M2_{i}','axis_left_C_mm':[x,735,z],'direction_left_C':[0,1,0],'bolt':'M2x10 nominal coarse0.4','underhead_Y_mm':732.5,'washer_Y_mm':[732.5,733],'lid_Y_mm':[733,735],'original_boss_thread_Y_mm':[735,744],'engaged_interval_Y_mm':[735,742.5],'engagement_mm':7.5,'nominal_thread_contact':True,'strength_locking_environment_qualified':False})
add('original_upright_breakout_case_left_E04',case,'housing','Original revised E02 case with four integral4×4×9mm lid bosses; no vendor geometry. Actual motor pigtail/terminal/feedthrough qualification remains open.')
add('original_upright_breakout_terminal_plate_left_E04',lid,'cover','Original removable2mm lid with four retainedM2 holes; three8.4mm interface bores remain open, not fictitious installed connectors.')
meta=ce.export('upright_breakout_retained_left_E04',parts,{'source':'Original project enclosure and nominal fastener interface dimensions','vehicle_placed':False})
# Analytical and actual solid contacts, no 0.2mm false nut gap.
D={n:s for n,s,_,_ in parts};checks=[]
for i,st in enumerate(stacks):
 b=D[f'breakout_lid_M2x10_{i}'];w=D[f'breakout_lid_M2_washer_{i}'];checks.append({'id':st['id'],'bolt_case_distance_mm':b.distance(case),'bolt_case_positive_overlap_mm3':b.intersect(case).Volume(),'bolt_washer_distance_mm':b.distance(w),'washer_lid_distance_mm':w.distance(lid),'lid_case_distance_mm':lid.distance(case),'bolt_thread_equivalent_shared_area_mm2':b.intersect(case).Area(),'pass':b.distance(case)<1e-6 and b.intersect(case).Volume()<1e-5 and b.distance(w)<1e-6 and w.distance(lid)<1e-6})
conflicts=[]
for i,(n,s,_,_)in enumerate(parts):
 for m,t,_,_ in parts[i+1:]:
  v=s.intersect(t).Volume()
  if v>1e-5:conflicts.append({'a':n,'b':m,'volume_mm3':v})
c={'revision':'E04','geometry':meta,'replaces_E02_names':['original_upright_breakout_case_left_E01','original_upright_breakout_terminal_plate_left_E01'],'preserves_E02_M4_stacks':True,'station_transform':'Left-local Vehicle C mm; right proper Rz180, then stationX translation and actual upright steering/suspension transform.','case_bounds_mm':[160,735,-278,190,765,-222],'lid_retention':stacks,'checks':checks,'positive_volume_conflicts':conflicts,'pass':all(r['pass']for r in checks)and not conflicts,'OEM_phase_encoder_brake_connectors_resolved':False,'environmental_IP_rating_claimed':False,'strength_qualified':False,'parts':[{'name':n,'solids':len(s.Solids())}for n,s,_,_ in parts]}
(O/'breakout_retained_contract_E04.json').write_text(json.dumps(c,indent=2)+'\n');print(json.dumps({'parts':len(parts),'pass':c['pass'],'conflicts':conflicts}))
