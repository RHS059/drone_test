"""Static nominal test of original switchgear against actual holed body and frame.
Additional deck bores are simulated in memory only; integration owner must issue a body revision.
"""
from pathlib import Path
import cadquery as cq,json,hashlib
P=Path(__file__).resolve().parent;O=P/'victron_candidate/switchgear_E04'
B=P.parent/'body-power/R02/body_power_R02.step';F=P.parent.parent/'ugv-reconstruction/mechanical/frame_R07.step';E=O/'installed_isolators_E04.step'
def bb(s):
 b=s.BoundingBox();return[b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def load(p):return list(cq.importers.importStep(str(p)).solids().vals())
b=load(B);f=load(F);e=load(E);c=json.loads((O/'isolator_placement_contract.json').read_text());cuts=[]
for h in c['body_deck_patch']:
 x,y,z=h['center_C_mm'];cut=cq.Workplane('XY').center(x,y).circle(h['diameter_mm']/2).extrude(5).translate((0,0,99)).val();before=b[0].Volume();b[0]=b[0].cut(cut);removed=before-b[0].Volume();cuts.append({'id':h['id'],'removed_mm3':removed,'expected_mm3':3.141592653589793*3.3**2*3,'full_material':abs(removed-3.141592653589793*3.3**2*3)<1e-3})
bodyparts=json.loads((P.parent/'body-power/verification.json').read_text()).get('parts',[])
pool=[('body',i,s,bodyparts[i]['name'] if i<len(bodyparts) else str(i))for i,s in enumerate(b)]+[('frame',i,s,str(i))for i,s in enumerate(f)]
# Actual source-dimensional UR envelopes are not exact supplier CAD/mount datums.
for i,x in enumerate([-1710,-1370]):pool.append(('UR_dimensional_envelope',i,cq.Workplane('XY').box(168,451,150).translate((x,0,218)).val(),f'UR{i+1}'))
pbounds=[bb(t)for _,_,t,_ in pool];hits=[];contacts=[]
for i,s in enumerate(e):
 a=bb(s)
 for (kind,j,t,name),q in zip(pool,pbounds):
  if any(a[k]>q[k+3]+1e-6 or q[k]>a[k+3]+1e-6 for k in range(3)):continue
  v=s.intersect(t).Volume()
  if v>1e-4:hits.append({'electrical_solid':i,'kind':kind,'other':j,'name':name,'volume_mm3':v,'electrical_bounds':a})
  elif s.distance(t)<1e-4:contacts.append({'electrical_solid':i,'kind':kind,'other':j,'name':name})
out={'revision':'E04','actual_body_source':str(B),'hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [B,F,E]},'deck_patch_simulated_not_applied':True,'deck_bores':cuts,'positive_volume_hits':hits,'contacts':contacts,'static_body_frame_UR_envelope_pass':not hits and all(x['full_material']for x in cuts),'all_source_device_interfaces_qualified':False,'cable_routes_or_shock_clearance_included':False}
(O/'body_frame_UR_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'hits':hits,'deck_full_material':all(x['full_material']for x in cuts)}),flush=True)
