from pathlib import Path
import json,cadquery as cq
P=Path(__file__).resolve().parent;O=P/'victron_candidate/switchgear_E04';C=json.loads((O/'isolator_placement_contract.json').read_text());ss=list(cq.importers.importStep(str(O/'installed_isolators_E04.step')).val());import struct
b=(O/'installed_isolators_E04.glb').read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);assert len(ss)==len(j['nodes']);D=dict(zip([n['name']for n in j['nodes']],ss));rows=[]
for p in C['power_terminals']:
 ref,fun=p['id'].split(':');stem=ref+'_terminal_'+fun;lug=D[stem+('_7SG8_lug'if ref=='Q0'else'_105R8_lug')];blade=D[stem+'_blade'];bolt=D[stem+'_M8x20'];nut=D[stem+'_M8nut'];upper=D[stem+'_upper_washer'];lower=D[stem+'_lower_washer'];dist={'lug_blade':lug.distance(blade),'upper_lug':upper.distance(lug),'bolt_upper':bolt.distance(upper),'lower_blade':lower.distance(blade),'nut_lower':nut.distance(lower),'bolt_nut':bolt.distance(nut)};rows.append({'id':p['id'],'distances_mm':dist,'lug_blade_area_mm2':lug.intersect(blade).Area(),'bolt_nut_equivalent_contact_area_mm2':bolt.intersect(nut).Area(),'pass':max(dist.values())<1e-5})
out={'revision':'E04','terminal_stacks':rows,'pass':all(r['pass']for r in rows),'source_blade_XYZ_verified':True,'polarity_circuit_assignment_crimp_fuse_or_protection_qualified':False}
(O/'terminal_contact_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'pass':out['pass']}))
