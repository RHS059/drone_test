from pathlib import Path
import cadquery as cq,json,struct,hashlib
P=Path(__file__).resolve().parent;O=P/'victron_candidate/controllers_E04'
def load(stem):
 b=(P/(stem+'.glb')).read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);s=list(cq.importers.importStep(str(P/(stem+'.step'))).val());assert len(s)==len(j['nodes']);return dict(zip([n['name']for n in j['nodes']],s))
a=load('victron_candidate/controllers_E04/controller_housing_interfaces_E04');old=load('carrier_freeze_E02/original_electrical_carriers_E02');checks=[];overlaps=[]
def bb(s):b=s.BoundingBox();return[b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
for n,s in a.items():
 aa=bb(s)
 for m,t in old.items():
  b=bb(t)
  if any(aa[k]>b[k+3]+1e-5 or b[k]>aa[k+3]+1e-5 for k in range(3)):continue
  v=s.intersect(t).Volume()
  if v>1e-4:overlaps.append({'a':n,'b':m,'volume_mm3':v})
for i in range(1,7):
 ref=f'INV{i}';base=a[ref+'_source_dimensional_base'];carrier=old[ref+'_original_drilled_carrier'];mount=[]
 for k in range(1,5):
  w=old[f'{ref}_mount{k}_upper_washer'];mount.append({'id':f'{ref}_mount{k}','washer_base_distance_mm':w.distance(base),'washer_base_contact_area_mm2':w.intersect(base).Area()})
 term=[]
 for label in ['M1','M2','M3','Bminus','DCplus']:
  s=a[ref+'_'+label+'_M6_source_XY_terminal_interface'];lug=old[ref+'_'+label+'_105R6_dimensioned_lug'];bolt=old[ref+'_'+label+'_M6_retaining_bolt'];term.append({'id':ref+':'+label,'lug_terminal_distance_mm':lug.distance(s),'lug_terminal_contact_area_mm2':lug.intersect(s).Area(),'bolt_equivalent_thread_distance_mm':bolt.distance(s),'bolt_thread_contact_area_mm2':bolt.intersect(s).Area(),'OEM_terminal_Z_verified':False})
 checks.append({'id':ref,'carrier_base_distance_mm':base.distance(carrier),'carrier_base_contact_area_mm2':base.intersect(carrier).Area(),'mounts':mount,'terminals':term})
B=P.parent/'body-power/shock-opening-study/body_power_shock_clearance_SO01.step';body=list(cq.importers.importStep(str(B)).val());bodyhits=[]
for n,s in a.items():
 aa=bb(s)
 for i,t in enumerate(body):
  b=bb(t)
  if any(aa[k]>b[k+3]+1e-5 or b[k]>aa[k+3]+1e-5 for k in range(3)):continue
  v=s.intersect(t).Volume()
  if v>1e-4:bodyhits.append({'part':n,'body_child':i,'volume_mm3':v})
pas=not overlaps and not bodyhits and all(c['carrier_base_distance_mm']<1e-5 and all(x['washer_base_distance_mm']<1e-5 for x in c['mounts'])and all(x['lug_terminal_distance_mm']<1e-5 and x['bolt_equivalent_thread_distance_mm']<1e-5 for x in c['terminals'])for c in checks)
out={'scope':'Actual original housing/base/boss export against all668 retained E02 parts and actual SO01 body. Nominal contacts at proposed terminalZ do not establish source attachment.','checks':checks,'E02_overlaps':overlaps,'body_overlaps':bodyhits,'geometric_nominal_fit_pass':pas,'source_terminal_header_Z_verified':False,'source_compatibility_or_commissioning_qualified':False}
(O/'controller_housing_check_E04.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'pass':pas,'E02_overlaps':overlaps,'body_overlaps':bodyhits}))
