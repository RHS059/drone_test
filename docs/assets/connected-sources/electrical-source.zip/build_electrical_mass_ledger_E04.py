"""Volume-derived original-hardware estimates only; factory envelope mass excluded."""
from pathlib import Path
import json,struct,cadquery as cq
P=Path(__file__).resolve().parent;O=P/'freeze_E04';rows=[]
L=json.loads((P/'victron_candidate/lynx_E04/lynx_mounted_contract.json').read_text());removed=set(L['patch']['remove']+L['patch']['replace'])
def group(stem,kind,count=1):
 b=(P/(stem+'.glb')).read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);ss=list(cq.importers.importStep(str(P/(stem+'.step'))).val());assert len(ss)==len(j['nodes'])
 for n,s in zip(j['nodes'],ss):
  name=n['name'];material=None;rho=None;scope='unassigned supplier/interface envelope';sel=True
  if kind=='E02':
   if name in removed:sel=False
   if any(w in name for w in ['carrier','fin_','support_','cable_clamp_rail']):material='original aluminium';rho=2700
   if any(w in name for w in ['M4','M5','M6','M8','washer','nut','bolt']):material='nominal steel hardware';rho=7850
   if '105R6'in name:material='dimensioned copper lug, approximate volume';rho=8960
   if 'contact_cavity'in name:material='approximate copper contact';rho=8960
  elif kind=='E02body':material='nominal steel hardware';rho=7850
  elif kind=='trough':
   if name.startswith('cable_duct'):material='original aluminium, matching body same-alloy proposal';rho=2700
  elif kind=='switchgear':
   if '_tray'in name or '_deck_'in name or '_mount'in name and '_mount_foot'not in name:material='original steel support/nominal hardware';rho=7850
   if 'lug'in name:material='dimensioned copper lug, approximate volume';rho=8960
   if any(w in name for w in ['_M8x','_M8nut','_washer']):material='nominal steel hardware';rho=7850
  elif kind=='lynx':
   if name=='PDU_original_baseplate':material='original aluminium';rho=2700
   elif name.startswith('LYNX_mount_') or any(w in name for w in ['_M10x','_M10nut','_washer']):material='nominal steel hardware';rho=7850
   elif 'lug'in name:material='dimensioned copper lug, approximate volume';rho=8960
  elif kind=='breakout':
   if 'M2'in name:material='nominal steel hardware';rho=7850
  if rho is not None:scope='original/interface geometry estimate, material/grade qualification pending'
  v=s.Volume();rows.append({'asset':stem,'name':name,'instance_quantity':count,'selected_after_overlay':sel,'volume_mm3_each':v,'density_kg_m3_assumed':rho,'material_basis':material,'estimated_mass_kg_each':v*rho/1e9 if rho is not None else None,'mass_scope':scope,'supplier_component_mass_included':False})
group('carrier_freeze_E02/original_electrical_carriers_E02','E02');group('carrier_freeze_E02/body_mount_fasteners_E02','E02body');group('carrier_freeze_E02/breakout_enclosure_fasteners_left_E02','E02body',6)
group('victron_candidate/switchgear_E04/aligned_trough_and_glands_E04','trough');group('victron_candidate/switchgear_E04/installed_isolators_E04','switchgear');group('victron_candidate/lynx_E04/lynx1000_mounted_E04','lynx');group('victron_candidate/breakout_E04/upright_breakout_retained_left_E04','breakout',6)
t=[r for r in rows if r['name'].startswith('cable_duct')]
out={'revision':'E04','mass_model':'Original solid volumes times explicitly assumed density. No entire supplier maximum housing treated as solid mass. Do not add subpart supplier-interface estimates to a verified complete factory mass without excluding overlaps.','parts':rows,'selected_original_estimated_subtotal_kg':sum(r['estimated_mass_kg_each']*r['instance_quantity']for r in rows if r['selected_after_overlay']and r['estimated_mass_kg_each']is not None),'trough15_original_aluminium_mass_kg':sum(r['estimated_mass_kg_each']for r in t),'trough15_original_count':len(t),'factory_masses':[{'part':'LYN034170310','mass_kg':2.7,'quantity':1,'source':'https://www.victronenergy.com/media/pg/Lynx_Smart_BMS_NG/en/technical-specifications.html','includes_factory_housing_internal_busbars_contactors_shunt':True,'price_list_mass_conflict_kg':2.5},{'part':'BAT548110620','mass_kg':37,'quantity':2,'source':'https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/technical-data.html','battery_owner_handles_mount_mass':True}],'whole_electrical_mass_known':False,'unknowns':['Exact configured inverter case mass','ABB whole device/installed shrouds','Fuseholder/branch contactors/converters/controls','Breakout polymer bodies density and source connectors','Complete routed harness length and mass'],'replacement_map':{'E02_removed':L['patch']['remove'],'E02_replaced':L['patch']['replace'],'trough':json.loads((P/'victron_candidate/switchgear_E04/rear_trough_patch_contract.json').read_text())['changes']}}
(O/'original_mass_ledger_E04.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'trough_parts':len(t),'trough_mass_kg':out['trough15_original_aluminium_mass_kg'],'whole_known':False}))
