from pathlib import Path
import cadquery as cq,json,hashlib
P=Path(__file__).resolve().parent;O=P/'victron_candidate/lynx_E04';c=json.loads((O/'lynx_mounted_contract.json').read_text());ss=cq.importers.importStep(str(O/'lynx1000_mounted_E04.step')).val().Solids();N=sum(r['solids']for r in c['parts']);assert len(ss)==N
new={};ii=0
for r in c['parts']:new[r['name']]=cq.Compound.makeCompound(ss[ii:ii+r['solids']]);ii+=r['solids']
def bb(s):
 b=s.BoundingBox();return[b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def ov(a,b):
 aa=bb(a);bo=bb(b)
 return all(aa[k]<bo[k+3]+1e-5 and bo[k]<aa[k+3]+1e-5 for k in range(3))
conf=[];contacts=[]
for i,(n,s)in enumerate(new.items()):
 for m,t in list(new.items())[i+1:]:
  if not ov(s,t):continue
  v=s.intersect(t).Volume();d=s.distance(t)
  if v>1e-4:conf.append({'a':n,'b':m,'volume_mm3':v})
  elif d<1e-5:contacts.append({'a':n,'b':m,'contact_area_mm2':s.intersect(t).Area()})
B=P.parent/'body-power/shock-opening-study';bodyfile=B/'body_power_shock_clearance_SO01.step';body=cq.importers.importStep(str(bodyfile)).val().Solids();bad=[]
for n,s in new.items():
 for i,t in enumerate(body):
  if ov(s,t):
   v=s.intersect(t).Volume()
   if v>1e-4:bad.append({'part':n,'body_solid':i,'volume_mm3':v})
mountchecks=[]
for m in c['mounts']:
 stem=m['id'];base=new['PDU_original_baseplate'];case=new['LYNX1000_original_max_housing_and_mount_interface'];bolt=new[stem+'_M5x30'];nut=new[stem+'_M5nut'];upper=new[stem+'_original_OD22_upper_washer'];lower=new[stem+'_lower_washer'];mountchecks.append({'id':stem,'bolt_nut_distance_mm':bolt.distance(nut),'bolt_nut_shared_area_mm2':bolt.intersect(nut).Area(),'washer_case_distance_mm':upper.distance(case),'washer_case_shared_area_mm2':upper.intersect(case).Area(),'lower_washer_base_distance_mm':lower.distance(base),'nut_washer_distance_mm':nut.distance(lower),'foot_base_distance_mm':case.distance(base),'pass':max(bolt.distance(nut),upper.distance(case),lower.distance(base),nut.distance(lower),case.distance(base))<1e-5})
tc=[]
for p in c['power_terminals']:
 stem=p['id'].replace(':','_').replace('+','positive').replace('-','negative');blade=new[stem+'_source_blade'];lug=new[stem+'_Klauke7SG10_lug'];bolt=new[stem+'_M10x30'];nut=new[stem+'_M10nut'];wa=new[stem+'_flat_washer'];sw=new[stem+'_spring_washer_envelope'];tc.append({'id':p['id'],'lug_blade_distance_mm':lug.distance(blade),'lug_blade_shared_area_mm2':lug.intersect(blade).Area(),'bolt_nut_distance_mm':bolt.distance(nut),'bolt_nut_shared_area_mm2':bolt.intersect(nut).Area(),'bolt_head_blade_distance_mm':bolt.distance(blade),'lug_washer_distance_mm':lug.distance(wa),'washer_spring_distance_mm':wa.distance(sw),'spring_nut_distance_mm':sw.distance(nut),'pass':max(lug.distance(blade),bolt.distance(nut),bolt.distance(blade),lug.distance(wa),wa.distance(sw),sw.distance(nut))<1e-5})
out={'scope':'Actual exported original Lynx42-part interface against actual SO01 body; PDU external4deck supports unchanged. Source shell-only CAD provides datum facts, not physical factory contour validation.','hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [O/'lynx1000_mounted_E04.step',bodyfile]},'self_conflicts':conf,'body_conflicts':bad,'contacts':contacts,'mount_checks':mountchecks,'terminal_checks':tc,'pass':not(conf or bad)and all(r['pass']for r in mountchecks+tc),'source_factory_cover_internal_clearance_electrical_safety_qualified':False}
(O/'lynx_geometry_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['pass','self_conflicts','body_conflicts']}))
