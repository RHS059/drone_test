"""Public whitelist and bounded installed-component contract for E04.
No recursive publication. No source PDFs, source STEP or motor derivative assets.
"""
from pathlib import Path
import json,hashlib,struct
P=Path(__file__).resolve().parent;O=P/'freeze_E04';O.mkdir(exist_ok=True)
def read(p):return json.loads((P/p).read_text())
def sha(p):return hashlib.sha256((P/p).read_bytes()).hexdigest()
def glbnames(p):
 b=(P/p).read_bytes();j=json.loads(b[20:20+struct.unpack_from('<I',b,12)[0]]);return [n['name']for n in j['nodes']]
root='victron_candidate/';sw=root+'switchgear_E04/';ly=root+'lynx_E04/';bo=root+'breakout_E04/'
abb=read(sw+'isolator_placement_contract.json');lynx=read(ly+'lynx_mounted_contract.json');trough=read(sw+'rear_trough_patch_contract.json');br=read(bo+'breakout_retained_contract_E04.json')
geom=[{'module':'switchgear_E04','glb':sw+'installed_isolators_E04.glb','step':sw+'installed_isolators_E04.step','frame':'Vehicle C metres GLB/mm STEP','parts':204,'action':'add'}, {'module':'trough_E04','glb':sw+'aligned_trough_and_glands_E04.glb','step':sw+'aligned_trough_and_glands_E04.step','frame':'Vehicle C','parts':19,'action':'named_delta','changes':trough['changes']}, {'module':'lynx_E04','glb':ly+'lynx1000_mounted_E04.glb','step':ly+'lynx1000_mounted_E04.step','frame':'Vehicle C','parts':42,'action':'named_delta','changes':[{'action':'replace','name':n}for n in lynx['patch']['replace']]+[{'action':'remove','name':n}for n in lynx['patch']['remove']]+[{'action':'add','name':n}for n in lynx['patch']['add']]}, {'module':'breakout_E04','glb':bo+'upright_breakout_retained_left_E04.glb','step':bo+'upright_breakout_retained_left_E04.step','frame':'station-local left C; properRz180 on right, then station translation and upright suspension/yaw','parts':10,'instances':6,'action':'replace_per_corner_E02_case_and_lid','remove_per_corner':br['replaces_E02_names'],'preserve_per_corner':'E02 two retained M4 stacks, source bracket/standoffs/carrier fasteners'}, {'module':'local_lead_study_E04','glb':sw+'isolator_service_lead_study_E04.glb','step':sw+'isolator_service_lead_study_E04.step','frame':'Vehicle C','parts':12,'action':'optional_development_overlay','full_routes':False,'endpoints_include_unterminated_continuations':True}]
geom.append({'module':'controllers_E04','glb':root+'controllers_E04/controller_housing_interfaces_E04.glb','step':root+'controllers_E04/controller_housing_interfaces_E04.step','frame':'Vehicle C','parts':78,'action':'add','source_terminal_Z_and_header_frame_verified':False})
geom.append({'module':'UR_unretained_E04','glb':root+'controllers_E04/UR_OEMDC_cases_UNRETAINED_E04.glb','step':root+'controllers_E04/UR_OEMDC_cases_UNRETAINED_E04.step','frame':'Vehicle C','parts':2,'action':'add_unretained_reservation','required_support_complete':False})
for g in geom:
 g['sha256']={k:sha(g[k])for k in ['glb','step']};g['source_nodes']=glbnames(g['glb']);assert len(g['source_nodes'])==g['parts']
ports=abb['power_terminals']+lynx['power_terminals']
# Domain-specific boundaries preserve phase / feedback / brake separation. No motor DC return is invented.
unknown=[]
for i in range(1,7):
 for domain,names in [('three_phase_motor',['U','V','W']),('encoder_sincos',['SIN','COS','SUPPLY','RETURN']),('motor_temperature',['KTY1','KTY2']),('parking_brake_coil',['BRK+','BRK-'])]:
  for n in names:unknown.append({'id':f'M{i}:{n}','domain':domain,'source_identity_known':True,'configured_signal_supply_or_polarity_verified':False,'coordinate_C_mm':None,'source_XYZ_verified':False,'physical_continuity_verified':False,'required':True,'reason':'Exact OEM pigtail/connector part and labelled exit/terminal XYZ absent; do not infer functional identity from generic motor STEP solids.'})
connections=[];nodes={}
def node(id,**kw):nodes[id]={'id':id,**kw};return id
def edge(kind,a,b,ret=[],evidence=[],open_gates=[],**kw):connections.append({'id':f'E04_{len(connections):04}','kind':kind,'from_nodes':a,'to_nodes':b,'retaining_nodes':ret,'evidence':evidence,'open_gates':open_gates,**kw})
# All per-corner rendered electrical and mechanical breakout groups are active graph nodes.
for end,fore in [('rear',-1),('middle',0),('front',1)]:
 for side,sgn in [('left',1),('right',-1)]:
  label=end+'_'+side;upr=node('structure/'+label+'_upright',external=True)
  keys={}
  for source in ['breakout_bracket_left_C04_R01','breakout_standoff_0_C04_R01','breakout_standoff_1_C04_R01','breakout_carrier_fasteners_C04_R01']:
   keys[source]=node('structure/'+label+'_'+source,module='structure',instance=label,source_node=label+'_'+source,source_geometry=source,external=True)
  local={n:node('breakout_E04/'+label+'/'+n,module='breakout_E04',instance=label,source_node=n)for n in geom[3]['source_nodes']}
  m4names=glbnames('carrier_freeze_E02/breakout_enclosure_fasteners_left_E02.glb');m4={n:node('breakout_E02/'+label+'/'+n,module='breakout_E02',instance=label,source_node=n)for n in m4names}
  bracket=keys['breakout_bracket_left_C04_R01'];studs=[keys[f'breakout_standoff_{k}_C04_R01']for k in range(2)];carrierhw=keys['breakout_carrier_fasteners_C04_R01'];case=local['original_upright_breakout_case_left_E04'];lid=local['original_upright_breakout_terminal_plate_left_E04']
  edge('two_retained_M5_carrier_bolts',[bracket],[upr],[carrierhw],['external: mechanical/connection_completion_C04/drive/breakout_mount_contract_C04_R01.json','external: mechanical breakout M5 retained stack checks'],['M5 grade/preload/locking/fatigue unqualified'],mount_axes_left_C_mm=[[135,779,-235],[135,779,-265]],geometry_contact_verified=True)
  edge('two_retained_M4_enclosure_stacks',[case],[bracket],studs+list(m4.values()),['carrier_freeze_E02/breakout_retention_check.json','carrier_freeze_E02/breakout_retention_contract.json'],['Thread fit/grade/locking, enclosure and bracket strength unqualified'],geometry_contact_verified=True)
  edge('four_retained_M2_lid_stacks',[lid],[case],[v for k,v in local.items()if k.startswith('breakout_lid_')],[bo+'breakout_retained_contract_E04.json'],['M2 thread/material/strength/vibration locking and enclosure IP unqualified'],geometry_contact_verified=br['pass'])
  for holez in [-265,-250,-235]:
   req=node(f'breakout_requirement/{label}/phase_feedthrough_{holez}',required_interface=True,rendered_hardware=False,domain='three_phase_motor',verified=False)
   edge('unresolved_required_feedthrough',[lid],[req],[],[],['No selected source-rated installed insulated feedthrough or conductor retention.'],geometry_contact_verified=False)
# Device groups: every named rendered part is listed even when no detailed physical retention proof exists.
for g in geom[:3]+geom[4:]:
 for n in g['source_nodes']:node(g['module']+'/'+n,module=g['module'],source_node=n)
for n in geom[4]['source_nodes']:
 edge('open_local_lead_continuation',['local_lead_study_E04/'+n],[],evidence=[sw+'service_lead_check.json'],open_gates=['Local source-lug exit only; opposite endpoint is a free continuation, no complete circuit'],geometry_contact_verified=False)
for i,n in enumerate(geom[6]['source_nodes'],1):
 edge('unretained_OEMDC_case',['UR_unretained_E04/'+n],[node(f'body/controller_mount_tray_{i}',external=True)],evidence=[root+'controllers_E04/UR_case_reservation_contract_E04.json'],open_gates=['Supplier controller mounting/retention and actual connector datums unavailable; tray bearing does not establish retention'],geometry_contact_verified=False)
# Exact positive-volume/contact report edges for Lynx exported hardware.
lcheck=read(ly+'lynx_geometry_check.json')
for r in lcheck['contacts']:edge('verified_nominal_geometric_contact',['lynx_E04/'+r['a']],['lynx_E04/'+r['b']],evidence=[ly+'lynx_geometry_check.json'],open_gates=['Contact alone is not proof of current rating, purchased thread fit, torque or strength'],contact_area_mm2=r['contact_area_mm2'],geometry_contact_verified=True)
# Explicit retained support/device groups prevent group-level contact being mistaken for all-part retention.
for i in range(1,7):
 ref=f'INV{i}';base='controllers_E04/'+ref+'_source_dimensional_base';body='controllers_E04/'+ref+'_original_max_housing_shell';header='controllers_E04/'+ref+'_proposed_AMPSEAL_header_interface'
 carrier=node('electrical_E02/'+ref+'_original_drilled_carrier',external=True)
 hardware=[node('electrical_E02/'+ref+f'_mount{k}_'+suffix,external=True)for k in range(1,5)for suffix in ['M6x30','upper_washer','lower_washer','M6_nut']]
 edge('four_retained_controller_base_stacks',[base],[carrier],hardware,[root+'controllers_E04/controller_housing_check_E04.json'],['Current configured factory variant and legacy12mm base revision, torque/grade/preload unqualified'],geometry_contact_verified=True)
 edge('original_factory_housing_interface',[body,header],[base],evidence=[root+'controllers_E04/controller_housing_contract_E04.json'],open_gates=['Exact factory contour, internal cover retention and signalheader datum unknown'],geometry_contact_verified=False)
 for term in ['M1','M2','M3','DCplus','Bminus']:
  a='controllers_E04/'+ref+'_'+term+'_original_insulated_terminal_support';b='controllers_E04/'+ref+'_'+term+'_M6_source_XY_terminal_interface';lug=node('electrical_E02/'+ref+'_'+term+'_105R6_dimensioned_lug',external=True)
  hw=[node('electrical_E02/'+ref+'_'+term+'_'+k,external=True)for k in ['M6_retaining_bolt','M6_washer']]
  edge('original_terminal_boss_and_retained_lug',[b,lug],[a,base],hw,[root+'controllers_E04/controller_housing_check_E04.json'],['Source terminalXY known; terminalZ65 and conductor boss dimensions original assumptions, actual OEM attachment unverified'],geometry_contact_verified=False)
for d in abb['devices']:
 ref=d['id'];tr=node('switchgear_E04/'+ref+'_tray');foot='switchgear_E04/'+ref+'_mount_foot_interface'
 hardware=[k for k in nodes if k.startswith('switchgear_E04/'+ref+'_mount')and k!=foot]
 edge('four_retained_M5_switch_to_tray',[foot],[tr],hardware,[sw+'isolator_placement_contract.json',sw+'aligned_trough_check.json'],['Original max housing/foot interpolation; fastener grades/preload/strength unknown'],geometry_contact_verified=True)
 deckparts=[k for k in nodes if k.startswith('switchgear_E04/'+ref+'_deck_')];edge('four_retained_M6_tray_to_deck',[tr],[node('body/main_base_deck_3mm',external=True)],deckparts,[sw+'body_frame_UR_check.json','external: body-power/shock-opening-study/combined_deck_manifest_SO01_E04.json'],['Cantilever strength and fastener qualification'],geometry_contact_verified=True)
 for fun in ['P_IN','P_OUT','N_IN','N_OUT']:
  stem='switchgear_E04/'+ref+'_terminal_'+fun;lug=stem+('_7SG8_lug'if ref=='Q0'else'_105R8_lug')
  edge('retained_M8_lug_to_source_blade',[lug],[stem+'_blade'],[stem+'_'+k for k in ['M8x20','upper_washer','lower_washer','M8nut']],[sw+'terminal_contact_check.json'],['Source bladeXYZ verified; original palm thickness, crimp/tool, polarity circuit assignment and protection qualification open'],geometry_contact_verified=True)
 edge('factory_isolator_body_mount_boundary',['switchgear_E04/'+ref+'_max_housing','switchgear_E04/'+ref+'_shaft_mechanism_interface'],[foot],evidence=[sw+'abb_interface_facts.json'],open_gates=['Factory internal fasteners/shaft retention not reconstructed'],geometry_contact_verified=False)
 sh=[k for k in nodes if k.startswith('switchgear_E04/'+ref+'_OTDCS')];edge('source_shroud_shell_mating_boundary',sh,[foot],evidence=[sw+'abb_interface_facts.json'],open_gates=['Actual OTDCS clip/tab retention not reconstructed; source shell contact does not establish finished cover retention'],geometry_contact_verified=False)
for w in trough['welded_connections']:
 a='trough_E04/'+w['a'];b='trough_E04/'+w['b']if w['b']in geom[1]['source_nodes']else node('body/'+w['b'],external=True)
 edge('proposed_same_alloy_weld',[a],[b],evidence=[sw+'aligned_trough_check.json','external: body-power/shock-opening-study/partition_trough_check_SO02_E04P.json'],open_gates=['Weld size, process, distortion, panel fatigue and material selection unqualified'],geometry_contact_verified=True)
for y in [366.5,443.5]:
 stem=f'trough_E04/QB2_partition_gland_{y}';edge('M20_gland_panel_retention',[stem+'_53111020_body'],[node('body/controller_battery_partition',external=True)],[stem+'_53119020_locknut'],[sw+'aligned_trough_check.json','external: body-power/shock-opening-study/partition_trough_check_SO02_E04P.json'],['IP/seal/clamp pullout not tested; exact polymer contour original'],geometry_contact_verified=True)
active={k for k,n in nodes.items()if 'module'in n};covered=set()
for e in connections:covered.update(e['from_nodes']+e['to_nodes']+e['retaining_nodes'])
uncovered=sorted(active-covered)
# Uncovered factory/internal parts are explicit incomplete graph records, not silent drops.
for n in uncovered:edge('unqualified_factory_or_project_interface',[n],[],open_gates=['Exact part-level retained connection not yet verified; required completeness failure'],geometry_contact_verified=False)
report={'revision':'E04','status':'source-backed installed-interface candidate, incomplete electrical system','geometry':geom,'body_patch_package':'body-power/shock-opening-study/body_shock_partition_replacements_SO02_E04P','retained_E02_checkpoint':'carrier_freeze_E02/FREEZE.json','ports':ports,'unresolved_motor_ports':unknown,'nodes':nodes,'connections':connections,'every_rendered_E04_node_accounted':True,'unassigned_node_count':len(uncovered),'unassigned_nodes':uncovered,'geometrically_unverified_connection_count':sum(not e.get('geometry_contact_verified',False)for e in connections),'external_breakout_group_count':24,'unretained_UR_cases':{'glb':'victron_candidate/controllers_E04/UR_OEMDC_cases_UNRETAINED_E04.glb','step':'victron_candidate/controllers_E04/UR_OEMDC_cases_UNRETAINED_E04.step','contract':'victron_candidate/controllers_E04/UR_case_reservation_contract_E04.json','required_support_and_power_interfaces_complete':False},'source_motor_CAD_or_PDF_published':False,'electrical_end_to_end_complete':False,'operational_or_safety_qualified':False,'development_current_cap_A':180,'cap_enforced':False,'full_nameplate_traction_min_bus_A_at44p8V_eta80':13200/44.8/.8,'remaining_required_devices':['2 pack fuses at most100A with verified covered holders','Main bank fuse and coordination','6 source-compatible Gen4 inverter configured variants','6 branch contactors/branch precharge and coordinated protection','2 UR OEMDC softstart/fuse branches','2 steering external power switching branches','48-to24V auxiliary supply, 12V sensor supply','Controllers/sensors/communications retention and full harness','Documented regenerative sink or validated no-regen stop strategy'],'moving_harness':'Separate route requirement/study; OEM endpoints and completed source strain relief not verified'}
(O/'electrical_connection_contract_E04.json').write_text(json.dumps(report,indent=2)+'\n')
# BOM explicitly separates installed-interface studies from unplaced requirements.
bom=[{'ref':d['id'],'part':d['model'],'quantity':1,'status':'mounted source-dimensional candidate','qualification':'180A limited-power architecture; switch/fuse/DC arc coordination open'}for d in abb['devices']]
bom += [{'ref':'Q_shrouds','part':'ABB OTDCS200GG1','quantity':12,'status':'source external shell installed; clip retention incomplete'}, {'ref':'LYNX','part':'LYN034170310','quantity':1,'status':'mounted source-terminal/foot interface candidate'}, {'ref':'BAT1/BAT2','part':'BAT548110620','quantity':2,'status':'battery-owner BA02 candidate, terminal source-revision gate'}, {'ref':'PG1/PG2','part':'LAPP53111020','quantity':2,'status':'mounted gland max-interface model'}, {'ref':'PG_nuts','part':'LAPP53119020','quantity':2,'status':'retained nominal M20x1.5 interface'}, {'ref':'QB_lugs','part':'Klauke105R8','quantity':8,'status':'installed source dimensions; crimp/palm thickness gate'}, {'ref':'Q0_lugs','part':'Klauke7SG8','quantity':4,'status':'installed source dimensions; crimp/palm thickness gate'}, {'ref':'LYNX_lugs','part':'Klauke7SG10','quantity':4,'status':'installed source dimensions; crimp/palm thickness gate'}, {'ref':'breakout_cases','part':'original project30x30x56 retained enclosure','quantity':6,'status':'retained original development geometry; phase ports empty'}, {'ref':'lid_screws','part':'M2x10 coarse0.4 nominal interface','quantity':24,'status':'modelled7.5mm boss engagement, grade/fit/strength unknown'}]
(O/'bom_E04.json').write_text(json.dumps({'revision':'E04','items':bom,'complete_system_BOM':False},indent=2)+'\n')
files=['build_E04_handoff.py','build_domain_topology_E04.py','freeze_E04/electrical_topology_E04.json','build_electrical_mass_ledger_E04.py','freeze_E04/original_mass_ledger_E04.json','build_controller_housings_E04.py','check_controller_housings_E04.py','check_switchgear_contacts_E04.py','source_facts.json','cad_export.py','build_two_pack_switchgear.py','build_rear_trough_revision.py','build_lynx_mounted_E04.py','check_lynx_mounted_E04.py','build_breakout_retained_E04.py','check_two_pack_packaging.py','check_two_pack_switchgear_leads.py','check_aligned_trough.py','cover_research/abb_installed_interface_facts.json','victron_candidate/build_comparison.py','victron_candidate/electrical_comparison.json','victron_candidate/comparison_checks.json','victron_candidate/temperature_limits.py','victron_candidate/temperature_limit_tests.json','freeze_E04/electrical_connection_contract_E04.json','freeze_E04/bom_E04.json']
for g in geom:files += [g['glb'],g['step']]
files += [sw+n for n in ['abb_interface_facts.json','isolator_placement_contract.json','deck_holes_coordinate_freeze.json','body_frame_UR_check.json','service_lead_check.json','rear_trough_patch_contract.json','aligned_trough_check.json']]+[ly+'lynx_mounted_contract.json',ly+'lynx_geometry_check.json',bo+'breakout_retained_contract_E04.json']
files += [root+'controllers_E04/controller_housing_contract_E04.json',root+'controllers_E04/controller_housing_check_E04.json',sw+'terminal_contact_check.json']
files += ['build_ur_case_reservations_E04.py',root+'controllers_E04/UR_OEMDC_cases_UNRETAINED_E04.glb',root+'controllers_E04/UR_OEMDC_cases_UNRETAINED_E04.step',root+'controllers_E04/UR_case_reservation_contract_E04.json']
files += ['freeze_E04/README_E04.md']
files=list(dict.fromkeys(files));manifest={'revision':'E04','allowlist':files,'sha256':{f:sha(f)for f in files},'exclude':['all research directories','supplier PDFs, source CAD, source images','any WD220 source or derived supplier motor geometry','historical rejected E01 hardware','unfinished raised enclosure','recursive folder export'],'all_electrical_acceptance':False,'scope':'Original dimensions and interfaces, selected contracts, engineering facts/tests only.'}
(O/'PUBLIC_FILES_E04.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'geometry_parts':sum(g['parts']for g in geom),'nodes':len(nodes),'edges':len(connections),'unqualified_nodes':len(uncovered),'public_files':len(files),'end_to_end_complete':False}))
