"""Exact delta fit on SO01 body with semantic cuts; no selected body is overwritten."""
from pathlib import Path
import cadquery as cq,json,hashlib,sys
P=Path(__file__).resolve().parent;O=P/'victron_candidate/switchgear_E04';S=P.parent/'body-power/shock-opening-study'
bodyfile=S/'body_power_shock_clearance_SO01.step';m=json.loads((S/'replacement_manifest_SO01.json').read_text());ss=cq.importers.importStep(str(bodyfile)).val().Solids();assert len(ss)==len(m['parts']);body={r['name']:s for r,s in zip(m['parts'],ss)}
deckfile=S/'body_deck_SO01_E04_40holes.step';body['main_base_deck_3mm']=cq.importers.importStep(str(deckfile)).val()
c=json.loads((O/'rear_trough_patch_contract.json').read_text());newss=cq.importers.importStep(str(O/'aligned_trough_and_glands_E04.step')).val().Solids();assert len(newss)==len(c['parts']);new={r['name']:s for r,s in zip(c['parts'],newss)}
for r in c['changes']:
 if r['action'] in ['remove','replace']:body.pop(r['name'])
for h in c['partition_hole_cutters']:
 x,y,z=h['axis_C_mm'];lo,hi=h['cut_x_mm'];cut=cq.Workplane('YZ').center(y,z).circle(h['diameter_mm']/2).extrude(hi-lo).translate((lo,0,0)).val();body[h['target_part']]=body[h['target_part']].cut(cut)
for h in c['partition_trunk_slots']:
 sh=cq.Workplane('XY').box(*h['size_xyz_mm']).translate(tuple(h['center_C_mm'])).val();body[h['target_part']]=body[h['target_part']].cut(sh)
def bb(s):
 b=s.BoundingBox();return[b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
def hits(a,b):
 rows=[];contacts=[]
 for an,ash in a.items():
  aa=bb(ash)
  for bn,bsh in b.items():
   if an==bn:continue
   bo=bb(bsh)
   if any(aa[k]>bo[k+3]+1e-5 or bo[k]>aa[k+3]+1e-5 for k in range(3)):continue
   v=ash.intersect(bsh).Volume()
   if v>1e-4:rows.append({'a':an,'b':bn,'volume_mm3':v})
   elif ash.distance(bsh)<1e-4:contacts.append({'a':an,'b':bn})
 return rows,contacts
bad,contacts=hits(new,body);ownbad,owncontacts=hits(new,new)
switches={f'switchgear_solid_{i}':s for i,s in enumerate(cq.importers.importStep(str(O/'installed_isolators_E04.step')).val().Solids())};swbad,_=hits(switches,{**new,**body})
# The known nominal M6 shaft intersections with the old deck are removed by the actual composed40-hole deck.
leadfile=O/'isolator_service_lead_study_E04.step';leads={f'lead{i}':s for i,s in enumerate(cq.importers.importStep(str(leadfile)).val().Solids())};leadbad,leadcontacts=hits(leads,{**new,**body})
weldrows=[]
for w in c['welded_connections']:
 a=new[w['a']];b={**body,**new}[w['b']];weldrows.append({**w,'distance_mm':a.distance(b),'nominal_contact':a.distance(b)<1e-4,'positive_volume_overlap_mm3':a.intersect(b).Volume()})
# Contact areas of planar weld roots and support bearing faces are checked independently from distance.
for r in weldrows:
 a=new[r['a']];b={**body,**new}[r['b']];r['shared_face_area_mm2']=a.intersect(b).Area()
out={'revision':'E04','scope':'Actual exported original19-part aligned trough/gland delta against267-part SO01 body, actual40-hole deck,204switchgearparts and12serviceleads. Static only; source cabinet/gland contours simplified.','hashes':{p.name:hashlib.sha256(p.read_bytes()).hexdigest()for p in [bodyfile,deckfile,O/'aligned_trough_and_glands_E04.step',O/'installed_isolators_E04.step',leadfile]},'body_patches_simulated_not_applied':True,'body_overlaps':bad,'self_overlaps':ownbad,'switchgear_body_overlaps':swbad,'lead_body_overlaps':leadbad,'weld_checks':weldrows,'contacts':contacts+owncontacts,'lead_contacts':leadcontacts,'pass':not(bad or ownbad or swbad or leadbad)and all(w['nominal_contact']for w in weldrows),'motion_full_route_or_electrical_safety_qualified':False}
(O/'aligned_trough_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items()if k in ['pass','body_overlaps','self_overlaps','switchgear_body_overlaps','lead_body_overlaps']}))
