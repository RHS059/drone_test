"""Source-cable bend study at documented ABB lug mouths; free continuation endpoints stay open."""
from pathlib import Path
import cadquery as cq,json,math,hashlib
import cad_export as ce
P=Path(__file__).resolve().parent;O=P/'victron_candidate'/'switchgear_E04';ce.P=O
c=json.loads((O/'isolator_placement_contract.json').read_text());parts=[];rows=[]
for t in c['power_terminals']:
 p=t['wire_mouth_C_mm'];sy=t['outward_axis_C'][0];ref=t['id'].split(':')[0];d=next(d for d in c['devices'] if d['id']==ref);main=ref=='Q0';R=t['minimum_static_bend_radius_mm'];od=t['cable_nominal_OD_mm'];up=1 if main else -1;gap=5 if main else 10
 start=[d['origin_C_mm'][0]+sy*(156.8+gap),p[1],p[2]];end=[start[0]+sy*R,p[1],p[2]+up*R];mid=[start[0]+sy*R/math.sqrt(2),p[1],p[2]+up*R*(1-1/math.sqrt(2))]
 if ref=='QB2' and sy>0:
  start[0]=-1102;end[0]=start[0]+R;mid[0]=start[0]+R/math.sqrt(2)
 wire=cq.Wire.assembleEdges([cq.Edge.makeLine(cq.Vector(*p),cq.Vector(*start)),cq.Edge.makeThreePointArc(cq.Vector(*start),cq.Vector(*mid),cq.Vector(*end))])
 sh=cq.Workplane(cq.Plane(origin=tuple(p),normal=(sy,0,0),xDir=(0,1,0))).circle(od/2).sweep(wire,isFrenet=True).val();assert sh.isValid()
 parts.append((t['id'].replace(':','_')+'_service_lead_bend',sh,'cover','Clearance-study geometry for sourced fixed-installation cable; continuation is unresolved, not a completed electrical connection.'))
 b=sh.BoundingBox();bb=[b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax]
 rows.append({'terminal':t['id'],'wire_mouth_C_mm':p,'arc_start_C_mm':start,'arc_mid_C_mm':mid,'arc_end_C_mm':end,'bend_radius_mm':R,'outer_diameter_mm':od,'bounds_C_mm':bb,'wall_clearance_Y_mm':497-max(abs(b.ymin),abs(b.ymax)),'floor_clearance_mm':b.zmin-103,'roof_clearance_mm':337-b.zmax,'free_continuation_endpoint':True,'physical_electrical_continuity_verified':False})
meta=ce.export('isolator_service_lead_study_E04',parts,{'source':'LAPP fixed installation cable dimensions and6D bend radius','vehicle_placed':True,'clearance_study_only':True})
# Compare against actual original isolator models; the barrel-mouth face itself is permitted contact.
a=cq.importers.importStep(str(O/'installed_isolators_E04.step')).val();hits=[]
for (name,s,_,_),r in zip(parts,rows):
 v=s.intersect(a).Volume()
 if v>1e-3:hits.append({'lead':name,'overlap_mm3':v})
out={'scope':'Nominal 12 source-lug service bend envelopes, not complete routes or wire retention. Shows why main70mm² bends must turn upward rather than through the floor.','rows':rows,'overlaps_with_isolator_assembly':hits,'enclosure_box_only_pass':all(min(r['wall_clearance_Y_mm'],r['floor_clearance_mm'],r['roof_clearance_mm'])>0 for r in rows),'isolator_clearance_pass':not hits,'full_route_pass':False,'geometry':meta,'sources':[{'url':'https://imager.lapp.com/e/lapp/W13_z3JTFuRu06VMhqamTw~~/DB0047000EN.pdf','fact':'Minimum fixed-installation radius6xOD; one end bend3xOD not used for this conservative study.'},{'url':'https://products.lappgroup.com/online-catalogue/power-and-control-cables/expanded-ambient-temperatures/silicone-single-cores/oelflex-heat-180-sif.html','fact':'35mm²OD10.3,70mm²OD14.2; no ampacity or harsh mobile-environment approval inferred.'}]}
(O/'service_lead_check.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['rows','sources','geometry']}))
