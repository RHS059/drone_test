# Electrical E04 viewer checkpoint

This is a visibly installed-interface development candidate, not a complete or commissioned electrical system.

## Selected physical geometry

- Six original Gen4 Size2 housing/base/interface models on retained E02 carriers. The 165×187×71 mm envelope, 151×173 mounting pattern and legacy12 mm base are sourced. Copper terminal XY is sourced; terminal Z65 and header location/retention remain proposed. The matched WD220 inverter configuration is unresolved.
- Three ABB source-dimensional isolators, twelve shroud shells, twelve source-positioned blade/lug stacks and retained deck trays. Actual shroud clips, handle/shaft cut and exact DC circuit/protection qualification remain open.
- Lynx Smart BMS NG1000A LYN034170310 source-positioned M10 terminals and four retained M5 mounting stacks, replacing the old original PDU internal buses/guard. Source CAD was read privately for numeric datums; no supplier CAD or contours are published.
- Three aligned original aluminium cable troughs, six welded supports and two retained LAPP53111020/53119020 glands. The selected body owner package is body_shock_partition_replacements_SO02_E04P, which includes the actual40-hole deck and matching partition openings.
- Six original breakout cases with four retained M2 lid screws each, retaining E02 M4 case hardware and the mechanical carrier brackets/standoffs/M5 groups.
- Two visible UR OEMDC source-dimension cases labelled UNRETAINED. The trays do not establish controller retention. Source mounting and connector datums remain missing.
- Twelve local ABB lead bends are an optional incomplete-route overlay. Their free ends must not be displayed as finished circuits.

## Integration

Use electrical_connection_contract_E04.json geometry entries and exact named add/remove changes. Apply E02 first, then E04 overlays. Remove the old PDU internals and old breakout case/lid, rather than stacking both versions. Preserve E02 body fasteners and external PDU supports. All24 external mechanical breakout groups are explicitly addressed in the retained graph.

Only PUBLIC_FILES_E04.json allowlisted files are public. Never recursively publish this directory. Source PDFs, source CAD, images and all restricted motor materials are excluded. Generators that use E02 expect the separately frozen carrier_freeze_E02 checkpoint at its original relative path. No supplied motor STEP geometry is used.

## Tests and boundaries

- Actual body/frame/deck contacts and no-overlap checks pass for the accepted retained original interfaces.
- Aligned trough/glands clear all six R13 tower/module samples:78 suspension poses,35,682 separated pairs, conservative minimum23 mm. This is finite sampling, not continuous-motion qualification.
- Gen4 original housing models contact the existing bases/lugs/bolt proxies without positive overlap; this checks proposed geometry, not undocumented OEM terminal height.
- Original thread proxies use nominal cylindrical contact, not manufactured helical thread geometry. Grade, fit, torque, locking, strength and environment remain unqualified unless separately sourced.
- electrical_topology_E04.json explicitly separates DC, phase circuits, motor sensing, parking-brake coils, CANopen, raw sensorCAN, VE.Can and permission circuits.172 required cable edges remain unclosed; the model cannot be called electrically complete.

## Operating constraints

Two Victron51.2V100Ah batteries are a BA02 mechanically bounded candidate. Source temperature limits and per-pack current sharing apply.180A is a warm-bank development ceiling that is not implemented or enforced. Arms/auxiliary current must be deducted before traction. Six2.2kW outputs need at least368.3ADC at44.8V and80% efficiency, before arms/auxiliaries, so full simultaneous nameplate output is unsupported.

Unresolved operating gates include the exact motor/inverter/encoder pairing, per-branch Gen4 precharge, two UR softstarts, actual coordinated fuses/covered holders, branch contactor variants, per-branch sensing and auxiliary conversion, regen inhibition and a safe braking/sink strategy. Delayed Lynx protection is not vehicle stopping logic. ATC/ATD dry contacts must not feed48V AUX into24V controller inputs.

The moving-corner harness still needs selected retained strain relief, torsion/bend/service-loop geometry and full combined-travel clearance, plus actual motor pigtail identities. No arbitrary pipe or unlabelled motor protrusion closes that gap.
