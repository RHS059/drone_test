"""Geometric development checks of exported original body opening patch."""
from pathlib import Path
import sys,json,math
import cadquery as cq
import build_shock_openings_SO01 as g
P=g.P;sys.path.insert(0,str(g.PR));import check_panel_retention as prcheck

def read_export():
 m=json.loads((P/'replacement_manifest_SO02.json').read_text());ss=cq.importers.importStep(str(P/'body_power_shock_clearance_SO02.step')).val().Solids();assert len(ss)==len(m['parts']);out=[]
 for s,r in zip(ss,m['parts']):
  assert max(abs(x-y)for x,y in zip(g.bb(s),r['bounds_mm']))<1e-4;assert abs(s.Volume()-r['volume_mm3'])<1e-3
  out.append(dict(name=r['name'],shape=s,material=r['material'],group=r['group'],note='SO02 exported STEP roundtrip'))
 return m,out

def check():
 m,parts=read_export();named={p['name']:p['shape']for p in parts};boxes={n:g.bb(s)for n,s in named.items()};g.TOWER_REV='R13';cs=g.corners();rows=[];fail=[];clearances=[]
 def screen(s,corner,kind,q=None):
  bounds=g.bb(s);hits=[];nearrows=[]
  for n,o in named.items():
   if not g.near(bounds,boxes[n],10):continue
   v=s.intersect(o).Volume() if g.near(bounds,boxes[n])else 0.;d=s.distance(o)
   r=dict(corner=corner,component=kind,q_deg=q,body_part=n,overlap_mm3=v,minimum_distance_mm=d);nearrows.append(r)
   if v>1e-3:hits.append(r);fail.append(r);print('CLASH',r,flush=True)
  rows.extend(nearrows)
  return hits
 for c in cs:
  screen(c['shape'],c['name'],'R13_stationary_tower')
  for q in range(-12,13,2):
   for name,s in g.modules(c,q):screen(s,c['name'],name,q)
   print('MOTION',c['name'],q,'failures',len(fail),flush=True)
  (P/'clearance_check_SO02.json').write_text(json.dumps({'status':'running','rows':rows,'failures':fail},indent=2))
 # Replay all PR01 body/frame connections against the new exported skins.
 prmanifest=json.loads((g.PR/'replacement_addition_manifest.json').read_text());
 for override in m.get('retention_axis_overrides',[]):
  next(j for j in prmanifest['joints']if j['id']==override['joint'])['axis_C_mm']=override['axis_C_mm']
 prcheck.g.PARTS=parts;prcheck.g.JOINTS=prmanifest['joints'];prcheck.g.WELDS=prmanifest['welded_connections'];prcheck.g.SERVICE=prmanifest['retained_service_groups'];prcheck.g.TIE_RODS=prmanifest['battery_tie_rods']
 old={p['name']:p['shape']for p in g.load_body()}
 rr=prcheck.check(old,Path('/workspace/shared/ugv-reconstruction/mechanical/frame_R07.step'),P)
 # Existing check writes retention_check.json only in this isolated task folder.
 # Check real circular hole faces plus an intact 1 mm surrounding annulus.
 deck=named['main_base_deck_3mm'];holes=[]
 for h in json.loads((g.BODY/'R02/body_attachment_patch.json').read_text())['holes']:
  x,y,z=[v*1000 for v in h['axis_C_m']];bore=g.b.cyl(3.3,3,(x,y,100));annulus=g.b.cyl(4.3,3,(x,y,100)).cut(bore);void=deck.intersect(bore).Volume();solid=deck.intersect(annulus).Volume();radii=prcheck.hole_radii(deck,[x,y,100],[0,0,1]);holes.append({'id':h['id'],'residual_bore_mm3':void,'support_annulus_mm3':solid,'required_annulus_mm3':annulus.Volume(),'face_radii_mm':radii,'pass':void<1e-5 and abs(solid-annulus.Volume())<1e-4 and 3.3 in radii})
 # Cover 2 unseating against actual tower AND guided module, conservative spring cylinder.
 cover='right_side_service_cover_2';service=[];c=next(c for c in cs if c['name']=='middle_right')
 for q in [-12,0,12]:
  obstacles=[('tower',c['shape'])]+g.modules(c,q)
  for travel in list(range(0,201,5)):
   s=named[cover].translate((0,-travel,0));sb=g.bb(s);hits=[]
   for name,o in obstacles:
    if not g.near(sb,g.bb(o)):continue
    v=s.intersect(o).Volume()
    if v>1e-3:hits.append({'obstacle':name,'overlap_mm3':v})
   service.append({'q_deg':q,'outward_displacement_mm':travel,'hits':hits,'pass':not hits})
 # Straight external wrench envelopes with suspension installed.
 tools=[]
 for j in prmanifest['joints']:
  if j['cover']!=cover:continue
  x,y,z=j['axis_C_mm'];tool=cq.Solid.makeCylinder(6,60,cq.Vector(x,-523.7,z),cq.Vector(0,-1,0));tb=g.bb(tool);hits=[]
  for q in [-12,0,12]:
   for name,o in [('tower',c['shape'])]+g.modules(c,q):
    if not g.near(tb,g.bb(o)):continue
    v=tool.intersect(o).Volume()
    if v>1e-3:hits.append({'q_deg':q,'obstacle':name,'overlap_mm3':v})
  tools.append({'joint':j['id'],'tool_diameter_mm':12,'tool_length_mm':60,'hits':hits,'pass':not hits})
 report={'revision':'SO02','source_step_sha256':g.sha(P/'body_power_shock_clearance_SO02.step'),'tower_revision':'R13','tower_source_hashes':{c['source']:g.sha(c['source'])for c in cs},'scope':'Actual R13 tower B-reps and all 24 R08 guided-module nodes versus 267 original body parts. Spring checked with filled OD110 reservation rather than approximate helical visual. q −12..12 in2 degree steps, six corners,78 poses; no continuous-motion or load qualification. Full PR01 nominal hardware/body/frame retention replay also performed.','body_parts_valid_single_solids':all(p['shape'].isValid()and len(p['shape'].Solids())==1 for p in parts),'rows':rows,'failures':fail,'static_and_sampled_motion_clear':not fail,'R02_electrical_deck_holes':holes,'all_28_bores_and_surrounding_annuli_preserved':len(holes)==28 and all(h['pass']for h in holes),'retention_check_file':'retention_check.json','retention_geometry_pass':rr['geometry_pass'],'right_middle_cover_suspension_unseating':service,'right_middle_cover_tool_access':tools,'right_middle_cover_fastener_relayout':m.get('retention_axis_overrides',[]),'limitations':['New-profile clearance is3 mm nominal; existing clamp/body reliefs have2 mm minimum. Manufacturing/deflection clearance unqualified.','Original tapped-thread nominal cylinders and proposed welded clips retained; no fastener grade/preload/locking qualification.','Narrow cover header, body opening edge stiffness, sealing and full field service remain unqualified.'],'geometry_pass':not fail and rr['geometry_pass'] and all(h['pass']for h in holes) and all(s['pass']for s in service) and all(t['pass']for t in tools)}
 (P/'clearance_check_SO02.json').write_text(json.dumps(report,indent=2)+'\n');print('RESULT',json.dumps({k:v for k,v in report.items()if k in ['geometry_pass','static_and_sampled_motion_clear','all_28_bores_and_surrounding_annuli_preserved','retention_geometry_pass','right_middle_cover_fastener_relayout_needed']}),flush=True)
 return report
if __name__=='__main__':check()
