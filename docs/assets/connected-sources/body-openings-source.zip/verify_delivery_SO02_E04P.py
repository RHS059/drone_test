"""Round-trip selected named STEP/GLB package; no geometric source changes."""
import json,struct
import numpy as np
import build_shock_openings_SO01 as g
P=g.P;m=json.loads((P/'partition_trough_check_SO02_E04P.json').read_text());m['selected_replacement_package']=m['selected_step'];m['selected_replacement_glb']=m['selected_glb'];ss=g.cq.importers.importStep(str(P/m['selected_replacement_package'])).val().Solids();blob=(P/m['selected_replacement_glb']).read_bytes();ln=struct.unpack_from('<I',blob,12)[0];j=json.loads(blob[20:20+ln]);buf=blob[28+ln:];rows=[]
assert len(ss)==len(j['nodes'])==len(m['parts'])==20
for s,r,node in zip(ss,m['parts'],j['nodes']):
 assert node['name']==r['name'];prim=j['meshes'][node['mesh']]['primitives'][0];a=j['accessors'][prim['attributes']['POSITION']];view=j['bufferViews'][a['bufferView']];pts=np.frombuffer(buf,dtype=np.float32,count=a['count']*3,offset=view.get('byteOffset',0)+a.get('byteOffset',0)).reshape(-1,3)*1000;gb=np.r_[pts.min(axis=0),pts.max(axis=0)];sb=np.array(g.bb(s));be=float(np.max(np.abs(sb-r['bounds_mm'])));ge=float(np.max(np.abs(sb-gb)));ve=abs(s.Volume()-r['volume_mm3']);rows.append({'name':r['name'],'valid':s.isValid(),'solid_count':len(s.Solids()),'STEP_bounds_error_mm':be,'STEP_volume_error_mm3':ve,'GLB_bounds_error_mm':ge,'pass':s.isValid()and len(s.Solids())==1 and be<1e-4 and ve<1e-3 and ge<.35})
old={p['name']:p['shape']for p in g.load_body()};changes=[]
for s,r in zip(ss,m['parts']):
 a=s.cut(old[r['name']]).Volume();removed=old[r['name']].cut(s).Volume();changes.append({'name':r['name'],'added_volume_mm3':a,'removed_volume_mm3':removed,'strictly_subtractive':a<1e-3,'authorized_service_relayout':r['name']=='right_side_service_cover_2' or r['name'].startswith(('right_service_nutclip_2_1','right_service_nutclip_2_2'))})
out={'revision':'SO02_E04P','selected_STEP':m['selected_replacement_package'],'selected_GLB':m['selected_replacement_glb'],'rows':rows,'subtractive_patch_checks':changes,'named_count':len(rows),'pass':all(r['pass']for r in rows)and all(c['strictly_subtractive']or c['authorized_service_relayout']for c in changes),'source_sha256':{f:g.sha(P/f)for f in [m['selected_replacement_package'],m['selected_replacement_glb']]}}
(P/'delivery_roundtrip_SO02_E04P.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2),flush=True)
