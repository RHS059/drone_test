import json
import build_shock_openings_SO01 as g
import check_shock_openings_SO01 as v
_,ps=v.read_export();p={p['name']:p['shape']for p in ps};c=next(x for x in g.corners()if x['name']=='middle_right');cover=p['right_side_service_cover_2'];rows=[]
for q in [-12,0,12]:
 obs=[('tower',c['shape'])]+g.modules(c,q)
 for travel in [40,50,60,70,80,90,100,120,140,160,200]:
  s=cover.translate((0,-travel,0));sb=g.bb(s)
  for n,o in obs:
   if not g.near(sb,g.bb(o)):continue
   it=s.intersect(o)
   if it.Volume()>1e-3:rows.append({'q':q,'travel':travel,'obstacle':n,'volume':it.Volume(),'intersection_bounds':g.bb(it),'in_cover_coordinates':g.bb(it.translate((0,travel,0)))})
(g.P/'cover_service_intersections_SO01.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(rows,indent=2),flush=True)
