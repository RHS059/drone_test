"""Apply electrical-owner exact partition cutters and screen its original trough.
No electrical-owned file is edited. Scope is hash-pinned E04 development candidate.
"""
import json,struct,math
from pathlib import Path
import numpy as np
import cadquery as cq
import build_shock_openings_SO01 as g
import check_shock_openings_SO02 as v
P=g.P;E=g.BODY.parent/'electrical-drive/victron_candidate/switchgear_E04';F=E/'rear_trough_patch_contract.json';S=E/'aligned_trough_and_glands_E04.step'
EXPECTED='98f1584c0d7d2a4e48c26c6215782e8ba7e95a23107b59b08ae8780d620df770';assert g.sha(S)==EXPECTED;fh=g.sha(F);contract=json.loads(F.read_text());shapes=cq.importers.importStep(str(S)).val().Solids();blob=(E/'aligned_trough_and_glands_E04.glb').read_bytes();ln=struct.unpack_from('<I',blob,12)[0];jn=json.loads(blob[20:20+ln])['nodes'];assert len(shapes)==len(contract['parts'])==len(jn)==19
obs=[]
for s,r,n in zip(shapes,contract['parts'],jn):
 assert r['name']==n['name'];assert max(abs(x-y)for x,y in zip(g.bb(s),r['bounds_mm']))<.2,(r['name'],g.bb(s),r['bounds_mm']);assert s.isValid()and len(s.Solids())==1
 obs.append((r['name'],s,g.bb(s)))
# Retain all original parts except the exact named body sheets selected for these cutters.
m,parts=v.read_export();by={p['name']:p for p in parts};patches={};cutrows=[]
for r in contract['partition_trunk_slots']:
 n=r['target_part'];old=patches.get(n,by[n]['shape']);cut=g.b.box(*r['size_xyz_mm'],tuple(r['center_C_mm']));removed=old.intersect(cut);s=old.cut(cut);patches[n]=s;cutrows.append({'id':n+'_trunk_slot','target_part':n,'type':'rectangular trunk aperture','cutter':r,'actual_removed_volume_mm3':removed.Volume(),'actual_removed_bounds_mm':g.bb(removed)})
for r in contract['partition_hole_cutters']:
 n=r['target_part'];old=patches.get(n,by[n]['shape']);x,y,z=r['axis_C_mm'];a,b=r['cut_x_mm'];radius=r['diameter_mm']/2;cut=cq.Solid.makeCylinder(radius,b-a,cq.Vector(a,y,z),cq.Vector(1,0,0));removed=old.intersect(cut);s=old.cut(cut);patches[n]=s;assert abs(removed.Volume()-math.pi*radius**2*3)<1e-3;cutrows.append({'id':r['id'],'target_part':n,'type':'gland bore','cutter':r,'actual_removed_volume_mm3':removed.Volume(),'actual_removed_bounds_mm':g.bb(removed)})
for n,s in patches.items():assert s.isValid()and len(s.Solids())==1;assert s.cut(by[n]['shape']).Volume()<1e-5
# Preserve full1 mm annulus at both gland bores, with exact coaxial cylindrical faces.
holes=[]
for r in contract['partition_hole_cutters']:
 x,y,z=r['axis_C_mm'];rad=r['diameter_mm']/2;s=patches[r['target_part']];cyl=lambda rr:cq.Solid.makeCylinder(rr,3,cq.Vector(-1143,y,z),cq.Vector(1,0,0));bore=cyl(rad);ring=cyl(rad+1).cut(bore);res=s.intersect(bore).Volume();ann=s.intersect(ring).Volume();radii=v.prcheck.hole_radii(s,[x,y,z],[1,0,0]);holes.append({'id':r['id'],'residual_bore_mm3':res,'surrounding_annulus_mm3':ann,'required_annulus_mm3':ring.Volume(),'coaxial_radii_mm':radii,'pass':res<1e-5 and abs(ann-ring.Volume())<1e-3 and rad in radii})
# Check intended retained gland seating and nominal locking-nut contact.
allparts={p['name']:p['shape']for p in parts};allparts.update(patches);allparts.update({n:s for n,s,b in obs});seats=[]
for y in [366.5,443.5]:
 names=[f'QB2_partition_gland_{y}_53111020_body',f'QB2_partition_gland_{y}_53119020_locknut'];host=patches['controller_battery_partition']
 for n in names:
  dist=allparts[n].distance(host);vol=allparts[n].intersect(host).Volume();seats.append({'part':n,'host':'controller_battery_partition','distance_mm':dist,'overlap_mm3':vol,'pass':dist<1e-5 and vol<1e-3})
# Every electrical support/weld interface is rechecked against the two newly exported sheets.
welds=[]
for r in contract['welded_connections']:
 a=allparts[r['a']];b=allparts[r['b']];dist=a.distance(b);vol=a.intersect(b).Volume();welds.append({**r,'distance_mm':dist,'overlap_mm3':vol,'pass':dist<1e-5 and vol<1e-3})
# Body partition neighbours, including original retained hatch ledges/bosses, remain fit.
body_clashes=[]
for n,s in patches.items():
 for other,o in allparts.items():
  if other==n or not g.near(g.bb(s),g.bb(o)):continue
  vv=s.intersect(o).Volume()
  if vv>1e-3:body_clashes.append({'partition':n,'other':other,'overlap_mm3':vv})
# Existing old duct pieces are replaced by the electrical delta and excluded from the selected check.
replaced_or_removed={r['name']for r in contract['changes']if r['action']in ['remove','replace']}
body_clashes=[r for r in body_clashes if r['other']not in replaced_or_removed or r['other']in dict((n,s)for n,s,b in obs)]
rows=[];failures=[];casebounds=[]
def gap(a,b):return float(np.linalg.norm([max(0,a[k]-b[k+3],b[k]-a[k+3])for k in range(3)]))
def screen(s,corner,node,q):
 bs=g.bb(s);casebounds.append({'corner':corner,'node':node,'q_deg':q,'bounds_mm':bs})
 for name,o,bo in obs:
  lower=gap(bs,bo);vv=0 if lower>1e-6 else s.intersect(o).Volume();row={'corner':corner,'node':node,'q_deg':q,'electrical_part':name,'AABB_distance_lower_bound_mm':lower,'overlap_mm3':vv};rows.append(row)
  if vv>1e-3:failures.append(row)
for c in g.corners():
 screen(c['shape'],c['name'],'R13_stationary_tower',None)
 for q in range(-12,13,2):
  for name,s in g.modules(c,q):screen(s,c['name'],name,q)
 print('SCREENED',c['name'],'failures',len(failures),flush=True)
assert g.sha(S)==EXPECTED and g.sha(F)==fh,'Electrical candidate changed while checking.'
# Export exactly two partition replacements and the full20-part selected body patch.
partrows=[]
for n,s in patches.items():
 p=dict(by[n]);p['shape']=s;p['note']='SO02_E04P: exact electrical-owner E04 trunk slot / gland bore cutters; original remaining sheet preserved.';partrows.append(p)
base_manifest=json.loads((P/'combined_deck_manifest_SO02_E04.json').read_text());base_solids=cq.importers.importStep(str(P/base_manifest['selected_replacement_package'])).val().Solids();base_patch=[]
for s,r in zip(base_solids,base_manifest['parts']):
 p=dict(by[r['name']]);p['shape']=s;base_patch.append(p)
final=base_patch+partrows;assert len(final)==20 and len({p['name']for p in final})==20
for stem,ps in [('body_partition_openings_SO02_E04P',partrows),('body_shock_partition_replacements_SO02_E04P',final)]:
 a=cq.Assembly(name=stem)
 for p in ps:a.add(p['shape'],name=p['name'],color=cq.Color(*g.b.MATS[p['material']]['color']))
 a.export(str(P/(stem+'.step')));g.b.export_glb(ps,P/(stem+'.glb'))
cs=g.corners();sourcehash={str(F):fh,str(S):EXPECTED,str(P/'body_power_shock_clearance_SO02.step'):g.sha(P/'body_power_shock_clearance_SO02.step'),str(P/'body_shock_opening_replacements_SO02_E04.step'):g.sha(P/'body_shock_opening_replacements_SO02_E04.step')};sourcehash.update({c['source']:g.sha(c['source'])for c in cs})
report={'revision':'SO02_E04P','electrical_candidate_frozen':contract.get('freeze',False),'source_sha256':sourcehash,'scope':'Actual original19-part aligned trough/glands candidate versus all sixR13 towers and24R08 module nodes at78q poses; filledOD110 spring reservation. Exact bounds used for provable separation, with B-rep Boolean fallback for overlapping bounds. No electrical-owned source changed.','pair_checks':len(rows),'minimum_AABB_separation_mm':min(r['AABB_distance_lower_bound_mm']for r in rows),'Boolean_fallback_pair_count':sum(r['AABB_distance_lower_bound_mm']<=1e-6 for r in rows),'failures':failures,'module_bounds':casebounds,'partition_cuts':cutrows,'gland_bores':holes,'gland_seating':seats,'electrical_weld_fits':welds,'partition_body_overlaps':body_clashes,'geometry_pass':not failures and not body_clashes and all(x['pass']for x in holes+seats+welds),'selected_step':'body_shock_partition_replacements_SO02_E04P.step','selected_glb':'body_shock_partition_replacements_SO02_E04P.glb','replace_by_name':[p['name']for p in final],'parts':[{'name':p['name'],'bounds_mm':g.bb(p['shape']),'volume_mm3':p['shape'].Volume(),'valid':p['shape'].isValid(),'solid_count':len(p['shape'].Solids())}for p in final],'integration_rule':'Use this20-part body replacement package instead of the18-part SO02_E04 package. Apply electrical19-part trough/gland delta separately using its removal/replacement manifest. Keep only one copy of each named component. All40 deck bores and revisedX279 cover stacks are included unchanged.','open_gates':['Electrical candidate contract is not freeze/release approval.','Original gland exterior and threads simplified; clamp/IP performance untested.','Partition edge stiffness, new slot corners, welds, sealing and all structural qualification open.','Discreteq screen does not certify continuous motion or final integrated whole-vehicle geometry.'],'outputs':{f:g.sha(P/f)for f in ['body_partition_openings_SO02_E04P.step','body_partition_openings_SO02_E04P.glb','body_shock_partition_replacements_SO02_E04P.step','body_shock_partition_replacements_SO02_E04P.glb']}}
(P/'partition_trough_check_SO02_E04P.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k]for k in ['geometry_pass','pair_checks','minimum_AABB_separation_mm','Boolean_fallback_pair_count','failures','partition_body_overlaps','outputs']}),flush=True)
