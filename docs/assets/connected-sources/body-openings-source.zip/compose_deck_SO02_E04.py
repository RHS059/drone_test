"""Compose frozen 12 E04 bores with SO02 skin openings, retaining 28 R02 bores."""
from pathlib import Path
import json,math
import cadquery as cq
import build_shock_openings_SO01 as g
import check_shock_openings_SO02 as v
P=g.P;F=g.BODY.parent/'electrical-drive/victron_candidate/switchgear_E04/deck_holes_coordinate_freeze.json'
EXPECTED='787152d50f6573ed6f2f78ae6473859c013be2c3781e4b588aabd972166fdd07'
assert g.sha(F)==EXPECTED
contract=json.loads(F.read_text());assert contract['coordinate_freeze'];newholes=contract['body_deck_patch'];assert len(newholes)==12
m,parts=v.read_export();d=next(p for p in parts if p['name']=='main_base_deck_3mm');old=d['shape'];deck=old;cutchecks=[]
for h in newholes:
 x,y,z=h['center_C_mm'];lo,hi=h['cut_z_mm'];r=h['diameter_mm']/2;tool=g.b.cyl(r,hi-lo,(x,y,lo));removed=deck.intersect(tool).Volume();required=math.pi*r*r*3;assert abs(removed-required)<1e-4,(h['id'],removed,required);deck=deck.cut(tool);cutchecks.append({'id':h['id'],'removed_mm3':removed,'expected_mm3':required,'pass':abs(removed-required)<1e-4})
assert deck.isValid()and len(deck.Solids())==1
d['shape']=deck;d['note']='SO02 exact-profile shock skin openings plus 28 original R02 and 12 frozen E04 electrical deck bores. All40 Ø6.6.'
allholes=[dict(id=h['id'],center_C_mm=[x*1000 for x in h['axis_C_m']],diameter_mm=h['diameter_mm'])for h in json.loads((g.BODY/'R02/body_attachment_patch.json').read_text())['holes']]+newholes
checks=[]
for h in allholes:
 x,y,z=h['center_C_mm'];r=h['diameter_mm']/2;bore=g.b.cyl(r,3,(x,y,100));ring=g.b.cyl(r+1,3,(x,y,100)).cut(bore);void=deck.intersect(bore).Volume();surround=deck.intersect(ring).Volume();radii=v.prcheck.hole_radii(deck,[x,y,100],[0,0,1]);checks.append({'id':h['id'],'center_C_mm':[x,y,100],'diameter_mm':2*r,'residual_bore_mm3':void,'support_annulus_mm3':surround,'expected_support_annulus_mm3':ring.Volume(),'coaxial_face_radii_mm':radii,'pass':void<1e-5 and abs(surround-ring.Volume())<1e-4 and r in radii})
# Explicitly prove strictly subtractive composition, so a previously clear tower cannot gain a collision.
added=deck.cut(old).Volume();removed=old.cut(deck).Volume();assert added<1e-5;assert abs(removed-sum(c['expected_mm3']for c in cutchecks))<1e-3
# One final18-part package: combined deck plus unchanged17 other SO02 replacements.
changes={x['name']for x in m['changes']};patch=[p for p in parts if p['name']in changes]
for stem,pp in [('body_deck_SO02_E04_40holes',[d]),('body_shock_opening_replacements_SO02_E04',patch)]:
 a=cq.Assembly(name=stem)
 for p in pp:a.add(p['shape'],name=p['name'],color=cq.Color(*g.b.MATS[p['material']]['color']))
 a.export(str(P/(stem+'.step')));g.b.export_glb(pp,P/(stem+'.glb'))
reimport=cq.importers.importStep(str(P/'body_deck_SO02_E04_40holes.step')).val().Solids();assert len(reimport)==1;reimport=reimport[0];err=abs(reimport.Volume()-deck.Volume());assert err<1e-3
out={'revision':'SO02_E04','selected_replacement_package':'body_shock_opening_replacements_SO02_E04.step','selected_replacement_glb':'body_shock_opening_replacements_SO02_E04.glb','integration_rule':'Use this 18-part package instead of all SO01 packages or the SO02-only 18-part package. Replace these existing named parts after PR01; never layer them. One selected main_base_deck_3mm includes all40 bores and shock openings. No concurrent battery well, rear duct or partition replacement is included.','source_SO02_step_sha256':g.sha(P/'body_power_shock_clearance_SO02.step'),'electrical_hole_contract':str(F),'electrical_hole_contract_sha256':EXPECTED,'preserved_R02_count':28,'new_E04_count':12,'total_holes':40,'named_replacements':[p['name']for p in patch],'parts':[{'name':p['name'],'volume_mm3':p['shape'].Volume(),'bounds_mm':g.bb(p['shape']),'valid':p['shape'].isValid(),'solid_count':len(p['shape'].Solids())}for p in patch],'new_bore_removals':cutchecks,'holes':checks,'strictly_subtractive_added_volume_mm3':added,'total_removed_mm3':removed,'expected_removed_mm3':12*math.pi*3.3**2*3,'STEP_roundtrip_volume_error_mm3':err,'nominal_geometry_pass':all(x['pass']for x in checks)and added<1e-5 and err<1e-3,'remaining_gates':'SO02 clearance/retention report remains applicable geometrically because deck operation is strictly subtractive and remote from retained body connections. Actual E04 support stacks and full integrated assembly are checked by electrical owner; no structural/sealing release.','outputs':{f:g.sha(P/f)for f in ['body_deck_SO02_E04_40holes.step','body_deck_SO02_E04_40holes.glb','body_shock_opening_replacements_SO02_E04.step','body_shock_opening_replacements_SO02_E04.glb']}}
(P/'combined_deck_manifest_SO02_E04.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k]for k in ['revision','total_holes','nominal_geometry_pass','outputs']}),flush=True)
