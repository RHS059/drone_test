"""Exact exported STEP closeups using scientific triangle plots; not Blender."""
import json,textwrap
import numpy as np
import cadquery as cq
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LightSource
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
import check_shock_openings_SO02 as v
import build_shock_openings_SO01 as g
P=g.P;m,parts=v.read_export();g.TOWER_REV='R13';corners=g.corners();named={p['name']:p for p in parts}
def draw(file,title,sub,corner,limits,elev,azim,section=None):
 fig=plt.figure(figsize=(13,8),dpi=170,facecolor='#f4f6f8');ax=fig.add_subplot(111,projection='3d');ax.set_facecolor('#f4f6f8');bb=np.array(limits,float);ext=bb[3:]-bb[:3];cutbb=bb.copy()
 if section:
  k,coord,sign=section;cutbb[k if sign>0 else k+3]=coord
 crop=g.b.box(*(cutbb[3:]-cutbb[:3]),tuple((cutbb[:3]+cutbb[3:])/2));c=next(c for c in corners if c['name']==corner)
 shapes=[(p['name'],p['shape'],g.b.MATS[p['material']]['color'])for p in parts];shapes.append(('frame-owned R13 tower',c['shape'],[.10,.34,.47,1]))
 for n,s in g.modules(c,0):
  if 'filled_OD110'not in n:shapes.append((n,s,[.63,.68,.72,1]))
 triangles=[];colors=[]
 for name,s,color in shapes:
  if not g.near(g.bb(s),cutbb):continue
  sh=s.intersect(crop)
  if sh.Volume()<1e-5:continue
  vert,face=sh.tessellate(.15,.15);t=np.array([[p.x,p.y,p.z]for p in vert])[np.array(face)]
  col=color
  if 'right_side_service_cover_2'==name:col=[.82,.62,.32,1]
  elif name.startswith('right_service_nutclip_2'):
   col=[.86,.34,.07,1]if name.endswith('M6x20')else[.06,.54,.57,1]if 'washer'not in name else[.74,.76,.78,1]
  triangles.extend(t);colors.extend([col]*len(t))
 coll=Poly3DCollection(triangles,facecolors=colors,edgecolors='#28343b',linewidths=.08,shade=True,lightsource=LightSource(azdeg=310,altdeg=45));ax.add_collection3d(coll);ax.set_xlim(bb[0],bb[3]);ax.set_ylim(bb[1],bb[4]);ax.set_zlim(bb[2],bb[5]);ax.set_box_aspect(ext);ax.view_init(elev=elev,azim=azim);ax.set_proj_type('ortho');ax.set_xlabel('X (mm)');ax.set_ylabel('Y (mm)');ax.set_zlabel('Z (mm)');
 if section:ax.set_xticks([]);ax.set_xlabel('')
 fig.suptitle(title,fontsize=18,x=.055,ha='left',y=.98);fig.text(.055,.92,textwrap.fill(sub,140),fontsize=10,va='top');fig.text(.055,.025,'Original delivered STEP geometry. Blue: frame-owned R13 tower; ochre: removable cover; teal: retained clips/bosses; orange: screws.\nDevelopment candidate only. Opening stiffness, weld/fastener strength, sealing and continuous-travel qualification remain open.',fontsize=9,color='#3a4c60');fig.subplots_adjust(top=.86,bottom=.08,left=.02,right=.99);fig.savefig(P/file);plt.close(fig);print('PNG',file,flush=True)
draw('right_middle_opening_closeup_SO02.png','Right-middle shock opening and retained service cover','3 mm rounded profile clearance around the actual tower; cover widened locally for the outboard carrier stays. Two left screw stacks are at X279; both right stacks stay at X497. The cover stays one solid, with a 12 mm top header.','middle_right',[220,-595,95,535,-480,238],18,-75)
draw('right_middle_clip_section_SO02.png','Right-middle cover: retained lower-left screw section','Section through the real M6 stack at X279, Z164. The complete left stack is shifted4 mm to preserve12 mm hole edge distance beside the widened service slot.','middle_right',[263,-535,144,309,-487,187],8,180,(0,279,1))
draw('front_right_opening_closeup_SO02.png','Front-right opening: side, base and sloped nose','Tower silhouette is relieved through each actual skin intersection. The narrow nose-wall proximity relief retains the complete panel and its existing seams.','front_right',[1550,-600,90,1960,-470,245],22,-115)
draw('rear_left_opening_closeup_SO02.png','Rear-left tower: local deck, side and bulkhead relief','The suspension tower stays attached to the rail clamp. Body material removal is limited to the offset tower silhouette and nearby skin band.','rear_left',[-1910,475,90,-1545,605,240],20,120)
