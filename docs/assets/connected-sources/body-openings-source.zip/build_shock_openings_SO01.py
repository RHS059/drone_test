"""Original C04 body opening patch SO01. STEP mm, GLB metres, vehicle Z up.
Uses per-corner tower silhouette with 3 mm offset, never a whole-body blind box.
Source PR01 is immutable; electrical R02 28 holes retained. No supplier geometry.
"""
from pathlib import Path
import json, math, sys, hashlib, struct
import numpy as np
import cadquery as cq
P=Path(__file__).resolve().parent; BODY=P.parent; PR=BODY/'panel-retention'
MECH=Path('/workspace/shared/ugv-reconstruction/mechanical/connection_completion_C04')
sys.path.insert(0,str(BODY));import build_body_power as b
CLEAR=3.;REV='SO01';TOWER_REV='R13'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bb(s):
 from OCP.Bnd import Bnd_Box
 from OCP.BRepBndLib import BRepBndLib
 bounds=Bnd_Box();BRepBndLib.AddOptimal_s(s.wrapped,bounds,False,False);return list(bounds.Get())
def near(a,b,tol=0):return all(a[k]<=b[k+3]+tol and b[k]<=a[k+3]+tol for k in range(3))
def tf(s,B,p):return s.moved(cq.Location(cq.Plane(origin=tuple(p),xDir=tuple(B[:,0]),normal=tuple(B[:,2]))))
def rx(a):return np.array([[1,0,0],[0,math.cos(a),-math.sin(a)],[0,math.sin(a),math.cos(a)]])
def load_body():
 rows=json.loads((PR/'retention_check.json').read_text())['parts'];sh=cq.importers.importStep(str(PR/'body_power_panel_retained_PR01.step')).val().Solids();blob=(PR/'body_power_panel_retained_PR01.glb').read_bytes();nl=struct.unpack_from('<I',blob,12)[0];glb=json.loads(blob[20:20+nl]);parts=[]
 assert len(sh)==len(rows)==len(glb['nodes'])==267
 for s,r,node in zip(sh,rows,glb['nodes']):
  assert r['name']==node['name'];assert max(abs(x-y)for x,y in zip(bb(s),r['bounds_mm']))<1e-4;assert abs(s.Volume()-r['volume_mm3'])<1e-3
  material=glb['materials'][glb['meshes'][node['mesh']]['primitives'][0]['material']]['name']
  parts.append({'name':r['name'],'shape':s,'material':material,'group':node['extras']['group'],'note':node['extras'].get('note','')})
 return parts

def corners():
 out=[]
 for fore,end in [(-1,'rear'),(0,'middle'),(1,'front')]:
  for side,label in [(1,'left'),(-1,'right')]:
   source=f'stationary_clamp_{end}_{label if fore else "left"}_offset_C04_{TOWER_REV}'
   path=MECH/'offset_supports'/(source+'.step');s=cq.importers.importStep(str(path)).val()
   if not fore and side<0:s=s.rotate((0,0,0),(0,0,1),180)
   s=s.translate((1350*fore,0,0));offset=-350*side if not fore else 550*fore
   # Exact source X/Z silhouette: native middle-right is proper Rz180.
   direction=1 if offset<0 else -1;oo=-abs(offset)
   poly=[(1350*fore+direction*x,z)for x,z in [(oo-45,70),(-170,70),(-170,110),(oo+45,140),(oo+45,200),(oo-45,200)]]
   # Offset wire uses round joins: exact straight edges + radius3 arcs.
   wire=cq.Wire.makePolygon([cq.Vector(x,0,z)for x,z in poly],close=True);ow=wire.offset2D(CLEAR,kind='arc')[0]
   cutter=cq.Solid.extrudeLinear(ow,[],cq.Vector(0,18,0)).translate((0,507 if side>0 else -525,0))
   out.append({'name':end+'_'+label,'fore':fore,'side':side,'shape':s,'source':str(path),'offset':offset,'polygon_xz_mm':poly,'cutter':cutter,'bounds':bb(s)})
 return out

def modules(cs,q):
 nodes=json.loads((MECH/'shocks/guided_spring_module_local_C04_R08_anchors.json').read_text())['nodes'];side=cs['side'];fore=cs['fore'];U=np.array([1350*fore+cs['offset'],side*560.,170.]);A=np.array([1350*fore,side*550.,-270.]);D0=np.array([U[0],side*720.3,-367.5]);R=rx(math.radians(side*q));D=A+R@(D0-A);L=np.linalg.norm(D-U);Z=(D-U)/L;X=np.array([side,0,0]);B=np.column_stack([X,np.cross(Z,X),Z]);fixed=np.diag([side,side,1]);out=[]
 for n in nodes:
  g=n['motion_group']
  if g=='spring_deformable':
   # Filled conservative OD110 cylinder, strictly larger than helical visual.
   s=cq.Solid.makeCylinder(55,L-225);out.append((n['node']+'_filled_OD110_reservation',tf(s,B,U+B@np.array([0,0,170]))));continue
  s=cq.Shape.importBrep(str(MECH/'shocks/parts'/(n['part']+'.brep')))
  if g.startswith('upper_'):basis=fixed;pos=U+fixed@np.array([n['origin_mm'][0],0,0])
  elif g.startswith('lower_'):basis=R@fixed;pos=D+fixed@np.array([n['origin_mm'][0],0,0])
  else:basis=B;pos=U if g=='shock_body'else D
  out.append((n['node'],tf(s,basis,pos)))
 return out

def build():
 parts=load_body();old={p['name']:p['shape']for p in parts};cs=corners();cuts=[]
 for c in cs:
  for p in parts:
   if not near(bb(p['shape']),bb(c['cutter'])):continue
   contact=p['shape'].intersect(c['shape']);cut=p['shape'].intersect(c['cutter']);v=cut.Volume()
   if v<=1e-4:continue
   s=p['shape'].cut(c['cutter']);row={'corner':c['name'],'part':p['name'],'tower_overlap_before_mm3':contact.Volume(),'actual_tower_intersection_bounds_mm':bb(contact)if contact.Volume()>1e-4 else None,'removed_volume_mm3':v,'removed_bounds_mm':bb(cut),'remaining_solid_count':len(s.Solids()),'valid':s.isValid(),'method':'Source tower planar silhouette, exact 3 mm round-join planar offset; Y507..525 or -525..-507 only. Applied to each named skin intersection.'};cuts.append(row);p['shape']=s;p['note']+=' SO01: local C04 tower skin opening with nominal 3 mm clearance; suspension tower remains frame-owned.'
   print('CUT',json.dumps(row),flush=True)
 for p in parts:assert p['shape'].isValid() and len(p['shape'].Solids())==1,(p['name'],p['shape'].isValid(),len(p['shape'].Solids()))
 return parts,old,cs,cuts

def save(parts,old,cs,cuts):
 changed=[p for p in parts if abs(p['shape'].Volume()-old[p['name']].Volume())>1e-4];ass=cq.Assembly(name='body_shock_openings_SO01')
 for p in changed:ass.add(p['shape'],name=p['name'],color=cq.Color(*b.MATS[p['material']]['color']))
 ass.export(str(P/'body_shock_opening_replacements_SO01.step'));b.export_glb(changed,P/'body_shock_opening_replacements_SO01.glb')
 ass=cq.Assembly(name='body_power_shock_clearance_SO01')
 for p in parts:ass.add(p['shape'],name=p['name'],color=cq.Color(*b.MATS[p['material']]['color']))
 ass.export(str(P/'body_power_shock_clearance_SO01.step'));b.export_glb(parts,P/'body_power_shock_clearance_SO01.glb')
 sourcepaths=[PR/'body_power_panel_retained_PR01.step',PR/'retention_check.json',MECH/'kinematics_C04_R03.mjs',MECH/'shocks/guided_spring_module_local_C04_R08_anchors.json']+[Path(c['source'])for c in cs]
 manifest={'revision':REV,'status':'development geometry; checks separate','base_revision':'PR01 with 28 R02 electrical deck bores','integration_rule':'Apply named replacements AFTER PR01. Do not stack replacement skins over original skins. This package does not change the frozen PR01 source or nonrear157 delta; it is a separate superseding named skin patch. Coordinate deck replacement with electrical new-bore patch by applying its bores after this replacement. Battery well and electrical partition/trough are unchanged.','source_sha256':{str(p):sha(p)for p in sourcepaths},'changes':[{'action':'replace','name':p['name'],'old_volume_mm3':old[p['name']].Volume(),'new_volume_mm3':p['shape'].Volume(),'material':p['material'],'group':p['group'],'reason':p['note']}for p in changed],'skin_intersections':cuts,'corners':[{'name':c['name'],'source':c['source'],'polygon_xz_mm':c['polygon_xz_mm'],'nominal_clearance_mm':CLEAR,'cutter_bounds_mm':bb(c['cutter'])}for c in cs],'parts':[{'name':p['name'],'volume_mm3':p['shape'].Volume(),'bounds_mm':bb(p['shape']),'valid':p['shape'].isValid(),'solid_count':len(p['shape'].Solids()),'material':p['material'],'group':p['group']}for p in parts],'scope_limits':['No suspension load transfer into body.','Weather sealing, edge reinforcement/strength, fatigue, stress concentration, manufacturing tolerances and frame deflection remain unqualified.','Finite travel samples are not continuous-motion certification.','Original profile and original engineering geometry only; no vendor geometry.'],'outputs':{n:sha(P/n)for n in ['body_shock_opening_replacements_SO01.step','body_shock_opening_replacements_SO01.glb','body_power_shock_clearance_SO01.step','body_power_shock_clearance_SO01.glb']}}
 (P/'replacement_manifest_SO01.json').write_text(json.dumps(manifest,indent=2)+'\n');print('EXPORTED',len(changed),flush=True)

if __name__=='__main__':save(*build())
