# SO02_E04P: C04 body openings, retained cover and electrical partition passages

Original development geometry. No fabrication, structural, weather-sealing or operational release.

## Select this package

Use `body_shock_partition_replacements_SO02_E04P.step` and `.glb`. This is the final **20-part named replacement package**, including the combined 40-hole deck and both electrical partition revisions. STEP units are millimetres; GLB units are metres, Z up.

Use `SELECTED_PACKAGE.json` and `partition_trough_check_SO02_E04P.json` for final replacement names and hashes. `combined_deck_manifest_SO02_E04.json` documents the unchanged 40-hole deck; `replacement_manifest_SO02.json` documents the openings and service cover. Apply these replacements after PR01. Do not layer old skins, the SO01 package, or the SO02-only 28-hole deck beneath them. The package replaces the two partitions only by applying the electrical owner’s exact cutter contract. It does not replace battery-well geometry or the separately supplied 19-part electrical trough/gland assembly. Apply that electrical delta separately, following its remove/replace/add list. The previous 18-part SO02_E04 package is superseded.

`body_deck_SO02_E04_40holes.step` and `.glb` are the same selected deck as a one-part package. The deck contains all 28 original R02 electrical bores plus the 12 E04 switchgear bores frozen by the electrical owner. Every Ø6.6 bore is checked for an empty cylinder, a coaxial circular face and an intact 1 mm surrounding annulus. The deck operation removes exactly twelve full 3 mm-thick bore cylinders from the SO02 deck. No tower-clearance material is added back.

`body_power_shock_clearance_SO02.step` and `.glb` are the 267-part, 28-hole reference body used for standalone body checks. They are not the selected assembled-vehicle package and must not overwrite the concurrent electrical or battery revisions.

## Original profile openings

Per-corner openings follow the original tower's six-edge X/Z silhouette with a 3 mm round-joined offset. Cutters occupy only Y507…525 or Y−525…−507 and remove only actual named skin intersections. The front/rear towers are already handed and receive X±1350 translation only. Middle right uses proper Rz180. The final checks use complete R13 towers, including their new root gussets below Z70, plus the unchanged R08 guided modules and R03 motion convention.

The body side sheets, decks, bulkhead and nose remain connected single solids. The suspension tower remains clamp/frame owned. No suspension load path into the body skins is introduced.

The full clamp/body assembly retains some pre-existing **2 mm** gaps at inherited Z130/132 reliefs. The new tower-profile edge clearance is 3 mm; a global 3 mm minimum is not claimed. Existing-gap closest-point evidence is in `minimum_clearance_details_SO01.json`; those skin regions are unchanged by SO02.

## Right-middle cover revision

SO01's installed fit, fastener retention and 20–40 mm outward unseating passed. An extended test found the upper carrier stays caught the cover during an 80–100 mm straight pull. That rejected extraction test is preserved in `cover_service_intersections_SO01.json`.

SO02 widens only the removable cover's service opening to X291…409. This comes from the actual original carrier stay centers at X350±48 and their 8 mm radius, plus 3 mm nominal side clearance. The opening has 3 mm rounded top corners and reaches Z203. The cover stays one solid with a 12 mm minimum top header.

The two left retained M6 stacks move from X283 to **X279**; Z164/204 and normal direction remain unchanged. The two right stacks stay at X497. The new left bores have 12 mm center-to-edge distance to both the cover's outer side and its service opening. Each relocated stack includes the original backing clip, tapped boss, screw and washer. The cover's old holes are replaced with new coaxial bores; no loose heads or empty old mounting points remain. Nominal M6x20 grip and cylindrical thread contact are rechecked against the new geometry.

The test samples a straight outward cover pull from 0 to 200 mm in 5 mm increments at q−12/0/+12. The four Ø12×60 mm axial tool corridors are checked against the actual tower and module. Stored suspension energy and vehicle support still require a safe service procedure; this geometry does not establish one.

## Electrical partition extension

The electrical owner’s stable, hash-pinned E04 candidate supplies two 64×42 mm aligned trunk slots at Y515/Z273, one in each partition, plus two Ø20.2 mm gland bores at Y366.5/443.5 and Z182.25 in the controller/battery partition. Only these exact cutters are applied; all other sheet geometry is preserved. The 2-part standalone export is `body_partition_openings_SO02_E04P.step` and `.glb`.

The 19 original trough/gland solids were screened against the six R13 towers and all 24 R08 module nodes at 78 suspension poses: 35,682 pairs were provably separated by exact B-rep bounds, with a minimum conservative gap of 23 mm. No Boolean fallback was needed. Both gland seats, both bore-support annuli and all 18 declared electrical weld contacts passed. These results are tied to STEP SHA256 98f1584c0d7d2a4e48c26c6215782e8ba7e95a23107b59b08ae8780d620df770. After the successful screen, the electrical owner froze this geometry and linked the report. The exact cutter and weld records and STEP hash were rechecked unchanged; only freeze metadata changed. Geometry freeze is not fabrication or electrical release approval.

## Check files

- `clearance_check_SO02.json`: complete R13 tower/module versus body screen, 78 suspension poses across q−12…+12 in 2-degree steps, retained cover tool/removal checks.
- `retention_check.json`: full nominal PR01 joint, weld, body/frame contact, tool and unseating replay against SO02. The report's inherited revision label is PR01 because its checker describes the retained connection system; the inputs are the SO02 exported body.
- `combined_deck_manifest_SO02_E04.json`: all 40 holes and strictly subtractive 12-hole deck composition.
- `delivery_roundtrip_SO02_E04P.json`: final named 20-part STEP/GLB identity, volume, bounds and valid-solid roundtrip.
- `partition_trough_check_SO02_E04P.json`: pinned electrical candidate motion screen, exact partition removals, gland seats and weld fits.
- Four `*_SO02.png` files: actual delivered STEP exterior and section closeups, drawn as scientific triangle plots, not Blender renders.

The motion screen checks all 24 module nodes, using a filled OD110 spring reservation rather than trusting the approximate helix. Positive q means jounce on both sides; lower pin hardware follows Rx(side*q), not damper-axis tilt. Bounding-box-separated pairs are excluded conservatively; candidate pairs use actual B-rep intersection.

## Open qualification gates

A connected sheet and contact-correct fastener stack do not prove strength. The narrow cover header, sheet edge stresses, clip welds, fastener grade/preload/locking, manufacturing tolerances, frame deflection and fatigue remain unqualified. The existing finger opening and tower openings are not weather-sealed. Continuous motion, collision-free manipulation between every sample, full-vehicle service/tool access and all current electrical/battery replacements still require integrated review.

## Rebuild order

Using CadQuery 2.7 and the referenced frozen PR01/C04 sources:

1. `build_shock_openings_SO01.py` reconstructs the local profile openings.
2. `build_shock_openings_SO02.py` creates the revised cover and relocated retained stacks.
3. `check_shock_openings_SO02.py` checks installed geometry and sampled service motion.
4. `compose_deck_SO02_E04.py` applies the frozen 12-hole electrical contract.
5. `verify_delivery_SO02_E04.py` checks the selected named STEP/GLB package.
6. `preview_shock_openings_SO02.py` draws exact exported-geometry closeups.
7. `compose_partition_and_check_trough_SO02_E04P.py` applies the exact partition cutters and screens the electrical owner’s pinned original assembly.
8. `verify_delivery_SO02_E04P.py` verifies the final 20-part package.

Frozen input directories and electrical-owned files are read only. All outputs are confined to this directory. No supplier CAD is incorporated and no vendor geometry is published.
