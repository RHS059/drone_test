import json
from OCP.BRepExtrema import BRepExtrema_DistShapeShape
import build_shock_openings_SO01 as g
import check_shock_openings_SO01 as v
m,ps=v.read_export();ps={p['name']:p['shape']for p in ps};cs={c['name']:c for c in g.corners()};j=json.loads((g.P/'clearance_check_SO01.json').read_text());out=[]
for r in j['rows']:
 if r['component']!='R13_stationary_tower' or r['minimum_distance_mm']>=2.999:continue
 c=cs[r['corner']];d=BRepExtrema_DistShapeShape(c['shape'].wrapped,ps[r['body_part']].wrapped);d.Perform();pairs=[]
 for k in range(1,d.NbSolution()+1):
  a=d.PointOnShape1(k);b=d.PointOnShape2(k);pairs.append({'tower_point_mm':[a.X(),a.Y(),a.Z()],'body_point_mm':[b.X(),b.Y(),b.Z()]})
 out.append({**r,'closest_points':pairs})
(g.P/'minimum_clearance_details_SO01.json').write_text(json.dumps({'scope':'Minimum clearance of full R13 clamp versus body can be below the new3 mm tower-profile offset because existing clamp reliefs are retained. Exact closest-point evidence.','rows':out},indent=2)+'\n');print(json.dumps(out,indent=2))
