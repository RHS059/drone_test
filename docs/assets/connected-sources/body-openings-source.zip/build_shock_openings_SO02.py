"""SO02: serviceable right-middle cover with two relocated retained M6 stacks.
Builds on original SO01 tower cuts; no mechanical component changes.
"""
import json,math
import cadquery as cq
import build_shock_openings_SO01 as g
import check_shock_openings_SO01 as v
P=g.P

def build():
 m,parts=v.read_export();base={p['name']:p for p in g.load_body()};named={p['name']:p for p in parts};cover='right_side_service_cover_2';points=[(279,164),(279,204),(497,164),(497,204)]
 s=g.b.box(246,3,62,(390,-514.5,184));s=g.b.holes(s,points,3.3,axis='Y',start=-600,length=1200);s=s.cut(g.b.box(76,10,12,(390,-514.5,190)))
 # The original upper-carrier stays are centred at local X±48, radius8,
 # hence globalX294..406 at middle-right. Allow3 mm either side for axial withdrawal.
 # Only this removable cover receives this service-slot relief.
 profile=cq.Workplane('XZ',origin=(350,-506,128)).rect(118,150).extrude(20).edges('|Y').fillet(3).val()
 c=next(c for c in g.corners()if c['name']=='middle_right');s=s.cut(c['cutter']).cut(profile)
 assert s.isValid()and len(s.Solids())==1
 named[cover]['shape']=s;named[cover]['note']='SO02 original removable cover: tower clearance plus3 mm-clear upper-carrier stay service slotX291..409; header retained toZ215, minimum12 mm. Left screw axes relocatedX283→279, retaining4 M6 fasteners.'
 for k in [1,2]:
  stem=f'right_service_nutclip_2_{k}'
  for suffix in ['', '_tapped_boss','_M6x20','_washer']:
   n=stem+suffix;named[n]['shape']=base[n]['shape'].translate((-4,0,0));named[n]['note']='SO02 entire original retainedM6 stack translated4 mm toward−X toX279; matching cover/clip/tapped-boss bores retained. No floating hardware.'
 changes=[p for p in parts if abs(p['shape'].Volume()-base[p['name']]['shape'].Volume())>1e-4 or p['name'].startswith(('right_service_nutclip_2_1','right_service_nutclip_2_2'))]
 assert len(changes)==18
 for p in parts:assert p['shape'].isValid()and len(p['shape'].Solids())==1
 for stem,pp in [('body_power_shock_clearance_SO02',parts),('body_shock_opening_replacements_SO02',changes)]:
  a=cq.Assembly(name=stem)
  for p in pp:a.add(p['shape'],name=p['name'],color=cq.Color(*g.b.MATS[p['material']]['color']))
  a.export(str(P/(stem+'.step')));g.b.export_glb(pp,P/(stem+'.glb'))
 out={**m,'revision':'SO02','supersedes':'SO01; service80 mm pull contact rejected, fixed with localcoverrelief and retainedstackrelayout','integration_rule':'Replace18 named PR01 parts; preferably use final SO02_E04 composed package with40-holedeck. Do not layer SO01 replacements or old X283 left screw hardware. No battery/electrical trough or partition parts changed.','changes':[{'action':'replace','name':p['name'],'old_volume_mm3':base[p['name']]['shape'].Volume(),'new_volume_mm3':p['shape'].Volume(),'material':p['material'],'group':p['group'],'reason':p['note']}for p in changes],'parts':[{'name':p['name'],'volume_mm3':p['shape'].Volume(),'bounds_mm':g.bb(p['shape']),'valid':p['shape'].isValid(),'solid_count':len(p['shape'].Solids()),'material':p['material'],'group':p['group']}for p in parts],'cover_service_slot':{'part':cover,'source_member':'Original guided_upper_carrier_C04_R07 stays: localX±48, radius8','source_stay_global_X_bounds_mm':[294,406],'service_slot_X_bounds_mm':[291,409],'slot_top_mm':203,'top_corner_radius_mm':3,'remaining_header_min_mm':12,'left_screw_axis_before_X_mm':283,'left_screw_axis_after_X_mm':279,'left_hole_edge_distance_to_side_and_notch_mm':[12,12],'qualification':'Nominal geometry only; narrow-header and edge strength, sealing and tolerances unqualified.'},'retention_axis_overrides':[{'joint':f'right_service_nutclip_2_{k}_M6x20','axis_C_mm':[279,-513,z]}for k,z in [(1,164),(2,204)]],'outputs':{n:g.sha(P/n)for n in ['body_power_shock_clearance_SO02.step','body_power_shock_clearance_SO02.glb','body_shock_opening_replacements_SO02.step','body_shock_opening_replacements_SO02.glb']}}
 out['preceding_SO01_skin_intersections']=out.pop('skin_intersections')
 out['skin_intersections']=[r for r in out['preceding_SO01_skin_intersections']if r['part']not in [cover,'right_service_nutclip_2_1','right_service_nutclip_2_2']]
 out['cover_service_revision_evidence']='cover_service_intersections_SO01.json records rejected80–100 mm pull collisions. SO02 rebuilds cover and translates complete left stacks; oldclipedgecuts are superseded.'
 out['source_sha256'].update({str(P/f):g.sha(P/f)for f in ['build_shock_openings_SO01.py','build_shock_openings_SO02.py','replacement_manifest_SO01.json']});(P/'replacement_manifest_SO02.json').write_text(json.dumps(out,indent=2)+'\n');print('EXPORTED SO02',len(changes),flush=True)
if __name__=='__main__':build()
