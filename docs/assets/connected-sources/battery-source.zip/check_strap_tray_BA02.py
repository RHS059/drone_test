"""BA01 assembly checks against frozen PR01 and R07. Never imports vendor CAD."""
from pathlib import Path
import cadquery as cq,numpy as np,json,struct,hashlib
P=Path(__file__).parent;O=P/'BA02';B=P.parent/'body-power'
def read(step,glb):
 blob=glb.read_bytes();nl=struct.unpack_from('<I',blob,12)[0];doc=json.loads(blob[20:20+nl]);solids=cq.importers.importStep(str(step)).val().Solids();names=[n['name'] for n in doc['nodes']];assert len(solids)==len(names);return dict(zip(names,solids))
def bb(s):
 z=s.BoundingBox();return np.array([z.xmin,z.ymin,z.zmin,z.xmax,z.ymax,z.zmax])
def intersect(a,b):
 x,y=bb(a),bb(b)
 if np.any(x[:3]>y[3:]+1e-6) or np.any(y[:3]>x[3:]+1e-6):return 0.
 return a.intersect(b).Volume()
new=read(O/'battery_strap_tray_BA02.step',O/'battery_strap_tray_BA02.glb');base=read(B/'panel-retention/body_power_panel_retained_PR01.step',B/'panel-retention/body_power_panel_retained_PR01.glb');m=json.loads((O/'replacement_addition_manifest.json').read_text());retained={n:s for n,s in base.items() if n not in m['remove_names'] and n not in m['replace_names']};frame_path=next(q for q in [P.parent/'mechanical/frame_R07.step',P.parent/'app/docs/assets/mechanical/frame_R07.step'] if q.exists());frame=cq.importers.importStep(str(frame_path)).val().Solids();print('Imported',len(new),'new',len(retained),'retained',flush=True)
hits=[];contacts=[];nl=list(new)
for i,n in enumerate(nl):
 for k in nl[i+1:]:
  a,c=new[n],new[k];v=intersect(a,c)
  if v>1e-3:hits.append({'a':n,'b':k,'volume_mm3':v})
  elif not(np.any(bb(a)[:3]>bb(c)[3:]+1e-5) or np.any(bb(c)[:3]>bb(a)[3:]+1e-5)) and a.distance(c)<1e-5:contacts.append([n,k])
 print('new part',i,'hits',len(hits),flush=True) if i%20==0 else None
bodyhits=[];framehits=[]
for n,s in new.items():
 for k,c in retained.items():
  v=intersect(s,c)
  if v>1e-3:bodyhits.append({'a':n,'b':k,'volume_mm3':v})
 for j,c in enumerate(frame):
  v=intersect(s,c)
  if v>1e-3:framehits.append({'a':n,'frame_solid':j,'volume_mm3':v})
print('Static checked',flush=True)
# Connectivity uses intentional zero-gap interfaces and nominal cylindrical threads.
adj={n:set() for n in new}
for a,c in contacts:adj[a].add(c);adj[c].add(a)
seen={'battery_well_floor_3mm'};q=list(seen)
while q:
 for n in adj[q.pop()]-seen:seen.add(n);q.append(n)
# Tools ascend all the way through installed fixed opening, lid/fasteners removed.
removed_hatch={n for n in retained if n.startswith('battery_hatch_') and ('_M6_' in n or 'removable_lid' in n or 'gasket' in n or '_washer_' in n)}
service={n:s for n,s in retained.items() if n not in removed_hatch};toolhits=[]
for j in m['joints']:
 x,y,_=j['axis_C_mm'];z=j['underhead_z_mm']+8
 tool=cq.Workplane('XY').circle(j['head_tool_diameter_mm']/2).extrude(450-z).translate((x,y,z)).val()
 for n,s in service.items():
  v=intersect(tool,s)
  if v>1e-3:toolhits.append({'joint':j['id'],'obstacle':n,'volume_mm3':v})
 for n,s in new.items():
  if n.startswith(j['id']):continue
  v=intersect(tool,s)
  if v>1e-3:toolhits.append({'joint':j['id'],'obstacle':n,'volume_mm3':v})
# Rigid pack first lifts16mm with1mm centering allowance, then10mm allowance.
# Both straps and buckle reservations removed; all carrier hardware stays installed.
lifthits=[]
fixed_new={n:ob for n,ob in new.items() if not('original_external_interface' in n or '_M8_interface' in n or '_vent_INTERFACE' in n or '_webbing_route' in n or '_purchased_buckle_' in n)}
for i,cx in enumerate([-975,-625],1):
 for stage,allow,lo,hi in [('guided_initial_16mm',1,-69,185.6),('expanded_after_16mm',10,-53,700)]:
  sweep=cq.Workplane('XY').box(161.5+2*allow,647.6+2*allow,hi-lo,centered=(True,True,False)).translate((cx,0,lo)).val()
  for n,ob in list(service.items())+list(fixed_new.items()):
   v=intersect(sweep,ob)
   if v>1e-3:lifthits.append({'pack':i,'stage':stage,'obstacle':n,'volume_mm3':v})
  for j,ob in enumerate(frame):
   v=intersect(sweep,ob)
   if v>1e-3:lifthits.append({'pack':i,'stage':stage,'frame_solid':j,'volume_mm3':v})
# Actual geometry-to-geometry strap separation from terminal and vent reservations.
interface_clearances=[]
for n,ob in new.items():
 if '_webbing_route' not in n:continue
 i=n.split('_')[2]
 for k,other in new.items():
  if k.startswith('BA02_pack_'+i) and ('_M8_interface' in k or '_vent_INTERFACE' in k):
   interface_clearances.append({'strap':n,'interface':k,'distance_mm':ob.distance(other),'overlap_mm3':intersect(ob,other)})
# Preservation proof: deck unchanged byte-independent B-rep volume andhole check28.
patch=json.loads((B/'R02/body_attachment_patch.json').read_text());deck=retained['main_base_deck_3mm'];hchecks=[]
for h in patch['holes']:
 x,y,_=[a*1000 for a in h['axis_C_m']];c=cq.Workplane('XY').circle(3.299).extrude(3).translate((x,y,100)).val();hchecks.append({'id':h['id'],'remaining_material_mm3':intersect(deck,c)})
result={'revision':'BA02','scope':'Nominal static original CAD only. Not load, thermal, waterproof, shock, manufacturing or lifting qualification.','candidate_parts':len(new),'all_valid_single_solids':all(s.isValid() and len(s.Solids())==1 for s in new.values()),'internal_positive_volume_intersections':hits,'retained_body_intersections':bodyhits,'frame_intersections':framehits,'zero_gap_contact_edges':contacts,'unconnected_new_parts':sorted(set(new)-seen),'retained_floor_root':'battery_well_floor_3mm','strap_to_interface_clearances':interface_clearances,'axial_tool_path_hits':toolhits,'expanded_vertical_lift_hits':lifthits,'nominal_tool_hatch_side_clearance_mm':46,'nominal_pack_hatch_side_clearance_mm':16.2,'expanded_pack_hatch_side_clearance_mm':6.2,'well_side_ventilation_space_mm':33.2,'well_end_space_mm':67.25,'interpack_gap_mm':188.5,'R02_deck_holes_checked':hchecks,'original_history_modified':False,'gates':{'strap_case_interface':'Victron permits straps. This is an original engaged route only; no case preload, bearing-zone approval, webbing thickness, edge protection or buckle geometry qualification. Factory-bracket failures remain in BA01.','dry_indoor_location':'FAIL for existing unsealed hatch/finger slots and apertures; dry, ventilated enclosure not qualified.','thermal':'Case-to-wall clearance exceeds 20 mm; local mounting hardware occupies part of the lower ventilation region; heat rejection/condensation/water exclusion not verified.','lifting':'Only rigid-pack extraction volume checked. Each 37 kg pack requires suitable human-assisted handling/hoist and validated sling/handle/access procedure; arms-only unsupported.','loads':'Carrier/floor, welded holders, tray and strap anchorage allowable load, torque, shock and fatigue remain unknown.','electrical':'Separate 180 A two-pack topology review; sharing, branch protection, disconnects and conductor heating remain open.'}}
result['vehicle_restraint_qualified']=False
result['buckle_internal_mechanism_modeled']=False
result['contact_graph_scope']='Nominal geometry connectivity through approximate purchased buckle interfaces. Does not prove cam locking, grip force, sewn termination or complete modeled retention mechanism.'
result['R02_deck_holes_preserved']=len(hchecks)==28 and all(h['remaining_material_mm3']<1e-6 for h in hchecks)
result['outputs_sha256']={n:hashlib.sha256((O/n).read_bytes()).hexdigest() for n in ['battery_strap_tray_BA02.step','battery_strap_tray_BA02.glb','replacement_addition_manifest.json']}
result['nominal_geometry_pass']=result['R02_deck_holes_preserved'] and not(hits or bodyhits or framehits or toolhits or lifthits or result['unconnected_new_parts'])
(O/'verification.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k not in ['zero_gap_contact_edges','R02_deck_holes_checked']},indent=2))
