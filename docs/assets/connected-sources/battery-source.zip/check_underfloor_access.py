from pathlib import Path
import cadquery as cq,json,numpy as np
P=Path(__file__).parent;O=P/'BA01'
s=cq.importers.importStep(str(P.parent/'app/docs/assets/mechanical/frame_R07.step')).val();report={'scope':'Straight underfloor M8 nut socket access to R07 frame only; no ground/skid/hoist qualification','tool_diameter_mm':20,'tool_depth_mm':80,'hits':[]}
def bb(s):
 b=s.BoundingBox();return np.array([b.xmin,b.ymin,b.zmin,b.xmax,b.ymax,b.zmax])
for cx in [-975,-625]:
 for dx in [-94,94]:
  for y in [-285,285]:
   x=cx+dx;t=cq.Workplane('XY').circle(10).extrude(80).translate((x,y,-168.1)).val()
   for i,f in enumerate(s.Solids()):
    a,b=bb(t),bb(f)
    if np.any(a[:3]>b[3:]) or np.any(b[:3]>a[3:]):continue
    v=t.intersect(f).Volume()
    if v>1e-3:report['hits'].append({'axis_mm':[x,y],'frame_solid':i,'volume_mm3':v})
report['pass']=not report['hits'];(O/'underfloor_tool_check.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
