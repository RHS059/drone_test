# BA02: strap-captured, bolted battery trays

BA02 is the preferred connection-development route after the rigid factory-bracket fit screen in BA01 remained unresolved. It shows a continuous physical attachment path without claiming outdoor, structural or battery-case load qualification. It is an original CAD model; no vendor geometry, derived vendor mesh, logos or textures are included.

## Complete attachment path

Each 37 kg pack rests in an original 210 × 704 × 12 mm aluminium tray. The tray has a 4 mm-deep pocket with 2 mm nominal horizontal clearance around the battery's overall footprint. Four M8 × 30 screws pass through actual Ø8.8 tray/floor bores, with top and bottom washers and separate nuts. The nuts have 6.5 mm nominal engagement and 5.3 mm tip protrusion. Matching cylindrical thread equivalents model connection; they are not manufacturing tap-drill dimensions or qualified thread flanks.

Two 25.4 mm-wide commercial strap routes per pack run at Y ±150 mm. They wrap around both the battery and the tray. Their lower legs pass through 27.4 mm-wide, 3 mm-high machined passages in the tray underside, bearing on the passage roofs. The straps therefore capture the bolted tray; they are not loose bands wrapped around only the battery. Passage roofs retain at least 5 mm of aluminium. Webbing thickness is provisionally 2 mm, with 1 mm channel-height clearance and 1 mm width clearance per side. Real webbing, edge radii, protective sleeves and threading access require verification.

The four webbing routes deliberately stop across a 40 mm upper closure gap. Four approximate external purchased-buckle depictions bridge those locations through nominal interface contacts. The purchased NRS complete assembly provides closure; its cam, springs, teeth, sewn termination, free tail and actual gripping/release mechanics are omitted. A contact graph proves spatial connection only and does not establish a complete modeled latch or its holding capacity. The opaque 60 × 35 × 7 mm external buckle depictions have assumed dimensions and a nominal webbing-interface slot; they are not original custom buckle designs, vendor geometry, manufacturing data or modeled cam mechanisms. The separate translucent 60 × 35 × 18 mm volumes are nonphysical service reservations. Do not use those reservation dimensions to manufacture a buckle or assert exact catalog fit.

## Sourced strap candidate

NRS 1-inch HD Tie-Down Straps, 4-foot pair, Stealth Black, manufacturer catalogue SKU 60027.01.112; two retail pairs give four straps total. The SKU is confirmed in the 2025 NRS Rescue Book. The current page displays the same size/color options, but its retrieved text does not expose the selected-variant price. Do not use another length's price or count a retail pair as one strap. The current manufacturer's page lists 25.4 mm width, 1,219.2 mm length, 500 lb working load limit and 1,500 lb minimum breaking strength for the strap assembly, with polypropylene webbing. A geometric loop is approximately 828 mm long; the exact generated report includes its length and remaining allowance for the closure and secured tail.

These are tie-down ratings, not a vehicle crash rating, a battery casing load rating or permission to hoist a battery. Do not use the straps as lifting slings. No pretension force is assigned and no arbitrary battery casing pressure limit is invented. The actual cam assembly, label, threading and secured tail must be checked. There is no purchase or availability commitment.

Victron explicitly permits optional strap mounting in the Introduction, section 2.2. That permission supports the mounting method; it does not supply an allowable case preload, load distribution, shock rating or detailed strap bearing zone for this tray.

## Pack datums and interfaces

Pack centers are X −975 / −625 mm, Y 0. Tray seat and battery bottom are Z −69 mm, 4 mm above BA01. The measured cover-plane reference is approximately 221.8 mm above the bottom, at Z 152.8. Conservative terminal reservations extend to Z 169.6 because the supplied STEP's 238.596 mm overall height conflicts with the 234.7 mm drawing.

Original terminal axes are X = pack center −54.05 mm and Y ±275.25 mm. The central top fitting/vent reservation is at X = pack center −44.25 mm, Y −52.5 mm, nominal Ø24 × 11 mm. The strap bands avoid those physical footprints. Computed edge-to-edge separations are geometric results only, not manufacturer-approved electrical clearances or vent keep-out distances. The original case footprint and simplified ledges do not reproduce moulded corner detail.

The carry-handle attachment areas are at the pack ends, remote from the chosen strap bands, but folded rope handles, BMS leads, cable lugs and terminal covers are not completely defined by the supplied solids. Secure their real routing and retain access to labels and closures. No hand-access or rigging claim follows from their absence in CAD.

## Removal and assembly limits

Open the hatch, isolate and prove the battery circuit safe, disconnect and secure cables, then release and clear both straps. The tray and its four bolts remain installed. The first 16 mm of vertical lift is checked with only a 1 mm centering allowance, reflecting the shallow pocket and nearby retained hardware. After clearing that hardware, a ±10 mm horizontal allowance is checked. This is a rigid-body obstruction test, not a validated handling method.

Each pack weighs 37 kg. Suitable human-assisted handling equipment and a validated sling/handle procedure remain required. Robot-arm-only lifting and hoisting by electrical terminals or BMS cables are not supported. The modeled buckle reservations are approximately 164 mm below the open hatch plane; actual gloved access, release motion and tail threading require a prototype demonstration.

## Integration

Use `replacement_addition_manifest.json` as a named patch onto PR01 or a later integrated body. Replace the well floor, remove the old RELiON pads/stops/crossbars/rods/nuts/washers and four battery envelopes, then add BA02. Preserve all other PR01 parts and all 28 R02 electrical deck holes. Never layer BA02 over BA01 factory brackets or old restraints. The new floor adds eight M8 bores only; the four inherited unused floor holes remain and need a sealed closure detail.

Exported assembly STEP is millimetres; GLB is metres, Z up. Battery and webbing solids are dimensional/interface models, not calibrated mass solids. Battery mass is 74 kg total, supplied separately. Buckle reservations have separate exports and must remain marked nonphysical.

## Remaining engineering limits

- The existing unsealed hatch/finger slots and apertures do not meet a dry indoor installation. A weatherproof, ventilated vehicle enclosure, condensation control and heat rejection remain open.
- Nominal case-to-well side space is 33.2 mm, above the manual's 20 mm, with 188.5 mm between packs. Local straps, tray margins and other hardware mean a full airflow path is not qualified.
- Tray/floor bending, weld load transfer, bolt grade/locking/preload, fatigue, vibration, impact and corrosion are not qualified.
- Strap tension, battery cover/edge bearing, abrasion protection, webbing thickness, temperature/chemical suitability and actual buckle envelope remain unverified. The sourced strap WLL does not resolve them.
- The separate electrical design owns BMS, fuses, disconnects, conductors, equal current sharing and 180 A enforcement. Cable and lug geometry must use the raised BA02 datum.
- BA01's factory-CAD interference evidence is preserved; strap mounting does not erase that failed rigid-fit screen.

## Primary sources, checked 2026-10-09

- Victron explicitly allows straps: https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/introduction.html
- Victron dry installation, ventilation and safe handling: https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/installation.html
- Victron ratings and mass: https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/technical-data.html
- Battery dimensions: https://www.victronenergy.com/upload/documents/LiFePO4-Battery-51.2V100Ah-NG.pdf
- Current NRS product and whole-assembly WLL: https://www.nrs.com/rescue/nrs-1-hd-tie-down-straps/p4yc

Catalogue SKU evidence: https://dh36nblqpps8a.cloudfront.net/assets/downloads/workbooks/2025_NRS_Rescue_Book.pdf . Current product page shows a $12.95–$43.95 family price range; exact 4-foot pair price is unverified and must remain absent from a firm unit-price rollup. Original metal hardware mass is in the manifest; commercial strap/buckle mass remains unknown and the two batteries contribute 74 kg separately.

## Reproduce and freeze

Place this directory beside the original `body-power` inputs in the reconstruction repository. With the pinned CadQuery environment, run:

    python build_strap_tray_BA02.py
    python check_strap_tray_BA02.py
    python preview_strap_tray_BA02.py
    python classify_BA02_geometry.py

The classification pass changes only JSON labels and verifies that each GLB geometry buffer is unchanged. The checks read frozen PR01 and R02 and the original R07 frame. They do not edit those inputs. `verification.json` records the tested assembly hashes and bounded results. `CHECKPOINT.json` freezes the ready-to-integrate geometry. Original metal mass uses assumed 2,700 kg/m³ aluminium and 7,850 kg/m³ steel densities.
