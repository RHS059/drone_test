# Battery alternatives: current strap-tray release and factory-bracket record

The ready-to-integrate connection-development candidate is BA02. Read BA02/README.md and its named replacement/removal manifest. It uses a purchased complete cam-strap assembly boundary with approximate external buckle geometry; no original custom buckle inherits its rating. BA01 below preserves the failed rigid factory-bracket study and must not be combined with BA02.

# BA01: two-pack Victron mounting candidate

This is a bounded packaging and attachment study, not a selected or qualified vehicle battery system. The existing unsealed vehicle body does not satisfy the manufacturer's dry, indoor installation requirement. No vendor geometry, derived vendor mesh, logos or product textures are in the deliverable. Do not distribute the separate `review-only` directory.

## What is factual, and what is original

Candidate: two Victron BAT548110620 Lithium NG 51.2 V / 100 Ah packs, connected in parallel only in the separate electrical proposal. Manufacturer estimated mass is 37 kg each, 74 kg total. The dimension drawing states 647.6 mm width, 161.5 mm depth, 234.7 mm overall height, 226.1 mm auxiliary height reference, M8 terminals 550.5 mm apart and 26.7 mm from one depth edge. The privately inspected STEP has 238.596 mm overall height including its bolt detail. This revision/datum conflict is unresolved; reserve the larger height.

The public bracket drawing gives 84.3 × 30.3 × 12.9 mm overall, 2 mm sheet, two 7 × 10 mm obround holes on 57 mm pitch and an 11.8 mm lip. Numerical inspection of the separate factory source puts its bolt foot 1 mm above the lowest bent end tabs and its lip underside 10.9 mm above the tabs. The bottom battery ledge is a 5° ramp: approximately 10 mm above the support datum at its root and 8.924 mm at its tip. The exact source corner footprint is wider than the deliberately simplified original proxy. A rigid flat-floor placement therefore does not demonstrate clamping: the lip stands at least about 0.9 mm above the sloping ledge before bracket deformation, while the real bracket end tabs interfere with the real case corners. Factory torque, permissible deflection, contact force, tolerances and vehicle shock load rating were not established.

The original external battery model is deliberately simple: a rectangular conservative body, two functional bottom ledges with a 5° sloped upper surface and simple M8 terminal interface cylinders. It is neither a reproduced moulding nor a mass model. The original bracket proxy is a square/faceted functional section dimensioned from the drawing, with vendor fillets and forming details omitted. Small geometric differences from the real product remain explicit. Exact manufacturer STEP is used only for private inspection, never imported by the original generator.

## Original carrier proposal

Each pack is centered at X −975 or −625 mm, Y 0, with its support datum at Z −73 mm. The battery well's actual clear dimensions are 644 × 714 mm. Pack-to-wall spaces are 67.25 mm at the longitudinal ends and 33.2 mm at the sides; the inter-pack gap is 188.5 mm. These nominal sides exceed the manufacturer's 20 mm requirement. They do not establish heat rejection or dry ventilation.

Actual private factory-source common-volume checks found 9.137 mm³ interference at a flat-floor tab datum and 9.609 mm³ at the proposed seated datum. Outward bracket shifts of 0.5 / 1.0 / 1.5 mm reduce interference to 3.353 / 0.427 / 0.018 mm³; none passes. No acceptable factory bracket fit or preload was established. The original simplified proxy can clear its own model despite this failure, and must not be used as a manufacturing fit proof.

Each original 210 × 704 × 5 mm carrier sits on the well floor at Z −77. A 1 mm-deep central seat locates the battery bottom at Z −73. Separate bracket-foot seats are at Z −72.9; local tab-relief pockets extend to Z −74. This places the original bracket proxy's lip underside at 10 mm above the battery bottom. It does NOT establish clamp contact with the sloping ledge; the battery is not claimed retained. The arrangement requires prototype dimensional verification against the actual purchased bracket and battery before machining.

Each bracket uses two M6 × 20 screws, washers, real Ø6.6 clearance bores and original 18 × 18 × 10 mm weld-on tapped blocks under the well floor. Nominal thread engagement is 9.3 mm. Each carrier additionally uses four through-floor M8 × 20 screws, top/bottom washers and M8 nuts with 6.5 mm nominal engagement. Thread interfaces use matching cylindrical contact equivalents; these are not manufacturing tap-drill or clearance-hole instructions. Fastener strength, torque, locking, corrosion isolation, weld size, floor bending and load transfer to the frame remain unqualified.

## Integration and preservation

`BA01/replacement_addition_manifest.json` is a candidate-only named patch. Remove the old RELiON pads, stops, crossbars, rods, nuts and washers; replace only `battery_well_floor_3mm`; add the new named candidate parts. Remove the four old external RELiON reservation objects separately. Do not layer new parts over old hardware. All other PR01 body-retention work is preserved. The 28 R02 electrical deck holes are unchanged and checked in the verification report. The original four unused well-floor holes remain and need a sealed closure detail.

## Service, lifting and open gates

- The hatch's fixed opening is 610 × 680 mm. A rigid pack fits vertically with 16.2 mm lateral clearance; a ±10 mm expanded pack sweep has only 6.2 mm lateral margin. This is an obstruction check, not a validated rigging procedure.
- The bracket screw axes at Y ±334.1 mm permit a nominal Ø10 mm straight driver path, leaving only 0.9 mm at the hatch edge. A real insulated extension, sockets, tolerances and hand access must be demonstrated. Remove and retrieve the brackets before lifting.
- Isolate, prove safe, disconnect and secure all power/BMS cables before battery handling. Hoisting by terminals or BMS cables is prohibited. Each 37 kg pack requires suitable human-assisted handling equipment; robot-arm-only service is unsupported. Carry handles, sling ratings, hoist headroom and extraction procedure remain to be validated.
- Existing finger slots, unsealed apertures and unqualified glands mean the dry-indoor installation gate is open. A weatherproof but ventilated vehicle enclosure needs a separate engineering solution, including condensation and heat rejection. IP65 battery marking does not waive the installation requirement.
- The separate electrical worker owns BMS, fuses, equal-current paths, conductors and the 180 A limited-power proposal. At 180 A ideal equal sharing is 90 A per pack, below the 100 A continuous rating, but actual unequal sharing, transient limits and protective enforcement are unresolved.
- This geometry does not qualify battery case ledge loads, retained bracket loads, carrier/floor strength, vehicle crash retention, off-road vibration, EMC, fire protection or environmental operation.

## Reproduce

Run `python build_battery_candidate.py` and `python check_battery_candidate.py` with CadQuery 2.7 and NumPy. `preview_battery_candidate.py` produces geometry evidence plots from the exported original triangles, with no Blender rendering. No script imports files under `review-only`.

## Primary sources, checked 2026-10-09

- Installation, ventilation, dry location, safe handling and terminals: https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/installation.html
- Ratings, estimated mass and included mounting brackets: https://www.victronenergy.com/media/pg/Lithium_NG_battery_51,2_V/en/technical-data.html
- Battery drawing: https://www.victronenergy.com/upload/documents/LiFePO4-Battery-51.2V100Ah-NG.pdf
- Bracket drawing: https://www.victronenergy.com/upload/documents/Bracket-for-Lithium-NG-Batteries.pdf

The privately inspected terminal top annulus is 238.595618 mm above the bottom (installed Z165.595618). This higher STEP reference remains subject to drawing/revision reconciliation. The original terminal cylinders reserve that height but do not model the factory contact recess or lug/washer/bolt stack.

The original bracket-to-floor hardware is connected; the battery ledge restraint remains unqualified. The clean primary evidence images are `bracket_M6_true_section.png` and `hatch_service_plan.png`; 3D triangle views are secondary orientation plots.
