"""Original BA02 tray/strap route. No vendor geometry, meshes or textures imported.
NRS1inch HD4ft strap assembly is a sourced tie-down candidate, not hoisting gear.
Only webbing width and rating/length are sourced;2mm thickness and buckle envelope
are explicit original fit assumptions. Pretension and allowable case bearing are unknown.
"""
from pathlib import Path
import cadquery as cq,numpy as np,json,sys,math,hashlib
P=Path(__file__).parent;B=P.parent/'body-power';sys.path.insert(0,str(B));import build_body_power as b
O=P/'BA02';PARTS=[];RES=[];JOINTS=[];BASE=-69.;COVER=BASE+221.8
b.MATS.update({'battery':{'density':0,'color':[.07,.35,.53,1]},'terminal':{'density':0,'color':[.65,.48,.20,1]},'strap':{'density':0,'color':[.91,.40,.09,1]},'carrier':{'density':2700,'color':[.11,.52,.52,1]},'buckle_proxy':{'density':0,'color':[.30,.33,.38,1]},'proxy':{'density':0,'color':[.89,.58,.12,.35]}})
def put(n,s,mat='carrier',group='battery_carrier',note=''):
 assert s.isValid() and len(s.Solids())==1,(n,s.isValid(),len(s.Solids()));PARTS.append({'name':n,'shape':s,'material':mat,'group':group,'note':note});return s

def band(cx,y):
 # One original closed routed loop captures tray underside and battery top.
 # Continuous route is the engaged-state functional equivalent, not woven material.
 inner=[(-105,-74),(105,-74),(105,-65),(80.75,COVER),(-80.75,COVER),(-105,-65)]
 outer=[(-107,-76),(107,-76),(107,-64.89),(82.54,COVER+2),(-82.54,COVER+2),(-107,-64.89)]
 a=cq.Workplane('XZ').polyline(outer).close().extrude(25.4).translate((cx,y+12.7,0)).val()
 q=cq.Workplane('XZ').polyline(inner).close().extrude(27.4).translate((cx,y+13.7,0)).val()
 # Omit40mm of the upper strand where purchased cam closure provides function.
 sh=a.cut(q).cut(b.box(40,27.4,6,(cx+10,y,COVER+1)))
 return sh,inner

def build():
 floor=b.plate(650,720,3,-80,-800);floor=b.holes(floor,[(x,y) for x in [-950,-650] for y in [-235,235]],4.4)
 rows=[]
 for i,cx in enumerate([-975,-625],1):
  case=b.box(161.5,623,221.8,(cx,0,BASE+110.9))
  for sg in [-1,1]:
   poly=[(sg*y,BASE+z) for y,z in [(311.5,0),(323.8,0),(323.8,8.9239),(311.5,10)]]
   case=case.fuse(cq.Workplane('YZ').polyline(poly).close().extrude(80).translate((cx-40,0,0)).val())
  put(f'BA02_pack_{i}_original_external_interface',case,'battery','battery_external_dimensional_proxy','Original simplified external dimensional model. Cover plane221.8mm and sloped bottom ledge from numeric inspection; actual corner moulding not reproduced. Pack37kg specified separately; not a solid mass model.')
  for sg,pol in [(-1,'positive'),(1,'negative')]:
   term=b.cyl(10,16.8,(cx-54.05,sg*275.25,COVER)).cut(b.cyl(4,19,(cx-54.05,sg*275.25,COVER-1)))
   put(f'BA02_pack_{i}_{pol}_M8_interface',term,'terminal','battery_terminal_reservations','M8/550.5pitch and26.7edge offset from drawing. Top169.6mm uses larger238.596mm source height. Contact recess/lug/bolt geometry unqualified; installed polarity is an orientation choice.')
  put(f'BA02_pack_{i}_central_vent_INTERFACE',b.cyl(12,11,(cx-44.25,-52.5,COVER)),'terminal','battery_vent_reservations','Original dimensional central top fitting reservation: drawing36.5mm depth edge offset and376.3mm width edge offset; nominal diameter24/height11 from private numeric inspection. No flow/clearance qualification.')
  carrier=b.plate(210,704,12,-77,cx)
  carrier=carrier.cut(b.plate(165.5,651.6,5,BASE,cx))
  # Four-mm-deep pocket gives2mm wall clearance around the overall pack envelope.
  # Two27.4mm-wide underside passages route25.4mm webbing under the bolted tray.
  for y in [-150,150]:carrier=carrier.cut(b.plate(214,27.4,3,-77,cx,y))
  for k,(dx,y) in enumerate([(dx,y) for dx in [-94,94] for y in [-285,285]],1):
   x=cx+dx;n=f'BA02_pack_{i}_tray_M8_{k}';carrier=carrier.cut(b.cyl(4.4,16,(x,y,-79)));floor=floor.cut(b.cyl(4.4,5,(x,y,-81)))
   w=b.cyl(8,1.6,(x,y,-65)).cut(b.cyl(4.2,4,(x,y,-66)));put(n+'_top_washer',w,'fastener','battery_fasteners','ISO7089 nominal M8 washer OD16/ID8.4/t1.6; grade unselected.')
   bolt=b.cyl(4,30,(x,y,-93.4)).fuse(b.cyl(6.5,8,(x,y,-63.4)));bolt=bolt.cut(cq.Workplane('XY').polygon(6,6/math.cos(math.pi/6)).extrude(4).translate((x,y,-59.4)).val());put(n+'_screw',bolt,'fastener','battery_fasteners','Original nominal M8x30 socket screw, AF6, smooth nominal thread equivalent; strength, locking and preload unselected.')
   w=b.cyl(8,1.6,(x,y,-81.6)).cut(b.cyl(4.2,4,(x,y,-82.6)));put(n+'_bottom_washer',w,'fastener','battery_fasteners','ISO7089 nominal M8 washer, against actual well floor underside.')
   nu=cq.Workplane('XY').polygon(6,13/math.cos(math.pi/6)).circle(4).extrude(6.5).translate((x,y,-88.1)).val();put(n+'_nut',nu,'fastener','battery_fasteners','ISO4032 nominal M8 nut AF13/t6.5, matching diameter8 thread-contact cylinder. Not a finished thread or tap-drill definition.')
   JOINTS.append({'id':n,'axis_C_mm':[x,y,0],'bolt':'M8x30','underhead_z_mm':-63.4,'tip_z_mm':-93.4,'nominal_nut_engagement_mm':6.5,'tip_protrusion_mm':5.3,'clearance_mm':8.8,'head_tool_diameter_mm':18,'underfloor_socket_diameter_mm':20})
  put(f'BA02_pack_{i}_pocketed_tray',carrier,'carrier','battery_carrier','Original210x704x12machined aluminium tray. Battery seatZ-69,4mm pocketdepth,2mm side gap. Two27.4x3mm underside channels capture straps beneath tray; minimum5mm roof above channels. Radius/edge protection, material, bending and local bearing require qualification.')
  for j,y in enumerate([-150,150],1):
   sh,route=band(cx,y);put(f'BA02_pack_{i}_strap_{j}_webbing_route',sh,'strap','battery_strap_route','Original routed-webbing equivalent for the purchased NRS1inchHD4ft assembly. A40mm closure gap is deliberate: commercial cam, spring, teeth, webbing bite and tail are NOT modeled.25.4mm width sourced;2mm thickness assumed. WLL applies only to the purchased complete strap, never to this geometry or a custom buckle.')
   # Approximate purchased external depiction with a nominal webbing-interface slot.
   # This is NOT a custom buckle design or a model of internal gripping function.
   dep=b.box(60,35,7,(cx+10,y,COVER+4.5))
   dep=dep.cut(b.box(64,25.4,3,(cx+10,y,COVER+.5)))
   put(f'BA02_pack_{i}_strap_{j}_purchased_buckle_APPROX_EXTERNAL',dep,'buckle_proxy','commercial_buckle_external_proxy','APPROXIMATE EXTERNAL DEPICTION ONLY:assumed60x35x7mm purchased NRS cam buckle body with nominal route contact. No internal cam, spring, teeth, sewn termination, tail or gripping/locking physics modeled. Do not manufacture or apply the500lb rating to this CAD body. Full commercial strap assembly is the functional boundary.')
   # Nonphysical buckle/service envelope lives only in separate reservation export.
   buckle=b.box(60,35,18,(cx+10,y,COVER+11))
   RES.append({'name':f'BA02_pack_{i}_strap_{j}_buckle_service_RESERVATION','shape':buckle,'material':'proxy','group':'buckle_service_reservations','note':'ASSUMED60x35x18mm buckle/hand-clearance reservation; no vendor dimensions available. Not physical buckle CAD. Real cam action, label and tail stowage require fit check.'})
   length=sum(math.hypot(route[(k+1)%len(route)][0]-a[0],route[(k+1)%len(route)][1]-a[1]) for k,a in enumerate(route))
   rows.append({'pack':i,'strap':j,'center_C_y_mm':y,'width_mm':25.4,'thickness_assumption_mm':2,'geometric_inner_loop_length_mm':length,'selected_strap_length_mm':1219.2,'gross_length_remaining_mm':1219.2-length,'closure_and_tail_allowance_in_length_mm':200,'strap_WLL_lbf':500,'strap_MBS_lbf':1500,'vehicle_restraint_rating_established':False,'terminal_plan_clearance_mm':275.25-10-(150+12.7),'known_vent_plan_clearance_mm':137.3-(52.5167+12),'case_preload_N':None,'case_bearing_zone_approved':False})
 put('battery_well_floor_3mm',floor,'aluminium','body_replacement','Original well floor with4inherited holes preserved and8newØ8.8M8tray bores; no unused factory-bracket bores added. Old holes require sealed closure.28R02electrical deck bores untouched.')
 return rows

def main():
 O.mkdir(exist_ok=True);rows=build()
 for stem,parts in [('battery_strap_tray_BA02',PARTS),('buckle_service_reservations_BA02',RES)]:
  a=cq.Assembly(name=stem)
  for p in parts:a.add(p['shape'],name=p['name'],color=cq.Color(*b.MATS[p['material']]['color']))
  a.export(str(O/(stem+'.step')));b.export_glb(parts,O/(stem+'.glb'))
 baseline=json.loads((P/'BA01/replacement_addition_manifest.json').read_text())
 m={'revision':'BA02','state':'Original physically connected strap/tray route; prototype, not field-qualified. Factory brackets omitted; BA01 failed rigid-fit evidence preserved.','replace_names':['battery_well_floor_3mm'],'remove_names':baseline['remove_names'],'add_names':[p['name'] for p in PARTS if p['name']!='battery_well_floor_3mm'],'remove_external_proxy_names':baseline['remove_external_proxy_names'],'integration':'Apply by name onto PR01 or later body. Never overlay BA01 factory brackets or old RELiON hardware. Buckle reservations are separate nonphysical envelopes.','pack_centers_bottom_C_mm':[[-975,0,BASE],[-625,0,BASE]],'battery_mass_kg':74,'source_casing_is_not_a_mass_model':True,'terminal_top_C_z_mm':169.6,'cover_reference_C_z_mm':COVER,'strap_component':{'manufacturer':'NRS','name':'1 inch HD Tie-Down Straps,4-foot size','url':'https://www.nrs.com/rescue/nrs-1-hd-tie-down-straps/p4yc','manufacturer_sku':'60027.01.112','variant':'4-foot pair,Stealth Black','retail_units_required':2,'straps_per_retail_unit':2,'quantity':4,'observed_variant_family_price_USD':[12.95,43.95],'exact_4ft_pair_price_USD':None,'price_status':'Selected-variant price unverified; do not assign range minimum.','WLL_lbf':500,'MBS_lbf':1500,'width_mm':25.4,'length_mm':1219.2,'webbing':'UV-protected polypropylene','note':'Whole strap assembly rating only; no lifting, battery-case or vehicle crash rating implied.'},'commercial_function_boundary':{'purchased_item':'NRS60027.01.112 complete cam-strap assembly','modeled':'Routed webbing with40mm closure gap; approximate external buckle with nominal surface contact; separate nonphysical service envelope','omitted':'Cam, spring, teeth, sewn termination, tail threading, release motion and actual friction/locking mechanics','geometry_contact_graph_proves':'Nominal spatial connectivity only','geometry_contact_graph_does_not_prove':'Closure action, holding load, casing approval or vehicle retention','rating_scope':'500lb WLL/1500lb MBS belongs only to purchased complete strap assembly; never custom CAD buckle'},'joints':JOINTS,'strap_routes':rows,'parts':[{'name':p['name'],'group':p['group'],'material':p['material'],'bounds_mm':b.bounds(p['shape']),'valid':p['shape'].isValid(),'solids':len(p['shape'].Solids()),'volume_mm3':p['shape'].Volume(),'note':p['note']} for p in PARTS]}
 m['mass_accounting']={'battery_mass_kg':74,'original_hardware_kg_including_replacement_floor':sum(q['shape'].Volume()*1e-9*b.MATS[q['material']]['density'] for q in PARTS),'original_hardware_kg_excluding_replacement_floor':sum(q['shape'].Volume()*1e-9*b.MATS[q['material']]['density'] for q in PARTS if q['name']!='battery_well_floor_3mm'),'strap_and_buckle_mass_kg':None,'note':'Only original metal hardware has CAD-density mass; complete commercial strap mass not verified. Battery proxies do not contribute solid-volume mass.'}
 (O/'replacement_addition_manifest.json').write_text(json.dumps(m,indent=2));print('Built BA02',len(PARTS),'physical/interface parts and',len(RES),'buckle reservations',flush=True)
if __name__=='__main__':main()
