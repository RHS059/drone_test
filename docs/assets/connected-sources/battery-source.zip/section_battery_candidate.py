"""Actual original exported-mesh section lines. No vendor geometry, no Blender."""
from pathlib import Path
import json,struct,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
P=Path(__file__).parent/'BA01';blob=(P/'battery_candidate_BA01.glb').read_bytes();nl=struct.unpack_from('<I',blob,12)[0];g=json.loads(blob[20:20+nl]);binary=blob[28+nl:]
def data(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC3':3}[a['type']];typ=np.float32 if a['componentType']==5126 else np.uint32
 return np.frombuffer(binary,dtype=typ,count=a['count']*n,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape((-1,n))
def plot(file,x,yl,yr,zl,zr,title):
 fig,ax=plt.subplots(figsize=(12,7),dpi=180,facecolor='#f5f7fa');ax.set_facecolor('#f5f7fa')
 colors={'battery_external_dimensional_proxy':'#0878a0','battery_terminal_reservations':'#9d6917','battery_fasteners':'#b86920','factory_bracket_dimensional_proxy':'#333d48','battery_carrier':'#138781','body_replacement':'#818681'}
 for n in g['nodes']:
  if not(n['name'].startswith('BA01_pack_1') or n['name']=='battery_well_floor_3mm'):continue
  p=g['meshes'][n['mesh']]['primitives'][0];v=data(p['attributes']['POSITION'])*1000;f=data(p['indices']).reshape(-1,3);tris=v[f];lines=[]
  for t in tris:
   d=t[:,0]-x
   if min(d)>1e-4 or max(d)<-1e-4:continue
   q=[]
   for j in range(3):
    k=(j+1)%3
    if abs(d[j])<1e-4:q.append(t[j,1:])
    if d[j]*d[k]<-1e-8:q.append((t[j]+(t[k]-t[j])*d[j]/(d[j]-d[k]))[1:])
   if len(q)>=2:
    q=np.unique(np.round(q,4),axis=0)
    if len(q)==2:lines.append(q)
  if lines:ax.add_collection(LineCollection(lines,colors=colors.get(n.get('extras',{}).get('group'),'#34495b'),linewidths=1.7))
 ax.set(xlim=(yl,yr),ylim=(zl,zr),aspect='equal',xlabel='Y (mm)',ylabel='Z (mm)',title=title);ax.grid(color='#d9e0e7',lw=.5)
 fig.text(.06,.04,'Exact plane intersections with the exported original triangles. Blue: battery proxy; dark: bracket; teal: carrier; orange: hardware.\nMatching nominal cylindrical threads are geometric contact equivalents. Factory tolerances, preload, welds and loads remain unqualified.',fontsize=9)
 ax.annotate('M6 × 20 screw',xy=(334.1,-65),xytext=(343,-56),arrowprops={'arrowstyle':'->'},fontsize=10)
 ax.annotate('Washer on bracket foot',xy=(338,-70.1),xytext=(344,-74),arrowprops={'arrowstyle':'->'},fontsize=10)
 ax.annotate('10 mm tapped holder',xy=(342,-84),xytext=(344,-88),arrowprops={'arrowstyle':'->'},fontsize=10)
 ax.annotate('Sloped ledge: contact unqualified',xy=(318,-63),xytext=(295,-57),arrowprops={'arrowstyle':'->'},fontsize=10)
 fig.subplots_adjust(left=.08,right=.99,top=.9,bottom=.16);fig.savefig(P/file);plt.close(fig)
plot('bracket_M6_true_section.png',-946.5,295,368,-94,-51,'BA01 bracket-to-floor retention · actual X = −946.5 mm section')
print('Saved actual original-geometry section.')
