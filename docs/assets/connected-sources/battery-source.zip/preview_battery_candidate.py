"""Evidence plots from exported original GLB triangles; no Blender rendering."""
from pathlib import Path
import json,struct,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from matplotlib.colors import LightSource
P=Path(__file__).parent/'BA01';blob=(P/'battery_candidate_BA01.glb').read_bytes();nl=struct.unpack_from('<I',blob,12)[0];g=json.loads(blob[20:20+nl]);binary=blob[28+nl:]
def data(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC3':3}[a['type']];typ=np.float32 if a['componentType']==5126 else np.uint32
 return np.frombuffer(binary,dtype=typ,count=a['count']*n,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape((-1,n))
parts={}
for n in g['nodes']:
 p=g['meshes'][n['mesh']]['primitives'][0];v=data(p['attributes']['POSITION'])*1000;f=data(p['indices']).reshape(-1,3);parts[n['name']]={'tris':v[f],'color':g['materials'][p['material']]['pbrMetallicRoughness']['baseColorFactor']}
def clip(tris,axis,loc,sign):
 d=sign*(tris[:,:,axis]-loc);ins=d>=-1e-5;out=list(tris[ins.all(axis=1)])
 for tri,di,ii in zip(tris[ins.any(axis=1)&~ins.all(axis=1)],d[ins.any(axis=1)&~ins.all(axis=1)],ins[ins.any(axis=1)&~ins.all(axis=1)]):
  poly=[]
  for j in range(3):
   k=(j+1)%3
   if ii[j]:poly.append(tri[j])
   if ii[j]!=ii[k]:poly.append(tri[j]+(tri[k]-tri[j])*di[j]/(di[j]-di[k]))
  for j in range(1,len(poly)-1):out.append([poly[0],poly[j],poly[j+1]])
 return np.asarray(out).reshape(-1,3,3)
def view(file,title,subtitle,names,bounds,elev,azim,cut=None):
 fig=plt.figure(figsize=(12,8),dpi=150,facecolor='#f3f6f9');ax=fig.add_subplot(111,projection='3d');ax.set_facecolor('#f3f6f9');tris=[];colors=[]
 for n in names:
  t=parts[n]['tris']
  for axis in range(3):t=clip(clip(t,axis,bounds[axis],1),axis,bounds[axis+3],-1)
  if cut:t=clip(t,*cut)
  tris.extend(t);colors.extend([parts[n]['color']]*len(t))
 coll=Poly3DCollection(tris,facecolors=colors,edgecolors='#334254',linewidths=.08,shade=True,lightsource=LightSource(azdeg=315,altdeg=45));ax.add_collection3d(coll)
 ax.set_xlim(bounds[0],bounds[3]);ax.set_ylim(bounds[1],bounds[4]);ax.set_zlim(bounds[2],bounds[5]);ax.set_box_aspect(np.array(bounds[3:])-bounds[:3]);ax.view_init(elev=elev,azim=azim);ax.set_proj_type('ortho');ax.set_xlabel('X (mm)');ax.set_ylabel('Y (mm)');ax.set_zlabel('Z (mm)')
 fig.suptitle(title,fontsize=17,x=.06,ha='left',y=.97);fig.text(.06,.915,subtitle,fontsize=10,va='top');fig.text(.06,.03,'Original dimensional geometry only. Blue: battery interface; teal: original carrier; grey: bracket; silver: fasteners.\nNo supplier mesh. Factory tolerances, loads, dry ventilation and 37 kg handling remain open.',fontsize=9,color='#34495c');fig.subplots_adjust(top=.86,bottom=.11,left=.03,right=.99);fig.savefig(P/file);plt.close(fig)
view('two_pack_layout.png','Two-pack BA01: original mounting candidate','Both packs at the proposed bottom datum Z −73 mm. Well walls and roof omitted to expose the attachment hardware.',list(parts),[-1130,-365,-95,-470,365,190],43,-58)
view('bracket_carrier_closeup.png','Factory-dimension bracket and original stepped carrier','Pack 1, left end. The bracket foot seat and end-tab relief are separate surfaces; no invented top-case clamp.',[n for n in parts if n.startswith('BA01_pack_1') or n=='battery_well_floor_3mm'],[-1025,303,-94,-925,352,-47],27,-58)
view('bracket_M6_stack_section.png','M6 bracket retention: continuous hardware path','Triangle section through one M6 axis: head, washer, bracket, carrier, floor and 10 mm tapped holder. Section is uncapped.',[n for n in parts if n.startswith('BA01_pack_1') or n=='battery_well_floor_3mm'],[-957,306,-93,-932,349,-56],10,180,(0,-946.5,1))
#Plan evidence of fixed hatch, side ventilation and straight extraction margins.
from matplotlib.patches import Rectangle
fig,ax=plt.subplots(figsize=(10,8),dpi=150);ax.add_patch(Rectangle((-1122,-357),644,714,fill=False,lw=2,label='Well clear boundary'));ax.add_patch(Rectangle((-1105,-340),610,680,fill=False,ls='--',lw=2,label='Fixed hatch opening'))
for i,cx in enumerate([-975,-625],1):
 ax.add_patch(Rectangle((cx-80.75,-323.8),161.5,647.6,facecolor='#0d6b8c',alpha=.7));ax.text(cx,0,f'Pack {i}\n37 kg',ha='center',va='center',color='white',fontsize=12)
 ax.add_patch(Rectangle((cx-90.75,-333.8),181.5,667.6,fill=False,edgecolor='#dc892c',ls=':',lw=2))
 for x in [cx-28.5,cx+28.5]:
  for y in [-334.1,334.1]:ax.add_patch(plt.Circle((x,y),5,color='#b75334'))
ax.set(xlim=(-1145,-455),ylim=(-380,380),aspect='equal',xlabel='X (mm)',ylabel='Y (mm)',title='BA01: hatch and service corridor');ax.legend(loc='upper center');fig.text(.13,.035,'33.2 mm to well sides; 16.2 mm to hatch sides; 6.2 mm with ±10 mm extraction allowance.\nM6 straight tool Ø10: only 0.9 mm nominal hatch-edge margin. Real rigging/driver access unverified.',fontsize=9);fig.subplots_adjust(bottom=.15);fig.savefig(P/'hatch_service_plan.png');plt.close(fig)
print('Saved 4 original geometry evidence plots.')
