"""Evidence sections and plan of delivered original BA02 geometry. No Blender."""
from pathlib import Path
import json,struct,numpy as np
import matplotlib;matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.collections import LineCollection
from matplotlib.patches import Rectangle,Circle
P=Path(__file__).parent/'BA02';blob=(P/'battery_strap_tray_BA02.glb').read_bytes();nl=struct.unpack_from('<I',blob,12)[0];g=json.loads(blob[20:20+nl]);binary=blob[28+nl:]
def data(i):
 a=g['accessors'][i];v=g['bufferViews'][a['bufferView']];n={'SCALAR':1,'VEC3':3}[a['type']];typ=np.float32 if a['componentType']==5126 else np.uint32
 return np.frombuffer(binary,dtype=typ,count=a['count']*n,offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape((-1,n))
def section(file,axis,loc,axes,bounds,title,labels):
 fig,ax=plt.subplots(figsize=(11,8),dpi=170,facecolor='#f5f7fa');ax.set_facecolor('#f5f7fa')
 colors={'battery_external_dimensional_proxy':'#0878a0','battery_terminal_reservations':'#9d6917','battery_fasteners':'#9a691c','battery_strap_route':'#e76b15','commercial_buckle_external_proxy':'#353e49','battery_carrier':'#16867f','body_replacement':'#5f6972'}
 for n in g['nodes']:
  if not(n['name'].startswith('BA02_pack_1') or n['name']=='battery_well_floor_3mm'):continue
  pr=g['meshes'][n['mesh']]['primitives'][0];v=data(pr['attributes']['POSITION'])*1000;f=data(pr['indices']).reshape(-1,3);tris=v[f];lines=[]
  for t in tris:
   d=t[:,axis]-loc
   if min(d)>1e-4 or max(d)<-1e-4:continue
   q=[]
   for j in range(3):
    k=(j+1)%3
    if abs(d[j])<1e-4:q.append(t[j,axes])
    if d[j]*d[k]<-1e-8:q.append((t[j]+(t[k]-t[j])*d[j]/(d[j]-d[k]))[axes])
   if len(q)>=2:
    q=np.unique(np.round(q,4),axis=0)
    if len(q)==2:lines.append(q)
  if lines:ax.add_collection(LineCollection(lines,colors=colors.get(n.get('extras',{}).get('group'),'#34495b'),linewidths=1.8))
 ax.set(xlim=bounds[:2],ylim=bounds[2:],aspect='equal',xlabel='XYZ'[axes[0]]+' (mm)',ylabel='XYZ'[axes[1]]+' (mm)',title=title);ax.grid(color='#dce3ea',lw=.5)
 for text,target,xy in labels:ax.annotate(text,xy=target,xytext=xy,arrowprops={'arrowstyle':'->','color':'#4a5661'},fontsize=10)
 fig.text(.06,.035,'Actual plane intersections with delivered original triangles. Orange: engaged strap route; teal: tray; blue: battery proxy.\nNominal geometry only. Case preload, strap abrasion, buckle dimensions and vehicle restraint loads remain unqualified.',fontsize=9);fig.subplots_adjust(left=.10,right=.98,top=.92,bottom=.14);fig.savefig(P/file);plt.close(fig)
section('strap_captures_tray_section.png',1,-150,[0,2],[-1120,-830,-90,185],'BA02 · webbing captures tray; purchased buckle function is external',[
 ('25.4 mm webbing / approximate buckle\nCam and gripping function omitted',(-975,153.8),(-1105,173)),
 ('Under-tray return in real channel',(-975,-75),(-975,-43)),
 ('Pocket floor supports battery',(-1005,-69),(-1100,-30)),
 ('Assumed engaged path\nNo pretension assigned',(-880,50),(-920,82))])
section('strap_channel_closeup.png',1,-150,[0,2],[-1089,-1044,-84,-53],'BA02 · underside channel captures the strap',[
 ('2 mm strap assumption',(-1060,-75),(-1060,-81)),
 ('3 mm channel; 5 mm roof',(-1060,-72),(-1058,-58)),
 ('Tray outer edge\nRadius / sleeve to verify',(-1080,-65),(-1088,-55))])
section('tray_M8_retention_section.png',1,-285,[0,2],[-1088,-1040,-98,-45],'BA02 · M8 × 30 tray-to-floor retention',[
 ('Socket screw + top washer',(-1069,-59),(-1054,-49)),
 ('12 mm tray',(-1080,-71),(-1087,-49)),
 ('Well floor',(-1045,-79),(-1054,-85)),
 ('Bottom washer + M8 nut\n6.5 mm nominal engagement',(-1062,-85),(-1086,-94))])
fig,ax=plt.subplots(figsize=(10,9),dpi=170);ax.add_patch(Rectangle((-1122,-357),644,714,fill=False,lw=2));ax.add_patch(Rectangle((-1105,-340),610,680,fill=False,ls='--',lw=1.4))
for i,cx in enumerate([-975,-625],1):
 ax.add_patch(Rectangle((cx-105,-352),210,704,facecolor='#b7d7d1',edgecolor='#247e74',alpha=.55));ax.add_patch(Rectangle((cx-80.75,-323.8),161.5,647.6,facecolor='#4b94b0',alpha=.65));ax.text(cx,20,f'Pack {i}\n37 kg',ha='center',va='center',fontsize=12)
 for y in [-150,150]:
  ax.add_patch(Rectangle((cx-107,y-12.7),214,25.4,facecolor='#e97926',alpha=.9));ax.add_patch(Rectangle((cx-20,y-17.5),60,35,fill=False,edgecolor='#9a5016',ls='--',lw=2))
 for y,color in [(-275.25,'#be3333'),(275.25,'#25303a')]:ax.add_patch(Circle((cx-54.05,y),10,color=color))
 ax.add_patch(Circle((cx-44.25,-52.5),12,fill=False,lw=2,color='#303c48'))
 for dx in [-94,94]:
  for y in [-285,285]:ax.add_patch(Circle((cx+dx,y),6.5,color='#a1833b'))
ax.set(xlim=(-1140,-460),ylim=(-375,375),aspect='equal',xlabel='X (mm)',ylabel='Y (mm)',title='BA02 · two bands per pack, retained tray and clear interface routes');fig.text(.10,.035,'Orange: 25.4 mm bands at Y ±150. Dotted rectangles: assumed buckle service volumes.\nCircles: terminals, central top fitting and retained M8 tray screws. These are geometric routes, not approved keep-outs.',fontsize=9);fig.subplots_adjust(bottom=.13);fig.savefig(P/'strap_terminal_route_plan.png');plt.close(fig)
print('Saved 4 BA02 original geometry evidence plots.')
