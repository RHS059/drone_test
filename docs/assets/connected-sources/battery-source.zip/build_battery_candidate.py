"""Original two-pack BA01 mounting study. All dimensions mm, vehicle C Z-up.
Never imports vendor CAD. Review-only factory data used as numeric interface facts.
No factory moulding, vendor mesh, texture, logo, internal cell model or patented detail.
No vehicle qualification or permission to build implied.
"""
from pathlib import Path
import cadquery as cq, numpy as np, json,struct,sys,math,hashlib
P=Path(__file__).parent; B=P.parent/'body-power';sys.path.insert(0,str(B));import build_body_power as b
OUT=P/'BA01'; PARTS=[];RES=[];JOINTS=[]; CENTERS=[-975.,-625.];BASE=-73.;BRACKET_INNER=311.8
b.MATS.update({'battery':{'density':0,'color':[.04,.34,.53,1]},'terminal':{'density':0,'color':[.65,.48,.20,1]},'interface':{'density':0,'color':[.29,.32,.36,1]},'carrier':{'density':2700,'color':[.15,.61,.64,1]},'reservation':{'density':0,'color':[.9,.5,.15,.2]}})
def put(n,s,mat='carrier',group='battery_candidate',note=''):
 assert s.isValid() and len(s.Solids())==1,(n,s.isValid(),len(s.Solids()));PARTS.append({'name':n,'shape':s,'material':mat,'group':group,'note':note});return s

def bolt(n,x,y,under,L,r=3,hr=5,hh=6,af=5):
 s=b.cyl(r,L,(x,y,under-L)).fuse(b.cyl(hr,hh,(x,y,under)));s=s.cut(cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).extrude(3).translate((x,y,under+hh-3)).val());put(n,s,'fastener','battery_fasteners','Original nominal smooth-thread substitute; head/socket functional envelope. Grade, torque, lock and corrosion unspecified.')
def washer(n,x,y,z,od=12,id=6.4,t=1.6):return put(n,b.cyl(od/2,t,(x,y,z)).cut(b.cyl(id/2,t+2,(x,y,z-1))),'fastener','battery_fasteners','Nominal ISO7089 washer envelope; material/strength unqualified.')
def hexnut(n,x,y,z,af=13,d=8,t=6.5):return put(n,cq.Workplane('XY').polygon(6,af/math.cos(math.pi/6)).circle(d/2).extrude(t).translate((x,y,z)).val(),'fastener','battery_fasteners','Matching nominal cylindrical thread-contact equivalent; no helical flanks/tolerances. Not a clearance-hole or tap-drill manufacturing instruction.')
def bracket(cx,sg):
 # Original functional Z-section from published dimension callouts. Not a vendor model.
 # Local inward edge q=0; outward positive q. 30.3 overall, 2 sheet, lip11.8,
 # 12.9 tab height, 1 mm foot-offset. Original square corners omit supplier fillets.
 # Bracket lowest tabs at battery datum-.9 gives underside lip datum+10.
 z=BASE-.9
 profile=[(0,10.9),(11.8,10.9),(13.3,9.4),(13.3,3),(16.3,1),(30.3,1),(30.3,3),(16.3,3),(15.3,4),(15.3,9.9),(12.3,12.9),(0,12.9)]
 pts=[(sg*(BRACKET_INNER+q),z+h) for q,h in profile]
 s=cq.Workplane('YZ').polyline(pts).close().extrude(80.3).translate((cx-40.15,0,0)).val()
 for dx in [-41.15,41.15]:s=s.fuse(b.box(2.002,11.8,12.9,(cx+dx,sg*(BRACKET_INNER+5.9),z+6.45)))
 for dx in [-28.5,28.5]:
  #7x10 obround: drawing R3.5 and3 mm centre separation; across Y.
  slot=cq.Workplane('XY').center(cx+dx,sg*334.1).slot2D(10,7,90).extrude(5).translate((0,0,z)).val();s=s.cut(slot)
 return s

def build():
 # Source frozen PR01 without editing it. GLB retains exact assembly names/order.
 blob=(B/'panel-retention/body_power_panel_retained_PR01.glb').read_bytes();nl=struct.unpack_from('<I',blob,12)[0];doc=json.loads(blob[20:20+nl]);names=[n['name'] for n in doc['nodes']]
 solids=cq.importers.importStep(str(B/'panel-retention/body_power_panel_retained_PR01.step')).val().Solids();assert len(names)==len(solids)
 baseline=dict(zip(names,solids));removed=[n for n in names if n.startswith('battery_') and n!='battery_well_floor_3mm' and ('isolator_pad' in n or '_stop_' in n or n.startswith('battery_retention_'))]
 floor=baseline['battery_well_floor_3mm'];before=floor
 for i,cx in enumerate(CENTERS,1):
  # A flat, original external proxy with only mounting/terminal facts.
  case=b.box(161.5,623.0,226.1,(cx,0,BASE+113.05))
  for sg in [-1,1]:
   poly=[(sg*y,BASE+z) for y,z in [(311.5,0),(323.8,0),(323.8,8.9239),(311.5,10)]]
   ledge=cq.Workplane('YZ').polyline(poly).close().extrude(80).translate((cx-40,0,0)).val();case=case.fuse(ledge)
  put(f'BA01_pack_{i}_functional_outer_shape',case,'battery','battery_external_dimensional_proxy','ORIGINAL DIMENSIONAL PROXY:161.5 depth,647.6 overall width;226.1 nominal cover height;80 mm-wide ledge footprint is an original simplified assumption; the 12.3 mm ledge projects from a 10 mm root to an 8.924 mm tip at 5 degrees, based on numeric source inspection from private numeric inspection. Not supplier geometry, mass or strength representation.')
  for sg,polarity in [(-1,'positive'),(1,'negative')]:
   # An independent contact reservation; actual height/source conflict remains a gate.
   term=b.cyl(10,12.5,(cx-54.05,sg*275.25,BASE+226.1)).cut(b.cyl(4,14,(cx-54.05,sg*275.25,BASE+225.5)))
   put(f'BA01_pack_{i}_{polarity}_M8_interface',term,'terminal','battery_terminal_reservations','M8 and550.5 pitch/26.7 edge offset from manufacturer drawing.12.5 axial cylinder is conservative checked STEP overall clearance, not a qualified lug contact stack. Positive/negative orientation is an explicit installed orientation choice.')
  carrier=b.plate(210,704,5,-77,cx)
  #Full-envelope seat one mm below carrier top: continuous support, no insulating pad claim.
  carrier=carrier.cut(b.plate(161.6,647.7,2,-73,cx))
  for sg in [-1,1]:
   #Foot seat at-72.9; independent relief under factory bent tabs down to-74.
   carrier=carrier.cut(b.plate(84.4,16.6,1.9,-72.9,cx,sg*334.1))
   for dx in [-41.15,41.15]:carrier=carrier.cut(b.plate(2.4,12.2,3,-74,cx+dx,sg*317.7))
   #2x M6 attachment through mounting bracket,carrier,andfloor into welded10mm tapped block.
   for j,dx in enumerate([-28.5,28.5],1):
    x=cx+dx;y=sg*334.1;carrier=carrier.cut(b.cyl(3.3,10,(x,y,-80)));floor=floor.cut(b.cyl(3.3,6,(x,y,-81)))
    n=f'BA01_pack_{i}_bracket_{sg}_M6_{j}';under=-69.3
    washer(n+'_washer',x,y,-70.9);bolt(n,x,y,under,20)
    holder=b.plate(18,18,10,-90,x,y).cut(b.cyl(3,12,(x,y,-91)))
    put(n+'_tapped_holder',holder,'aluminium','battery_fasteners','Original18x18x10 same-alloy weld-on boss under floor. TapM6x1;CADdiameter6 is nominal thread-contact equivalent. Welds/thread stripping/preload not qualified.')
    JOINTS.append({'id':n,'axis_C_mm':[x,y,0],'bolt':'M6x20','underhead_z_mm':under,'tip_z_mm':under-20,'nominal_engagement_mm':9.3,'holder_z_mm':[-90,-80],'clearance_diameter_mm':6.6,'clamped_parts':['washer','factory-dimension bracket','original carrier','well floor'],'tool_envelope_diameter_mm':10,'tool_access':'from open battery hatch','physical_thread_qualification':False})
   put(f'BA01_pack_{i}_bracket_{sg}_functional_interface',bracket(cx,sg),'interface','factory_bracket_dimensional_proxy','Original dimensional section from factory bracket drawing; two7x10 slots57 apart. Not vendor CAD. Bracket fastening is retained, but battery ledge contact is NOT established. Actual factory pose has measured corner interference; dimensions and tolerances remain a prototype gate.')
  for k,(dx,y) in enumerate([(dx,y) for dx in [-94,94] for y in [-285,285]],1):
   x=cx+dx;carrier=carrier.cut(b.cyl(4.4,8,(x,y,-78)));floor=floor.cut(b.cyl(4.4,6,(x,y,-81)))
   n=f'BA01_pack_{i}_carrier_M8_{k}';washer(n+'_top_washer',x,y,-72,16,8.4);bolt(n,x,y,-70.4,20,r=4,hr=6.5,hh=8,af=6)
   washer(n+'_bottom_washer',x,y,-81.6,16,8.4);hexnut(n+'_nut',x,y,-88.1)
   JOINTS.append({'id':n,'axis_C_mm':[x,y,0],'bolt':'M8x20','underhead_z_mm':-70.4,'tip_z_mm':-90.4,'nominal_engagement_mm':6.5,'nut_z_mm':[-88.1,-81.6],'clearance_diameter_mm':8.8,'tool_envelope_diameter_mm':18,'physical_thread_qualification':False})
  put(f'BA01_pack_{i}_machined_carrier',carrier,'carrier','battery_carrier','Original210x704x5 aluminium plate with1mm battery seat,0.9mm bracket foot seats and2mm tab-relief pockets. Carries pack bottom and M6 bracket fasteners; M8through-floor retention. Material, plate bending, well-floor load path, shock/fatigue/thermal and galvanic checks open.')
 put('battery_well_floor_3mm',floor,'aluminium','body_replacement','BA01adds8M6+8M8clearance bores to frozen floor;4oldM8bores preserved but unused and require sealing. All28R02electrical deck bores unaffected.')
 return baseline,removed,before

def export():
 baseline,removed,oldfloor=build();OUT.mkdir(exist_ok=True)
 ass=cq.Assembly(name='BA01_battery_candidate')
 for p in PARTS:ass.add(p['shape'],name=p['name'],color=cq.Color(*b.MATS[p['material']]['color']))
 ass.export(str(OUT/'battery_candidate_BA01.step'));b.export_glb(PARTS,OUT/'battery_candidate_BA01.glb')
 props=[{'name':p['name'],'material':p['material'],'group':p['group'],'bounds_mm':b.bounds(p['shape']),'volume_mm3':p['shape'].Volume(),'solid_count':len(p['shape'].Solids()),'valid':p['shape'].isValid(),'note':p['note']} for p in PARTS]
 manifest={'revision':'BA01','status':'candidate only; rigid factory-CAD fit screen fails; not selected or field-qualified','replace_names':['battery_well_floor_3mm'],'remove_names':removed,'add_names':[p['name'] for p in PARTS if p['name']!='battery_well_floor_3mm'],'remove_external_proxy_names':[f'DIMENSION_ONLY_RELiON_InSight_48V_battery_{i}' for i in range(1,5)],'integration':'Compose by name; never overlay old restraints or old floor. Preserve all unrelated PR01 history and28R02deck holes. Do not include review-only folder.','battery_mass_kg':74,'pack_centers_C_mm':[[x,0,BASE] for x in CENTERS],'nominal_envelope_mm':[161.5,647.6,234.7],'conservative_step_height_mm':238.596,'mass_proxy':False,'joints':JOINTS,'parts':props,'baseline_sha256':hashlib.sha256((B/'panel-retention/body_power_panel_retained_PR01.step').read_bytes()).hexdigest()}
 (OUT/'replacement_addition_manifest.json').write_text(json.dumps(manifest,indent=2));print('Built',len(PARTS),'candidate parts; removed old restraint names',len(removed),flush=True)
 return baseline,removed
if __name__=='__main__':export()
