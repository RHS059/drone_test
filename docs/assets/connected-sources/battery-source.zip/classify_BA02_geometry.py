"""Label representation boundaries; preserves every geometry buffer byte."""
from pathlib import Path
import struct,json,hashlib
P=Path(__file__).parent/'BA02'
def classify(path):
 blob=path.read_bytes();n=struct.unpack_from('<I',blob,12)[0];g=json.loads(blob[20:20+n]);binary=blob[28+n:];before=hashlib.sha256(binary).hexdigest()
 for node in g['nodes']:
  e=node.setdefault('extras',{});grp=e.get('group','')
  if grp=='commercial_buckle_external_proxy':e.update(classification='approximate_purchased_COTS_external_depiction',manufacturing_geometry=False,commercial_internal_function_modeled=False,rating_applies_to_this_CAD=False)
  elif grp=='battery_strap_route':e.update(classification='original_routed_webbing_interface',closure_gap_modeled_mm=40,cam_locking_function_modeled=False,commercial_internal_function_modeled=False)
  elif grp.startswith('battery_') and ('proxy' in grp or 'reservations' in grp):e.update(classification='original_dimensional_interface_proxy',mass_model=False)
  elif grp=='buckle_service_reservations':e.update(classification='nonphysical_service_reservation',physical_geometry=False)
  else:e.update(classification='original_development_CAD',manufacturing_qualified=False)
 g['extras'].update(qualified=False,commercial_buckle_internals_modeled=False,rated_commercial_assembly='NRS60027.01.112',rating_scope='Purchased complete commercial cam strap only; not original CAD or vehicle retention',geometry_mass_model_includes_battery=False)
 js=json.dumps(g,separators=(',',':')).encode();js+=b' '*((-len(js))%4)
 out=struct.pack('<III',0x46546C67,2,28+len(js)+len(binary))+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(binary),0x004E4942)+binary;path.write_bytes(out)
 nn=struct.unpack_from('<I',out,12)[0];assert before==hashlib.sha256(out[28+nn:]).hexdigest();return {'file':path.name,'geometry_binary_sha256':before,'geometry_unchanged':True}
if __name__=='__main__':
 rows=[classify(P/n) for n in ['battery_strap_tray_BA02.glb','buckle_service_reservations_BA02.glb']]
 (P/'representation_metadata_check.json').write_text(json.dumps(rows,indent=2));r=json.loads((P/'verification.json').read_text());r['outputs_sha256']={n:hashlib.sha256((P/n).read_bytes()).hexdigest() for n in ['battery_strap_tray_BA02.step','battery_strap_tray_BA02.glb','replacement_addition_manifest.json']};r['representation_metadata_checks']=rows;(P/'verification.json').write_text(json.dumps(r,indent=2));print(rows)
